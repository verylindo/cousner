CREATE TABLE `checkoutIntents` (
	`id` varchar(64) NOT NULL,
	`userId` int NOT NULL,
	`priceId` varchar(255) NOT NULL,
	`stripeCheckoutSessionId` varchar(255),
	`stripeCustomerId` varchar(255),
	`stripeSubscriptionId` varchar(255),
	`status` enum('pending','fulfilled','failed') NOT NULL DEFAULT 'pending',
	`expiresAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `checkoutIntents_id` PRIMARY KEY(`id`),
	CONSTRAINT `checkoutIntents_stripeCheckoutSessionId_unique` UNIQUE(`stripeCheckoutSessionId`),
	CONSTRAINT `checkoutIntents_stripeSubscriptionId_unique` UNIQUE(`stripeSubscriptionId`)
);
--> statement-breakpoint
ALTER TABLE `checkoutIntents` ADD CONSTRAINT `checkoutIntents_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `checkoutIntents_user_created_idx` ON `checkoutIntents` (`userId`,`createdAt`);
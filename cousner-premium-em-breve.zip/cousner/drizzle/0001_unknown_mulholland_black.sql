CREATE TABLE `stripeWebhookEvents` (
	`eventId` varchar(255) NOT NULL,
	`eventType` varchar(120) NOT NULL,
	`eventCreated` int NOT NULL,
	`processedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `stripeWebhookEvents_eventId` PRIMARY KEY(`eventId`)
);
--> statement-breakpoint
CREATE TABLE `subscriptions` (
	`userId` int NOT NULL,
	`stripeCustomerId` varchar(255),
	`stripeSubscriptionId` varchar(255),
	`priceId` varchar(255),
	`status` enum('active','trialing','past_due','canceled','incomplete','unpaid','paused') NOT NULL DEFAULT 'incomplete',
	`currentPeriodEnd` timestamp,
	`cancelAtPeriodEnd` boolean NOT NULL DEFAULT false,
	`lastStripeEventCreated` int NOT NULL DEFAULT 0,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `subscriptions_userId` PRIMARY KEY(`userId`),
	CONSTRAINT `subscriptions_stripeSubscriptionId_unique` UNIQUE(`stripeSubscriptionId`)
);
--> statement-breakpoint
ALTER TABLE `subscriptions` ADD CONSTRAINT `subscriptions_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;
CREATE TABLE `paymentHistory` (
	`id` varchar(255) NOT NULL,
	`stripePaymentIntentId` varchar(255),
	`stripeCheckoutSessionId` varchar(255),
	`stripeInvoiceId` varchar(255),
	`userId` int NOT NULL,
	`stripeSubscriptionId` varchar(255),
	`itemName` varchar(120) NOT NULL,
	`amountTotal` bigint NOT NULL,
	`currency` varchar(8) NOT NULL,
	`paymentStatus` varchar(32) NOT NULL,
	`eventCreatedAt` timestamp NOT NULL,
	CONSTRAINT `paymentHistory_id` PRIMARY KEY(`id`),
	CONSTRAINT `paymentHistory_stripePaymentIntentId_unique` UNIQUE(`stripePaymentIntentId`),
	CONSTRAINT `paymentHistory_stripeCheckoutSessionId_unique` UNIQUE(`stripeCheckoutSessionId`),
	CONSTRAINT `paymentHistory_stripeInvoiceId_unique` UNIQUE(`stripeInvoiceId`)
);
--> statement-breakpoint
ALTER TABLE `paymentHistory` ADD CONSTRAINT `paymentHistory_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `paymentHistory_user_created_idx` ON `paymentHistory` (`userId`,`eventCreatedAt`);
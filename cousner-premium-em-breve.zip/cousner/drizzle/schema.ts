import { bigint, boolean, index, int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const subscriptionStatuses = ["active", "trialing", "past_due", "canceled", "incomplete", "unpaid", "paused"] as const;
export type SubscriptionStatus = (typeof subscriptionStatuses)[number];

export const subscriptions = mysqlTable("subscriptions", {
  userId: int("userId").primaryKey().notNull().references(() => users.id, { onDelete: "cascade" }),
  stripeCustomerId: varchar("stripeCustomerId", { length: 255 }),
  stripeSubscriptionId: varchar("stripeSubscriptionId", { length: 255 }).unique(),
  priceId: varchar("priceId", { length: 255 }),
  status: mysqlEnum("status", subscriptionStatuses).default("incomplete").notNull(),
  currentPeriodEnd: timestamp("currentPeriodEnd"),
  cancelAtPeriodEnd: boolean("cancelAtPeriodEnd").default(false).notNull(),
  lastStripeEventCreated: int("lastStripeEventCreated").default(0).notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Subscription = typeof subscriptions.$inferSelect;
export type InsertSubscription = typeof subscriptions.$inferInsert;

export const stripeWebhookEvents = mysqlTable("stripeWebhookEvents", {
  eventId: varchar("eventId", { length: 255 }).primaryKey(),
  eventType: varchar("eventType", { length: 120 }).notNull(),
  eventCreated: int("eventCreated").notNull(),
  processedAt: timestamp("processedAt").defaultNow().notNull(),
});


export const paymentHistory = mysqlTable("paymentHistory", {
  id: varchar("id", { length: 255 }).primaryKey(),
  stripePaymentIntentId: varchar("stripePaymentIntentId", { length: 255 }).unique(),
  stripeCheckoutSessionId: varchar("stripeCheckoutSessionId", { length: 255 }).unique(),
  stripeInvoiceId: varchar("stripeInvoiceId", { length: 255 }).unique(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  stripeSubscriptionId: varchar("stripeSubscriptionId", { length: 255 }),
  itemName: varchar("itemName", { length: 120 }).notNull(),
  amountTotal: bigint("amountTotal", { mode: "number" }).notNull(),
  currency: varchar("currency", { length: 8 }).notNull(),
  paymentStatus: varchar("paymentStatus", { length: 32 }).notNull(),
  eventCreatedAt: timestamp("eventCreatedAt").notNull(),
}, table => [index("paymentHistory_user_created_idx").on(table.userId, table.eventCreatedAt)]);

export type PaymentHistory = typeof paymentHistory.$inferSelect;
export type InsertPaymentHistory = typeof paymentHistory.$inferInsert;

export const checkoutIntentStatuses = ["pending", "fulfilled", "failed"] as const;
export type CheckoutIntentStatus = (typeof checkoutIntentStatuses)[number];

export const checkoutIntents = mysqlTable("checkoutIntents", {
  id: varchar("id", { length: 64 }).primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  priceId: varchar("priceId", { length: 255 }).notNull(),
  stripeCheckoutSessionId: varchar("stripeCheckoutSessionId", { length: 255 }).unique(),
  stripeCustomerId: varchar("stripeCustomerId", { length: 255 }),
  stripeSubscriptionId: varchar("stripeSubscriptionId", { length: 255 }).unique(),
  status: mysqlEnum("status", checkoutIntentStatuses).default("pending").notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [index("checkoutIntents_user_created_idx").on(table.userId, table.createdAt)]);

export type CheckoutIntent = typeof checkoutIntents.$inferSelect;
export type InsertCheckoutIntent = typeof checkoutIntents.$inferInsert;

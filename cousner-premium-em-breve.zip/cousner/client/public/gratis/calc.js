/*
 * Cousner — contas financeiras (sem tela).
 * Todas as taxas são decimais (0,01 = 1%).
 * Este arquivo roda no navegador (window.CB) e no Node (module.exports), para poder ser testado.
 */
(function (root) {
  "use strict";

  /* ---------- taxas e prazos ---------- */

  /** Converte uma taxa para a taxa mensal equivalente. 12% a.a. ≈ 0,9489% a.m. */
  function toMonthlyRate(rate, unit) {
    return unit === "month" ? rate : Math.pow(1 + rate, 1 / 12) - 1;
  }

  function toAnnualRate(monthly) {
    return Math.pow(1 + monthly, 12) - 1;
  }

  function toMonths(value, unit) {
    return Math.round(unit === "year" ? value * 12 : value);
  }

  /* ---------- simulação ---------- */

  /** Simulação mês a mês. O aporte entra no fim de cada mês. */
  function simulate(initial, monthly, monthlyRate, months) {
    var pts = [{ month: 0, invested: initial, contributions: 0, interest: 0, total: initial, interestInPeriod: 0 }];
    var total = initial;
    var contributions = 0;
    for (var m = 1; m <= months; m++) {
      var gain = total * monthlyRate;
      total = total + gain + monthly;
      contributions += monthly;
      var invested = initial + contributions;
      pts.push({ month: m, invested: invested, contributions: contributions, interest: total - invested, total: total, interestInPeriod: gain });
    }
    return pts;
  }

  /** Aporte mensal necessário para chegar em `target` partindo de `initial` em `months` meses. */
  function requiredMonthly(initial, target, r, months) {
    if (months <= 0) return 0;
    var fvInitial = initial * Math.pow(1 + r, months);
    var remaining = target - fvInitial;
    if (remaining <= 0) return 0;
    if (r === 0) return remaining / months;
    return (remaining * r) / (Math.pow(1 + r, months) - 1);
  }

  /** Agrupa os meses em anos (guarda o último mês de cada ano). */
  function aggregate(points, byYear) {
    var out = [];
    var i;
    if (!byYear) {
      for (i = 1; i < points.length; i++) out.push(Object.assign({}, points[i], { label: points[i].month }));
      return out;
    }
    var acc = 0;
    for (i = 1; i < points.length; i++) {
      var p = points[i];
      acc += p.interestInPeriod;
      if (p.month % 12 === 0 || i === points.length - 1) {
        out.push(Object.assign({}, p, { interestInPeriod: acc, label: Math.ceil(p.month / 12) }));
        acc = 0;
      }
    }
    return out;
  }

  /* ---------- juros compostos ---------- */

  function calcCompound(i) {
    var monthlyRate = toMonthlyRate(i.rate, i.rateUnit);
    var months = toMonths(i.time, i.timeUnit);
    var points = simulate(i.initial, i.monthly, monthlyRate, months);
    return { points: points, final: points[points.length - 1], monthlyRate: monthlyRate, months: months, initial: i.initial, monthly: i.monthly };
  }

  /* ---------- aposentadoria ---------- */

  /** Modelo de renda: viver dos rendimentos (patrimônio × taxa mensal), preservando o patrimônio. */
  function calcRetirement(i) {
    var monthlyRate = toMonthlyRate(i.rate, i.rateUnit);
    var months = Math.round((i.retireAge - i.currentAge) * 12);
    var points = simulate(i.initial, i.monthly, monthlyRate, months);
    var final = points[points.length - 1];
    var requiredPatrimony = monthlyRate > 0 ? i.goalIncome / monthlyRate : Infinity;
    var estimatedIncome = final.total * monthlyRate;
    var hit = null;
    for (var k = 0; k < points.length; k++) {
      if (points[k].total >= requiredPatrimony) { hit = points[k]; break; }
    }
    return {
      points: points, final: final, monthlyRate: monthlyRate, months: months, initial: i.initial, monthly: i.monthly,
      currentAge: i.currentAge, retireAge: i.retireAge, goalIncome: i.goalIncome,
      requiredPatrimony: requiredPatrimony, estimatedIncome: estimatedIncome,
      gap: Math.max(0, requiredPatrimony - final.total),
      neededMonthly: requiredMonthly(i.initial, requiredPatrimony, monthlyRate, months),
      goalMonth: hit ? hit.month : null
    };
  }

  /* ---------- formatação pt-BR ---------- */

  var brl = new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" });
  var brlShort = new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL", notation: "compact", maximumFractionDigits: 1 });
  var pct = new Intl.NumberFormat("pt-BR", { style: "percent", minimumFractionDigits: 2, maximumFractionDigits: 4 });

  function formatBRL(v) { return isFinite(v) ? brl.format(v) : "—"; }
  function formatBRLShort(v) { return brlShort.format(v); }
  function formatPct(v) { return pct.format(v); }

  /** Lê "1,5" ou "1.234,56". Devolve NaN quando inválido. */
  function parseBR(s) {
    var t = String(s).trim().replace(/\s|%|R\$/g, "");
    if (!t) return NaN;
    var norm = t.indexOf(",") !== -1 ? t.replace(/\./g, "").replace(",", ".") : t;
    return /^-?\d*\.?\d+$/.test(norm) ? Number(norm) : NaN;
  }

  /** Como parseBR, mas para dinheiro: "1.000" e "1.234.567" (sem vírgula) são milhares, não decimais. */
  function parseMoney(s) {
    var t = String(s).trim().replace(/\s|R\$/g, "");
    if (t.indexOf(",") === -1 && /^[1-9]\d{0,2}(\.\d{3})+$/.test(t)) t = t.replace(/\./g, "");
    return parseBR(t);
  }

  function formatPeriod(months) {
    var y = Math.floor(months / 12), m = months % 12, parts = [];
    if (y) parts.push(y + " " + (y === 1 ? "ano" : "anos"));
    if (m) parts.push(m + " " + (m === 1 ? "mês" : "meses"));
    return parts.join(" e ") || "0 meses";
  }

  /* ---------- validação (devolve mensagens por campo) ---------- */

  var MAX_MONEY = 1e12;

  function vMoney(v, label, errs, key, opts) {
    opts = opts || {};
    var n = String(v).trim() === "" && !opts.required ? 0 : parseMoney(v);
    if (isNaN(n)) errs[key] = "Informe " + label + " válido.";
    else if (n < 0) errs[key] = "O valor não pode ser negativo.";
    else if (opts.required && n <= 0) errs[key] = "Informe " + label + " maior que zero.";
    else if (n > MAX_MONEY) errs[key] = "Valor muito alto. Use um valor menor.";
    return n;
  }

  function vRate(v, unit, errs, key) {
    key = key || "rate";
    var n = parseBR(v);
    var max = unit === "month" ? 20 : 500;
    if (isNaN(n)) errs[key] = "Informe uma rentabilidade válida.";
    else if (n < 0) errs[key] = "A rentabilidade não pode ser negativa.";
    else if (n > max) errs[key] = "Rentabilidade muito alta (máximo " + max + "% " + (unit === "month" ? "ao mês" : "ao ano") + ").";
    return n / 100;
  }

  function vInteger(v, errs, key, min, max, msg) {
    var n = parseBR(v);
    if (isNaN(n) || Math.floor(n) !== n || n < min || n > max) errs[key] = msg;
    return n;
  }

  /* ---------- investimentos pré-definidos ---------- */
  /* As taxas não ficam fixas aqui: a pessoa informa a taxa estimada. Para pré-preencher, troque `rate` (decimal). */

  var INVESTMENTS = [
    { id: "poupanca", name: "Poupança", description: "Rendimento definido por regra do Banco Central.", rate: null, rateUnit: "month" },
    { id: "selic", name: "Tesouro Selic", description: "Título público atrelado à taxa Selic.", rate: null, rateUnit: "year" },
    { id: "cdi", name: "CDI", description: "Referência de CDBs e fundos de renda fixa.", rate: null, rateUnit: "year" },
    { id: "ibovespa", name: "Ibovespa", description: "Renda variável — rentabilidade não garantida.", rate: null, rateUnit: "year" },
    { id: "custom", name: "Personalizado", description: "Defina a taxa que preferir.", rate: null, rateUnit: "year" }
  ];

  var api = {
    toMonthlyRate: toMonthlyRate, toAnnualRate: toAnnualRate, toMonths: toMonths,
    simulate: simulate, requiredMonthly: requiredMonthly, aggregate: aggregate,
    calcCompound: calcCompound, calcRetirement: calcRetirement,
    formatBRL: formatBRL, formatBRLShort: formatBRLShort, formatPct: formatPct, formatPeriod: formatPeriod, parseBR: parseBR, parseMoney: parseMoney,
    vMoney: vMoney, vRate: vRate, vInteger: vInteger, INVESTMENTS: INVESTMENTS
  };

  root.CB = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);

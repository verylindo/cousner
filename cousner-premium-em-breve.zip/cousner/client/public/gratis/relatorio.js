/*
 * Cousner — Relatório de gastos em PDF.
 * Gera o PDF no próprio navegador (nada é enviado para servidor), com jsPDF + AutoTable carregados só quando a pessoa pede o relatório.
 * Recebe os números já calculados pela tela de gastos (gastos-ui.js) e só desenha.
 */
(function () {
  "use strict";

  var G = window.CBGastos;
  var URL_JSPDF = "https://cdn.jsdelivr.net/npm/jspdf@2.5.1/dist/jspdf.umd.min.js";
  var URL_TABLE = "https://cdn.jsdelivr.net/npm/jspdf-autotable@3.8.2/dist/jspdf.plugin.autotable.min.js";

  var NAVY = [20, 32, 26], GOLD = [212, 43, 53], GREEN = [19, 154, 73], INK = [28, 34, 58], MUTED = [105, 112, 138], LINE = [222, 226, 236], SOFT = [244, 246, 251];
  var MAX_ROWS = 1500;

  function loadScript(src) {
    return new Promise(function (resolve, reject) {
      var s = document.createElement("script");
      s.src = src; s.async = true; s.crossOrigin = "anonymous"; s.referrerPolicy = "no-referrer";
      s.onload = resolve; s.onerror = function () { reject(new Error("load:" + src)); };
      document.head.appendChild(s);
    });
  }

  function loadLibs() {
    var p = Promise.resolve();
    if (!(window.jspdf && window.jspdf.jsPDF)) p = p.then(function () { return loadScript(URL_JSPDF); });
    return p.then(function () {
      if (!(window.jspdf.jsPDF.API && window.jspdf.jsPDF.API.autoTable)) return loadScript(URL_TABLE);
    });
  }

  /** A fonte padrão do PDF não tem alguns símbolos; troca por equivalentes simples. */
  function t(s) {
    return String(s == null ? "" : s).replace(/[  ]/g, " ").replace(/[−–]/g, "-").replace(/[“”]/g, '"').replace(/[‘’]/g, "'").replace(/[▲▼]/g, "");
  }
  function money(cents) { return t(G.fmt(cents)); }
  function hex(h) { var m = /^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(h || ""); return m ? [parseInt(m[1], 16), parseInt(m[2], 16), parseInt(m[3], 16)] : MUTED; }

  function niceMax(v) {
    if (!(v > 0)) return 100;
    var p = Math.pow(10, Math.floor(Math.log10(v))), s = [1, 2, 2.5, 4, 5, 8, 10];
    for (var i = 0; i < s.length; i++) if (s[i] * p >= v) return s[i] * p;
    return 10 * p;
  }

  function build(c) {
    var jsPDF = window.jspdf.jsPDF;
    var doc = new jsPDF({ unit: "mm", format: "a4" });
    var W = 210, H = 297, M = 15, CW = W - 2 * M, y = 0;
    var now = new Date();
    var stamp = now.toLocaleDateString("pt-BR") + " às " + now.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });

    function ensure(h) { if (y + h > H - 20) { doc.addPage(); y = 18; } }
    function color(rgb) { doc.setTextColor(rgb[0], rgb[1], rgb[2]); }
    function fill(rgb) { doc.setFillColor(rgb[0], rgb[1], rgb[2]); }
    function section(title) {
      ensure(16);
      fill(GOLD); doc.rect(M, y, 1.6, 5.2, "F");
      doc.setFont("helvetica", "bold"); doc.setFontSize(12); color(INK); doc.text(t(title), M + 4.5, y + 4.3);
      y += 10;
    }
    function note(text) {
      doc.setFont("helvetica", "normal"); doc.setFontSize(9); color(MUTED);
      var lines = doc.splitTextToSize(t(text), CW);
      ensure(lines.length * 4.2 + 2); doc.text(lines, M, y + 3); y += lines.length * 4.2 + 4;
    }
    function table(opts) {
      doc.autoTable(Object.assign({
        startY: y, theme: "striped", margin: { left: M, right: M, bottom: 22 },
        styles: { font: "helvetica", fontSize: 8.5, cellPadding: 2.2, textColor: INK, lineColor: LINE },
        headStyles: { fillColor: NAVY, textColor: 255, fontStyle: "bold" },
        alternateRowStyles: { fillColor: SOFT }
      }, opts));
      y = doc.lastAutoTable.finalY + 8;
    }

    /* ----- cabeçalho ----- */
    fill(NAVY); doc.rect(0, 0, W, 28, "F");
    doc.setFont("helvetica", "bold"); doc.setFontSize(19); doc.setTextColor(255, 255, 255); doc.text("COUS", M, 17.5);
    var wMon = doc.getTextWidth("COUS"); color(GREEN); doc.text("NER", M + wMon + 0.4, 17.5);
    doc.setFontSize(11); doc.setTextColor(255, 255, 255); doc.text("Relatório de gastos", W - M, 13, { align: "right" });
    doc.setFont("helvetica", "normal"); doc.setFontSize(8.5); doc.setTextColor(190, 196, 220); doc.text("Gerado em " + t(stamp), W - M, 19.5, { align: "right" });
    y = 40;

    doc.setFont("helvetica", "bold"); doc.setFontSize(18); color(INK); doc.text(t(c.per.cur.label), M, y);
    doc.setFont("helvetica", "normal"); doc.setFontSize(9.5); color(MUTED);
    doc.text(t(G.rangeText(c.per.cur)) + "  ·  gastos de consumo, sem investimentos e transferências", M, y + 6);
    y += 14;

    /* ----- números do período ----- */
    var cur = c.cur, gap = 4, cw = (CW - 3 * gap) / 4;
    var cards = [
      ["Gastos no período", money(cur.total), true],
      ["Despesas registradas", String(cur.count), false],
      ["Valor médio por despesa", cur.count ? money(cur.avg) : "-", false],
      ["Investimentos (separado)", money(cur.invest), false]
    ];
    cards.forEach(function (k, i) {
      var x = M + i * (cw + gap);
      fill(k[2] ? GOLD : SOFT); doc.roundedRect(x, y, cw, 21, 2.5, 2.5, "F");
      doc.setFont("helvetica", "normal"); doc.setFontSize(7.5); color(k[2] ? [255, 255, 255] : MUTED); doc.text(t(k[0]), x + 3.5, y + 6.5);
      var size = 13; doc.setFont("helvetica", "bold"); doc.setFontSize(size);
      while (doc.getTextWidth(k[1]) > cw - 7 && size > 8) { size -= 0.5; doc.setFontSize(size); }
      color(k[2] ? [255, 255, 255] : INK); doc.text(k[1], x + 3.5, y + 15);
    });
    y += 26;

    if (c.prev) {
      var line;
      if (c.prev.count > 0) {
        var d = G.compare(cur.total, c.prev.total);
        line = (d.diff === 0 ? "Igual ao " : (d.diff > 0 ? money(d.diff) + " a mais" : money(-d.diff) + " a menos") + (d.pct !== null ? " (" + (d.diff > 0 ? "+" : "-") + G.pct1(Math.abs(d.pct)) + ")" : "") + " que ") +
          c.per.prev.label + " (" + G.rangeText(c.per.prev) + ")";
      } else line = "Sem despesas em " + c.per.prev.label + " (" + G.rangeText(c.per.prev) + ") para comparar.";
      note("Comparação: " + line + ".");
    }
    if (cur.transfer > 0) note("Transferências entre contas no período: " + money(cur.transfer) + ". Não contam como gasto.");

    /* ----- categorias ----- */
    section("Gastos por categoria");
    if (!c.breakdown.length) note("Sem gastos de consumo no período.");
    else {
      var top = c.breakdown[0].value;
      c.breakdown.forEach(function (it) {
        ensure(8);
        fill(hex(c.colors[it.id])); doc.roundedRect(M, y - 2.6, 3, 3, 0.7, 0.7, "F");
        doc.setFont("helvetica", "normal"); doc.setFontSize(9); color(INK); doc.text(t(it.name), M + 5, y);
        var bx = M + 62, bw = 62;
        fill(LINE); doc.roundedRect(bx, y - 2.4, bw, 2.6, 1.2, 1.2, "F");
        fill(hex(c.colors[it.id])); doc.roundedRect(bx, y - 2.4, Math.max(1.6, bw * it.value / top), 2.6, 1.2, 1.2, "F");
        doc.setFont("helvetica", "bold"); doc.text(money(it.value), M + CW - 16, y, { align: "right" });
        doc.setFont("helvetica", "normal"); color(MUTED); doc.text(t(G.pct1(it.pct)), M + CW, y, { align: "right" });
        y += 7;
      });
      y += 3;
    }

    /* ----- fixas x variáveis ----- */
    var f = c.fv, ft = f.fixa + f.variavel;
    if (ft > 0) {
      section("Gastos fixos e variáveis");
      ensure(24);
      var pf = f.fixa / ft, BLUE = [91, 168, 245];
      fill(BLUE); doc.roundedRect(M, y, CW, 6, 2, 2, "F");
      if (pf > 0) { fill(GOLD); doc.roundedRect(M, y, Math.max(2, CW * pf), 6, 2, 2, "F"); }
      y += 12;
      [["Fixos", f.fixa, f.fixaCount, GOLD, pf * 100], ["Variáveis", f.variavel, f.variavelCount, BLUE, 100 - pf * 100]].forEach(function (r) {
        fill(r[3]); doc.roundedRect(M, y - 2.8, 3, 3, 0.7, 0.7, "F");
        doc.setFont("helvetica", "normal"); doc.setFontSize(9); color(INK);
        doc.text(r[0] + "  (" + r[2] + (r[2] === 1 ? " despesa" : " despesas") + ", " + t(G.pct1(r[4])) + ")", M + 5, y);
        doc.setFont("helvetica", "bold"); doc.text(money(r[1]), M + CW, y, { align: "right" });
        y += 6.5;
      });
      y += 4;
    }

    /* ----- evolução ----- */
    var series = cur.count ? G.buildSeries(c.occs, c.map, c.per.cur.fromD, c.per.cur.toD, G.autoGranularity(c.per.cur.fromD, c.per.cur.toD)) : null;
    if (series && series.length) {
      section("Evolução dos gastos");
      var ch = 44; ensure(ch + 14);
      var x0 = M + 20, cwid = CW - 20, max = 0, n = series.length;
      series.forEach(function (b) { max = Math.max(max, b.total); });
      var topV = niceMax(max * 1.05), base = y + ch;
      doc.setFont("helvetica", "normal"); doc.setFontSize(7); color(MUTED); doc.setDrawColor(LINE[0], LINE[1], LINE[2]); doc.setLineWidth(0.2);
      for (var g = 0; g <= 4; g++) {
        var gy = base - ch * g / 4;
        doc.line(x0, gy, x0 + cwid, gy);
        doc.text(t(G.fmtShort(topV * g / 4)), x0 - 2, gy + 1, { align: "right" });
      }
      var slot = cwid / n, bw2 = Math.max(0.6, slot * (n > 40 ? 0.85 : 0.6)), every = Math.max(1, Math.ceil(n / 10));
      series.forEach(function (b, i) {
        var bh = ch * b.total / topV, bx = x0 + i * slot + (slot - bw2) / 2;
        if (bh > 0) { fill(GOLD); doc.rect(bx, base - bh, bw2, bh, "F"); }
        if (i % every === 0) { color(MUTED); doc.text(t(b.label), x0 + i * slot + slot / 2, base + 4.5, { align: "center" }); }
      });
      y = base + 12;
    }

    /* ----- orçamento ----- */
    if (c.bud && c.bud.length) {
      section("Orçamento do mês atual");
      c.bud.forEach(function (b) {
        ensure(13);
        var col = b.level === "over" ? [212, 43, 53] : b.level === "warn" ? [196, 106, 12] : GREEN;
        doc.setFont("helvetica", "bold"); doc.setFontSize(9); color(INK); doc.text(t(b.name), M, y);
        doc.setFont("helvetica", "normal"); color(MUTED);
        doc.text(money(b.used) + " de " + money(b.limit) + "  ·  " + b.pct + "%", M + CW, y, { align: "right" });
        fill(LINE); doc.roundedRect(M, y + 2, CW, 2.6, 1.2, 1.2, "F");
        fill(col); doc.roundedRect(M, y + 2, Math.max(1.6, CW * Math.min(1, b.used / b.limit)), 2.6, 1.2, 1.2, "F");
        y += 11;
      });
      y += 2;
    }

    /* ----- maiores despesas ----- */
    if (c.top.length) {
      section("Maiores despesas");
      table({
        head: [["#", "Despesa", "Categoria", "Data", "Valor"]],
        body: c.top.map(function (o, i) { return [i + 1, t(o.name), t(c.catName(o.category)), G.brDate(o.date), money(o.amount)]; }),
        columnStyles: { 0: { cellWidth: 9 }, 3: { cellWidth: 24 }, 4: { halign: "right", cellWidth: 32, fontStyle: "bold" } },
        headStyles: { fillColor: NAVY, textColor: 255, fontStyle: "bold", halign: "left" },
        didParseCell: function (d) { if (d.section === "head" && d.column.index === 4) d.cell.styles.halign = "right"; }
      });
    }

    /* ----- lista completa ----- */
    if (c.rows.length) {
      section("Todas as despesas do período (" + c.rows.length + ")");
      var rows = c.rows.slice(0, MAX_ROWS);
      table({
        head: [["Data", "Despesa", "Categoria", "Pagamento", "Tipo", "Valor"]],
        body: rows.map(function (o) { return [G.brDate(o.date), t(o.name) + (o.recurring ? " (recorrente)" : ""), t(c.catName(o.category)), t(c.payName(o.payment)), t(c.kindName(o.kind)), money(o.amount)]; }),
        columnStyles: { 0: { cellWidth: 22 }, 3: { cellWidth: 22 }, 4: { cellWidth: 18 }, 5: { halign: "right", cellWidth: 30, fontStyle: "bold" } },
        headStyles: { fillColor: NAVY, textColor: 255, fontStyle: "bold", halign: "left" },
        didParseCell: function (d) { if (d.section === "head" && d.column.index === 5) d.cell.styles.halign = "right"; }
      });
      if (c.rows.length > MAX_ROWS) note("Lista limitada às " + MAX_ROWS + " despesas mais recentes. Use a planilha (CSV) para ver todas.");
    }

    /* ----- rodapé em todas as páginas ----- */
    var pages = doc.getNumberOfPages();
    for (var p = 1; p <= pages; p++) {
      doc.setPage(p);
      doc.setDrawColor(LINE[0], LINE[1], LINE[2]); doc.setLineWidth(0.3); doc.line(M, H - 15, W - M, H - 15);
      doc.setFont("helvetica", "normal"); doc.setFontSize(7.5); color(MUTED);
      doc.text("Cousner  ·  gerado em " + t(stamp), M, H - 10.5);
      doc.text("Página " + p + " de " + pages, W - M, H - 10.5, { align: "right" });
      doc.setFontSize(6.5); doc.text("Relatório educacional feito com os registros inseridos por você. Não é recomendação de investimento.", M, H - 6.5);
    }

    doc.save("cousner-relatorio-gastos-" + c.today + ".pdf");
  }

  window.CBRelatorio = {
    gerar: function (ctx) { return loadLibs().then(function () { build(ctx); }); }
  };
})();

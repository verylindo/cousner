/*
 * Cousner — Metas e cofrinhos.
 * Valores em centavos (inteiros). Os dados ficam só no navegador (localStorage).
 * Usa as contas de calc.js (juros compostos, aporte necessário) e os formatadores de gastos-core.js.
 */
(function () {
  "use strict";

  var G = window.CBGastos, CB = window.CB;
  if (!G || !CB) return;

  var KEY = "monevo.metas.v1";
  var MAX = G.MAX_AMOUNT_CENTS;
  var fmt = G.fmt;

  var $ = function (s, r) { return (r || document).querySelector(s); };
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function moneyInput(cents) { return (cents / 100).toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
  function toast(msg, kind) {
    var host = document.getElementById("toasts");
    if (!host) {
      host = document.createElement("div");
      host.className = "toasts"; host.id = "toasts";
      host.setAttribute("role", "status"); host.setAttribute("aria-live", "polite");
      document.body.appendChild(host);
    }
    var el = document.createElement("div");
    el.className = "toast " + (kind || "ok");
    el.textContent = msg;
    host.appendChild(el);
    setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, kind === "ok" ? 4000 : 8000);
  }

  /* ---------- dados ---------- */

  var storage = null;
  try { storage = window.localStorage; storage.getItem(KEY); } catch (e) { storage = null; }

  function emptyState() { return { version: 1, goals: [] }; }

  function sanitizeGoal(g) {
    if (!g || typeof g !== "object") return null;
    var name = String(g.name || "").trim().slice(0, 60);
    var target = Number(g.target), saved = Number(g.saved || 0), monthly = Number(g.monthly || 0), rate = Number(g.rate || 0);
    if (!name || !Number.isInteger(target) || target <= 0 || target > MAX) return null;
    if (!Number.isInteger(saved) || saved < 0 || saved > MAX) return null;
    if (!Number.isInteger(monthly) || monthly < 0 || monthly > MAX) return null;
    if (!(rate >= 0 && rate <= 1)) rate = 0;
    return {
      id: typeof g.id === "string" && g.id ? g.id.slice(0, 80) : G.uid(),
      name: name, target: target, saved: saved, monthly: monthly, rate: rate,
      deadline: g.deadline && !isNaN(G.toDays(g.deadline)) ? g.deadline : "",
      created: g.created && !isNaN(G.toDays(g.created)) ? g.created : G.todayStr()
    };
  }

  function sanitize(raw) {
    var st = emptyState(), ids = Object.create(null);
    if (raw && Array.isArray(raw.goals)) raw.goals.forEach(function (g) {
      var x = sanitizeGoal(g);
      if (x && !ids[x.id]) { ids[x.id] = true; st.goals.push(x); }
    });
    return st;
  }

  function load() {
    if (!storage) return emptyState();
    try { return sanitize(JSON.parse(storage.getItem(KEY))); } catch (e) { return emptyState(); }
  }

  var data = load();

  function save() {
    if (storage) { try { storage.setItem(KEY, JSON.stringify(data)); } catch (e) { toast("Não foi possível salvar neste navegador.", "err"); } }
  }

  /* ---------- contas de cada meta ---------- */

  /** Quantos meses de diferença entre duas datas (só ano e mês; mês atual = 0). */
  function monthsBetween(fromStr, toStr) {
    var a = fromStr.split("-"), b = toStr.split("-");
    return (+b[0] * 12 + +b[1]) - (+a[0] * 12 + +a[1]);
  }

  function analyse(g, today) {
    var r = CB.toMonthlyRate(g.rate, "year");
    var saved = g.saved / 100, target = g.target / 100, m = g.monthly / 100;
    var a = { pct: Math.min(100, Math.floor(g.saved * 100 / g.target)), left: Math.max(0, g.target - g.saved), done: g.saved >= g.target, rate: r };
    if (a.done) return a;
    var total = saved, n = 0;
    while (n < 1200 && total < target) { total = total * (1 + r) + m; n++; }
    a.reachable = total >= target;
    a.months = a.reachable ? n : null;
    a.date = a.reachable ? G.addMonths(today, n) : "";
    if (g.deadline) {
      var ml = monthsBetween(today, g.deadline);
      a.monthsLeft = ml;
      if (ml <= 0) { a.late = true; a.needed = null; }
      else {
        a.late = !(a.reachable && n <= ml);
        a.needed = Math.ceil(CB.requiredMonthly(saved, target, r, ml) * 100);
      }
    }
    return a;
  }

  /* ---------- tela ---------- */

  var ST = { editing: null, aportId: null, delId: null };

  function goalCard(g, today) {
    var a = analyse(g, today), tag, tagCls, lines = [];
    if (a.done) { tag = "Concluída"; tagCls = "ok"; lines.push("Parabéns! Você juntou o valor da meta."); }
    else {
      lines.push("Faltam <b>" + fmt(a.left) + "</b>.");
      if (a.reachable) lines.push("No ritmo atual" + (g.rate > 0 ? ", com o rendimento estimado," : "") + " você chega lá em <b>" + CB.formatPeriod(a.months) + "</b> (" + G.monthName(a.date) + ").");
      else lines.push("Com esse aporte, a meta não é alcançada. Defina um aporte mensal" + (g.rate > 0 ? "" : " ou uma rentabilidade") + " para ver a previsão.");
      if (g.deadline) {
        if (a.monthsLeft <= 0) lines.push("O prazo (" + G.brDate(g.deadline) + ") é este mês ou já passou. Edite a meta para definir uma nova data.");
        else if (a.late) lines.push("Para chegar até <b>" + G.brDate(g.deadline) + "</b>, guarde cerca de <b>" + fmt(a.needed) + "</b> por mês" + (a.needed > g.monthly ? " (" + fmt(a.needed - g.monthly) + " a mais que hoje)." : "."));
        else lines.push("Você chega antes do prazo de <b>" + G.brDate(g.deadline) + "</b>.");
      }
      if (g.deadline) { tag = a.late ? "Fora do ritmo" : "No prazo"; tagCls = a.late ? "over" : "ok"; }
      else if (a.reachable) { tag = "Em andamento"; tagCls = "ok"; }
      else { tag = "Sem previsão"; tagCls = "warn"; }
    }
    return '<article class="goal" data-id="' + esc(g.id) + '"><div class="goal-top"><h3>' + esc(g.name) + '</h3><span class="tag-s ' + tagCls + '">' + tag + "</span></div>" +
      '<div class="goal-nums"><b class="num">' + fmt(g.saved) + '</b><span>de ' + fmt(g.target) + '</span><span class="pc num">' + a.pct + "%</span></div>" +
      '<div class="track' + (a.done ? " done" : "") + '" role="progressbar" aria-label="Progresso de ' + esc(g.name) + '" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + a.pct + '"><i style="width:' + a.pct + '%"></i></div>' +
      '<ul class="goal-info">' + lines.map(function (l) { return "<li>" + l + "</li>"; }).join("") + "</ul>" +
      '<div class="goal-acts"><button type="button" class="btn small gold" data-aport="' + esc(g.id) + '">Registrar aporte</button><button type="button" class="btn small" data-edit="' + esc(g.id) + '">Editar</button><button type="button" class="btn small" data-del="' + esc(g.id) + '">Excluir</button></div></article>';
  }

  function render() {
    var host = $("#metas");
    var today = G.todayStr(), goals = data.goals.slice();
    goals.sort(function (a, b) { return (a.saved >= a.target) - (b.saved >= b.target); });

    var totSaved = 0, totTarget = 0, totMonthly = 0, doneCount = 0;
    data.goals.forEach(function (g) {
      totSaved += Math.min(g.saved, g.target); totTarget += g.target;
      if (g.saved >= g.target) doneCount++; else totMonthly += g.monthly;
    });

    var h = '<div class="toolbar"><div class="actions"><button type="button" class="btn gold" id="btnNewGoal">+ Nova meta</button></div></div>';
    if (!goals.length) {
      h += '<p class="empty"><b>Você ainda não criou nenhuma meta</b>Comece com uma: reserva de emergência, viagem, entrada de um carro ou imóvel. Informe quanto quer juntar e a Cousner mostra quando você chega lá.<br><button type="button" class="btn gold" id="btnNewGoal2">+ Criar minha primeira meta</button></p>';
    } else {
      h += '<div class="stats three"><div class="stat"><div class="l">Total guardado</div><div class="v num">' + fmt(totSaved) + '</div><div class="h">Soma de todas as metas</div></div>' +
        '<div class="stat"><div class="l">Falta juntar</div><div class="v num">' + fmt(Math.max(0, totTarget - totSaved)) + '</div><div class="h">' + doneCount + " de " + data.goals.length + (data.goals.length === 1 ? " meta concluída" : " metas concluídas") + '</div></div>' +
        '<div class="stat"><div class="l">Aporte mensal planejado</div><div class="v num">' + fmt(totMonthly) + '</div><div class="h">Soma dos aportes das metas em andamento</div></div></div>' +
        '<div class="goals">' + goals.map(function (g) { return goalCard(g, today); }).join("") + "</div>" +
        '<p class="note-line">As previsões são estimativas: usam juros compostos com o aporte no fim de cada mês, sem impostos, taxas ou inflação. Não são recomendação de investimento.</p>';
    }
    h += '<p class="storage-note">Suas metas ficam salvas só neste navegador, neste aparelho. Se você limpar os dados do navegador ou trocar de aparelho, elas não aparecem.</p>';
    host.innerHTML = h;
  }

  /* ---------- formulário da meta ---------- */

  var F = { name: "gName", target: "gTarget", saved: "gSaved", monthly: "gMonthly", rate: "gRate", deadline: "gDeadline" };

  function showErrors(errors) {
    var first = null;
    Object.keys(F).forEach(function (k) {
      var id = F[k], msg = errors[k] || "";
      $("#e-" + id).textContent = msg;
      $("#w-" + id).classList.toggle("err", !!msg);
      $("#" + id).setAttribute("aria-invalid", msg ? "true" : "false");
      if (msg && !first) first = id;
    });
    if (first) $("#" + first).focus();
  }

  function openForm(id) {
    var g = id ? data.goals.filter(function (x) { return x.id === id; })[0] : null;
    ST.editing = g ? g.id : null;
    $("#goalTitle").textContent = g ? "Editar meta" : "Nova meta";
    $("#gName").value = g ? g.name : "";
    $("#gTarget").value = g ? moneyInput(g.target) : "";
    $("#gSaved").value = g ? moneyInput(g.saved) : "";
    $("#gMonthly").value = g ? moneyInput(g.monthly) : "";
    $("#gRate").value = g && g.rate ? (g.rate * 100).toLocaleString("pt-BR", { maximumFractionDigits: 4 }) : "";
    $("#gDeadline").value = g ? g.deadline : "";
    showErrors({});
    var d = $("#dlgGoal"); if (!d.open) d.showModal();
    $("#gName").focus();
  }

  function money(text, allowEmpty) {
    if (allowEmpty && !String(text).trim()) return 0;
    return G.parseCents(text);
  }

  function saveGoal(ev) {
    ev.preventDefault();
    var err = {}, today = G.todayStr();
    var name = $("#gName").value.trim();
    if (!name) err.name = "Dê um nome para a meta."; else if (name.length > 60) err.name = "Use no máximo 60 caracteres.";
    var target = money($("#gTarget").value, false);
    if (isNaN(target)) err.target = "Informe um valor válido. Exemplo: 10.000,00";
    else if (target <= 0) err.target = "O valor da meta precisa ser maior que zero.";
    else if (target > MAX) err.target = "Valor muito alto. Use um valor menor.";
    var saved = money($("#gSaved").value, true);
    if (isNaN(saved)) err.saved = "Informe um valor válido ou deixe em branco."; else if (saved < 0 || saved > MAX) err.saved = "Valor fora do permitido.";
    var monthly = money($("#gMonthly").value, true);
    if (isNaN(monthly)) err.monthly = "Informe um valor válido ou deixe em branco."; else if (monthly < 0 || monthly > MAX) err.monthly = "Valor fora do permitido.";
    var rateTxt = $("#gRate").value.trim(), rate = 0;
    if (rateTxt) {
      var rn = CB.parseBR(rateTxt);
      if (isNaN(rn) || rn < 0) err.rate = "Informe uma rentabilidade válida ou deixe em branco.";
      else if (rn > 100) err.rate = "Rentabilidade muito alta (máximo 100% ao ano).";
      else rate = rn / 100;
    }
    var deadline = $("#gDeadline").value;
    if (deadline) {
      if (isNaN(G.toDays(deadline))) err.deadline = "Informe uma data válida.";
      else if (G.toDays(deadline) <= G.toDays(today)) err.deadline = "O prazo precisa ser depois de hoje.";
    }
    showErrors(err);
    if (Object.keys(err).length) return;

    var existing = ST.editing ? data.goals.filter(function (x) { return x.id === ST.editing; })[0] : null;
    var goal = { id: existing ? existing.id : G.uid(), name: name, target: target, saved: saved, monthly: monthly, rate: rate, deadline: deadline || "", created: existing ? existing.created : today };
    if (existing) data.goals = data.goals.map(function (x) { return x.id === goal.id ? goal : x; }); else data.goals.push(goal);
    save(); $("#dlgGoal").close(); render();
    toast(existing ? "Meta atualizada." : "Meta criada.", "ok");
  }

  /* ---------- aporte e exclusão ---------- */

  function openAport(id) {
    var g = data.goals.filter(function (x) { return x.id === id; })[0]; if (!g) return;
    ST.aportId = id;
    $("#aportTitle").textContent = "Registrar movimento: " + g.name;
    $("#aValue").value = g.monthly ? moneyInput(g.monthly) : "";
    $("#aIn").checked = true;
    $("#e-aValue").textContent = ""; $("#w-aValue").classList.remove("err");
    var d = $("#dlgAport"); if (!d.open) d.showModal();
    $("#aValue").focus();
  }

  function saveAport(ev) {
    ev.preventDefault();
    var g = data.goals.filter(function (x) { return x.id === ST.aportId; })[0]; if (!g) return;
    var v = G.parseCents($("#aValue").value), out = $("#aOut").checked, msg = "";
    if (isNaN(v) || v <= 0) msg = "Informe um valor maior que zero. Exemplo: 500,00";
    else if (v > MAX) msg = "Valor muito alto.";
    else if (out && v > g.saved) msg = "Você só pode retirar até " + fmt(g.saved) + ".";
    else if (!out && g.saved + v > MAX) msg = "Valor muito alto.";
    $("#e-aValue").textContent = msg; $("#w-aValue").classList.toggle("err", !!msg);
    if (msg) { $("#aValue").focus(); return; }
    g.saved += out ? -v : v;
    save(); $("#dlgAport").close(); render();
    toast(out ? "Retirada registrada." : (g.saved >= g.target ? "Aporte registrado. Meta concluída!" : "Aporte registrado."), "ok");
  }

  function askDelete(id) {
    var g = data.goals.filter(function (x) { return x.id === id; })[0]; if (!g) return;
    ST.delId = id;
    $("#cfText").textContent = "A meta “" + g.name + "” (" + fmt(g.saved) + " de " + fmt(g.target) + ") será excluída. Essa ação não pode ser desfeita.";
    $("#dlgConfirm").showModal(); $("#cfOk").focus();
  }

  /* ---------- eventos ---------- */

  document.addEventListener("click", function (e) {
    var b = e.target.closest && e.target.closest("button");
    if (!b) return;
    if (b.id === "btnNewGoal" || b.id === "btnNewGoal2") return openForm(null);
    if (b.hasAttribute("data-edit")) return openForm(b.getAttribute("data-edit"));
    if (b.hasAttribute("data-aport")) return openAport(b.getAttribute("data-aport"));
    if (b.hasAttribute("data-del")) return askDelete(b.getAttribute("data-del"));
    if (b.hasAttribute("data-close")) { var d = b.closest("dialog"); if (d) d.close(); }
  });
  $("#goalForm").addEventListener("submit", saveGoal);
  $("#aportForm").addEventListener("submit", saveAport);
  $("#cfOk").addEventListener("click", function () {
    data.goals = data.goals.filter(function (x) { return x.id !== ST.delId; });
    save(); $("#dlgConfirm").close(); render(); toast("Meta excluída.", "ok");
  });

  render();
})();

/*
 * Cousner — Calculadora de Gastos: regras e contas (sem tela).
 *
 * - Valores em CENTAVOS (números inteiros), para somar sem erro de arredondamento.
 * - Datas são texto "AAAA-MM-DD" e viram "número de dias" em UTC. Assim não existe
 *   problema de fuso horário nem de horário de verão na virada do dia, mês ou ano.
 * - Despesas recorrentes são guardadas uma vez só e viram uma ocorrência por mês na hora
 *   do cálculo (sem duplicar registros). Só entram nos totais ocorrências com data <= hoje.
 *
 * Roda no navegador (window.CBGastos) e no Node (module.exports), para poder ser testado.
 */
(function (root) {
  "use strict";

  var DAY = 86400000;
  var CB = root.CB;

  /* ---------- listas fixas ---------- */

  var DEFAULT_CATEGORIES = [
    { id: "moradia", name: "Moradia" },
    { id: "alimentacao", name: "Alimentação" },
    { id: "transporte", name: "Transporte" },
    { id: "saude", name: "Saúde" },
    { id: "educacao", name: "Educação" },
    { id: "lazer", name: "Lazer" },
    { id: "compras", name: "Compras pessoais" },
    { id: "assinaturas", name: "Assinaturas e serviços" },
    { id: "dividas", name: "Dívidas e juros" },
    { id: "impostos", name: "Impostos e taxas" },
    { id: "investimentos", name: "Investimentos e aplicações", noConsumption: true },
    { id: "outros", name: "Outros" },
    { id: "transferencias", name: "Transferências entre contas", noConsumption: true }
  ];

  /* Categorias de ganhos (listas separadas das de despesas). */
  var INCOME_CATEGORIES = [
    { id: "salario", name: "Salário" },
    { id: "freelance", name: "Freelance e serviços" },
    { id: "rendimentos", name: "Rendimentos de investimentos" },
    { id: "vendas", name: "Vendas" },
    { id: "beneficios", name: "Benefícios e auxílios" },
    { id: "presentes", name: "Presentes e reembolsos" },
    { id: "outros_ganhos", name: "Outros ganhos" }
  ];

  var PAYMENTS = [["dinheiro", "Dinheiro"], ["pix", "Pix"], ["debito", "Débito"], ["credito", "Crédito"], ["outro", "Outro"]];
  var KINDS = [["fixa", "Fixa"], ["variavel", "Variável"]];

  var MAX_AMOUNT_CENTS = 100000000 * 100; // R$ 100.000.000,00
  var MONTHS_SHORT = ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"];
  var MONTHS_LONG = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"];

  /* ---------- datas ---------- */

  function pad(n) { return n < 10 ? "0" + n : "" + n; }

  function parts(s) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(s));
    return m ? { y: +m[1], m: +m[2], d: +m[3] } : null;
  }

  function daysInMonth(y, m) { return new Date(Date.UTC(y, m, 0)).getUTCDate(); } // m = 1..12

  /** "AAAA-MM-DD" → dias desde 1970 (NaN se a data não existe, como 31/02). */
  function toDays(s) {
    var p = parts(s);
    if (!p || p.y < 1990 || p.y > 2100) return NaN;
    var t = Date.UTC(p.y, p.m - 1, p.d), dt = new Date(t);
    if (dt.getUTCFullYear() !== p.y || dt.getUTCMonth() !== p.m - 1 || dt.getUTCDate() !== p.d) return NaN;
    return Math.round(t / DAY);
  }

  function fromDays(n) {
    var d = new Date(n * DAY);
    return d.getUTCFullYear() + "-" + pad(d.getUTCMonth() + 1) + "-" + pad(d.getUTCDate());
  }

  /** Data de hoje no relógio do usuário (não em UTC). */
  function todayStr(now) {
    now = now || new Date();
    return now.getFullYear() + "-" + pad(now.getMonth() + 1) + "-" + pad(now.getDate());
  }

  /** Soma meses mantendo o "dia âncora"; dia 31 em mês curto vira o último dia do mês. */
  function addMonths(s, n, anchorDay) {
    var p = parts(s), idx = p.y * 12 + (p.m - 1) + n;
    var y = Math.floor(idx / 12), m = (idx % 12) + 1;
    return y + "-" + pad(m) + "-" + pad(Math.min(anchorDay || p.d, daysInMonth(y, m)));
  }

  function brDate(s) { var p = String(s).split("-"); return p[2] + "/" + p[1] + "/" + p[0]; }
  function brShort(days) { var p = parts(fromDays(days)); return pad(p.d) + "/" + pad(p.m); }
  function monthName(s) { var p = parts(s); return MONTHS_LONG[p.m - 1] + " de " + p.y; }

  /** Segunda-feira da semana de um dia. */
  function weekStart(days) { return days - ((new Date(days * DAY).getUTCDay() + 6) % 7); }

  /* ---------- dinheiro ---------- */

  function fmt(cents) { return CB.formatBRL(cents / 100); }
  function fmtShort(cents) { return CB.formatBRLShort(cents / 100); }

  /** Texto do formulário ("1.234,56") → centavos inteiros, ou NaN. */
  function parseCents(text) {
    var t = String(text).trim().replace(/\s|R\$/g, "");
    // "1.200" ou "1.200.000" (sem vírgula) é ponto de milhar, não decimal: R$ 1.200,00.
    if (t.indexOf(",") === -1 && /^[1-9]\d{0,2}(\.\d{3})+$/.test(t)) t = t.replace(/\./g, "");
    // Mais de duas casas decimais (ex.: "10,999"): recusa em vez de arredondar sem avisar.
    var dec = /[.,](\d+)$/.exec(t);
    if (dec && dec[1].length > 2) return NaN;
    var n = CB.parseBR(t);
    return isNaN(n) ? NaN : Math.round(n * 100);
  }

  function pct1(v) { return (Math.round(v * 10) / 10).toLocaleString("pt-BR", { minimumFractionDigits: 1, maximumFractionDigits: 1 }) + "%"; }

  /* ---------- categorias ---------- */

  function allCategories(custom) { return DEFAULT_CATEGORIES.concat(custom || []); }

  /** Objeto sem protótipo para usar como mapa: chaves como "__proto__" ou "constructor" viram chaves comuns. */
  function dict() { return Object.create(null); }

  function catMap(cats) {
    var m = dict();
    cats.forEach(function (c) { m[c.id] = c; });
    return m;
  }

  /* ---------- ocorrências (recorrência sem duplicar) ---------- */

  function occurrence(base, date, days) {
    var o = {};
    for (var k in base) o[k] = base[k];
    o.date = date; o.days = days; o.key = base.id + "@" + date;
    return o;
  }

  /**
   * Transforma os registros guardados em ocorrências.
   *  real   = ocorrências com data até hoje (entram nos totais)
   *  future = despesas únicas (ou recorrências que ainda não começaram) com data depois de hoje
   */
  function expand(expenses, today) {
    var td = toDays(today), real = [], future = [];
    expenses.forEach(function (e) {
      var base = { id: e.id, name: e.name, amount: e.amount, category: e.category, payment: e.payment, kind: e.kind, desc: e.desc || "", recurring: !!e.recurring, end: e.end || "", start: e.date };
      var d0 = toDays(e.date);
      if (isNaN(d0)) return;
      if (!e.recurring) { (d0 <= td ? real : future).push(occurrence(base, e.date, d0)); return; }
      var anchor = parts(e.date).d, endD = e.end ? toDays(e.end) : Infinity;
      for (var k = 0; k < 1200; k++) {
        var ds = addMonths(e.date, k, anchor), d = toDays(ds);
        if (d > endD) break;
        if (d > td) { if (k === 0) future.push(occurrence(base, ds, d)); break; }
        real.push(occurrence(base, ds, d));
      }
    });
    return { real: real, future: future };
  }

  /** Ganhos usam a mesma regra de recorrência das despesas (uma vez por mês, só até hoje). */
  function expandIncomes(incomes, today) { return expand(incomes || [], today); }

  function sumIncome(occs) {
    var t = 0;
    occs.forEach(function (o) { t += o.amount; });
    return t;
  }

  /* ---------- períodos e comparação ---------- */

  var PRESETS = [
    ["today", "Hoje"], ["7d", "Últimos 7 dias"], ["30d", "Últimos 30 dias"], ["month", "Este mês"],
    ["prevmonth", "Mês anterior"], ["year", "Este ano"], ["prevyear", "Ano anterior"], ["all", "Todo o histórico"], ["custom", "Personalizado"]
  ];

  function range(fromD, toD, label) { return { fromD: fromD, toD: toD, from: fromDays(fromD), to: fromDays(toD), label: label }; }

  function rangeText(r) { return r.fromD === r.toD ? brDate(r.from) : brDate(r.from) + " a " + brDate(r.to); }

  /**
   * Resolve o período escolhido e o período anterior equivalente (de mesmo tamanho).
   * "Este mês" e "Este ano" são comparados com o mesmo trecho do mês/ano anterior (1º dia até o mesmo número de dias).
   */
  function resolvePeriod(preset, today, custom, firstDate) {
    var t = toDays(today), p = parts(today), cur, prev = null, error = "";
    var monthFirst = function (y, m) { return toDays(y + "-" + pad(m) + "-01"); };
    var monthLast = function (y, m) { return toDays(y + "-" + pad(m) + "-" + pad(daysInMonth(y, m))); };
    var py, pm, len;

    switch (preset) {
      case "today":
        cur = range(t, t, "Hoje"); prev = range(t - 1, t - 1, "ontem"); break;
      case "7d":
        cur = range(t - 6, t, "Últimos 7 dias"); prev = range(t - 13, t - 7, "7 dias anteriores"); break;
      case "30d":
        cur = range(t - 29, t, "Últimos 30 dias"); prev = range(t - 59, t - 30, "30 dias anteriores"); break;
      case "month":
        cur = range(monthFirst(p.y, p.m), t, "Este mês");
        pm = parts(addMonths(p.y + "-" + pad(p.m) + "-01", -1, 1)); len = t - cur.fromD;
        prev = range(monthFirst(pm.y, pm.m), Math.min(monthFirst(pm.y, pm.m) + len, monthLast(pm.y, pm.m)), "mesmo trecho do mês anterior");
        break;
      case "prevmonth":
        pm = parts(addMonths(p.y + "-" + pad(p.m) + "-01", -1, 1));
        cur = range(monthFirst(pm.y, pm.m), monthLast(pm.y, pm.m), "Mês anterior");
        var pm2 = parts(addMonths(pm.y + "-" + pad(pm.m) + "-01", -1, 1));
        prev = range(monthFirst(pm2.y, pm2.m), monthLast(pm2.y, pm2.m), "mês retrasado");
        break;
      case "year":
        cur = range(toDays(p.y + "-01-01"), t, "Este ano"); len = t - cur.fromD; py = p.y - 1;
        prev = range(toDays(py + "-01-01"), Math.min(toDays(py + "-01-01") + len, toDays(py + "-12-31")), "mesmo trecho do ano anterior");
        break;
      case "prevyear":
        py = p.y - 1;
        cur = range(toDays(py + "-01-01"), toDays(py + "-12-31"), "Ano anterior");
        prev = range(toDays((py - 1) + "-01-01"), toDays((py - 1) + "-12-31"), "ano retrasado");
        break;
      case "all":
        cur = range(firstDate ? toDays(firstDate) : t, t, "Todo o histórico"); break;
      case "custom":
        var f = toDays(custom && custom.from), e = toDays(custom && custom.to);
        if (isNaN(f) || isNaN(e)) { error = "Escolha a data inicial e a data final."; cur = range(t, t, "Personalizado"); break; }
        if (f > e) { error = "A data inicial não pode ser depois da data final."; cur = range(t, t, "Personalizado"); break; }
        if (f > t) { error = "A data inicial é depois de hoje. Despesas futuras só entram nos totais a partir da data delas."; cur = range(t, t, "Personalizado"); break; }
        cur = range(f, Math.min(e, t), "Personalizado");
        len = cur.toD - cur.fromD + 1;
        prev = range(cur.fromD - len, cur.fromD - 1, "período anterior de mesmo tamanho");
        break;
      default:
        cur = range(t, t, "Hoje");
    }
    return { preset: preset, cur: cur, prev: prev, error: error };
  }

  function inRange(occs, r) { return occs.filter(function (o) { return o.days >= r.fromD && o.days <= r.toD; }); }

  /* ---------- resumos ---------- */

  function isConsumption(o, map) { var c = map[o.category]; return !(c && c.noConsumption); }

  /** Soma só o consumo. Investimentos e transferências ficam separados e não entram no total. */
  function summarize(occs, map) {
    var s = { total: 0, count: 0, avg: 0, invest: 0, investCount: 0, transfer: 0, transferCount: 0, byCat: dict() };
    occs.forEach(function (o) {
      if (o.category === "investimentos") { s.invest += o.amount; s.investCount++; return; }
      if (o.category === "transferencias") { s.transfer += o.amount; s.transferCount++; return; }
      if (!isConsumption(o, map)) return;
      s.total += o.amount; s.count++;
      s.byCat[o.category] = (s.byCat[o.category] || 0) + o.amount;
    });
    s.avg = s.count ? Math.round(s.total / s.count) : 0;
    return s;
  }

  function sumConsumption(occs, map) { return summarize(occs, map).total; }

  /** Lista de categorias com valor, participação (%) e quantidade, da maior para a menor. */
  function categoryBreakdown(occs, cats) {
    var map = catMap(cats), totals = dict(), counts = dict(), total = 0;
    occs.forEach(function (o) {
      if (!isConsumption(o, map)) return;
      totals[o.category] = (totals[o.category] || 0) + o.amount;
      counts[o.category] = (counts[o.category] || 0) + 1;
      total += o.amount;
    });
    var out = Object.keys(totals).map(function (id) {
      var idx = 0; for (var i = 0; i < cats.length; i++) if (cats[i].id === id) idx = i;
      return { id: id, name: (map[id] || { name: "Outros" }).name, value: totals[id], count: counts[id], pct: total ? totals[id] / total * 100 : 0, index: idx };
    });
    out.sort(function (a, b) { return b.value - a.value || a.name.localeCompare(b.name, "pt-BR"); });
    return out;
  }

  function fixedVariable(occs, map) {
    var r = { fixa: 0, variavel: 0, fixaCount: 0, variavelCount: 0 };
    occs.forEach(function (o) {
      if (!isConsumption(o, map)) return;
      var k = o.kind === "fixa" ? "fixa" : "variavel";
      r[k] += o.amount; r[k + "Count"]++;
    });
    return r;
  }

  function topExpenses(occs, map, n) {
    return occs.filter(function (o) { return isConsumption(o, map); })
      .sort(function (a, b) { return b.amount - a.amount || b.days - a.days || a.name.localeCompare(b.name, "pt-BR"); })
      .slice(0, n);
  }

  function compare(cur, prev) {
    var diff = cur - prev;
    return { diff: diff, pct: prev > 0 ? diff / prev * 100 : null };
  }

  /* ---------- evolução no tempo ---------- */

  function autoGranularity(fromD, toD) {
    var len = toD - fromD + 1;
    return len <= 31 ? "day" : len <= 120 ? "week" : len <= 1100 ? "month" : "year";
  }

  /** Divide o período em dias, semanas (seg-dom), meses ou anos e soma o consumo de cada um. */
  function buildSeries(occs, map, fromD, toD, gran, incOccs) {
    var buckets = [], i, d, s, y, m;
    if (gran === "day") {
      for (d = fromD; d <= toD; d++) buckets.push({ start: d, end: d, label: brShort(d), full: brDate(fromDays(d)) });
    } else if (gran === "week") {
      for (s = weekStart(fromD); s <= toD; s += 7) buckets.push({ start: s, end: s + 6, label: brShort(s), full: "Semana de " + brShort(s) + " a " + brShort(s + 6) });
    } else if (gran === "month") {
      var a = parts(fromDays(fromD)), z = parts(fromDays(toD));
      for (y = a.y, m = a.m; y * 12 + m <= z.y * 12 + z.m; m++) {
        if (m > 12) { m = 1; y++; }
        buckets.push({ start: toDays(y + "-" + pad(m) + "-01"), end: toDays(y + "-" + pad(m) + "-" + pad(daysInMonth(y, m))), label: MONTHS_SHORT[m - 1] + "/" + String(y).slice(2), full: MONTHS_LONG[m - 1].charAt(0).toUpperCase() + MONTHS_LONG[m - 1].slice(1) + " de " + y });
      }
    } else {
      var ya = parts(fromDays(fromD)).y, yz = parts(fromDays(toD)).y;
      for (y = ya; y <= yz; y++) buckets.push({ start: toDays(y + "-01-01"), end: toDays(y + "-12-31"), label: String(y), full: String(y) });
    }
    buckets.forEach(function (b) { b.total = 0; b.count = 0; b.income = 0; b.incCount = 0; });
    occs.forEach(function (o) {
      if (!isConsumption(o, map) || o.days < fromD || o.days > toD) return;
      for (i = 0; i < buckets.length; i++) {
        if (o.days >= buckets[i].start && o.days <= buckets[i].end) { buckets[i].total += o.amount; buckets[i].count++; break; }
      }
    });
    (incOccs || []).forEach(function (o) {
      if (o.days < fromD || o.days > toD) return;
      for (i = 0; i < buckets.length; i++) {
        if (o.days >= buckets[i].start && o.days <= buckets[i].end) { buckets[i].income += o.amount; buckets[i].incCount++; break; }
      }
    });
    return buckets;
  }

  /** Ganhos por categoria, do maior para o menor, com participação (%). */
  function incomeBreakdown(occs) {
    var totals = dict(), counts = dict(), total = 0;
    occs.forEach(function (o) { totals[o.category] = (totals[o.category] || 0) + o.amount; counts[o.category] = (counts[o.category] || 0) + 1; total += o.amount; });
    var out = Object.keys(totals).map(function (id) {
      var idx = 0, name = "Outros ganhos";
      INCOME_CATEGORIES.forEach(function (c, i) { if (c.id === id) { idx = i; name = c.name; } });
      return { id: id, name: name, value: totals[id], count: counts[id], pct: total ? totals[id] / total * 100 : 0, index: idx };
    });
    out.sort(function (a, b) { return b.value - a.value || a.name.localeCompare(b.name, "pt-BR"); });
    return out;
  }

  /* ---------- orçamento ---------- */

  /** Uso do orçamento no mês de `today`. Aviso em 80% e em 100%, nunca bloqueia nada. */
  function budgetStatus(realOccs, budget, cats, today) {
    var p = parts(today), map = catMap(cats);
    var r = range(toDays(p.y + "-" + pad(p.m) + "-01"), toDays(today), "");
    var s = summarize(inRange(realOccs, r), map), items = [];
    function level(used, limit) { return used >= limit ? "over" : used * 5 >= limit * 4 ? "warn" : "ok"; }
    // Porcentagem com inteiros (centavos × 100 ÷ limite): 57 de 100 dá 57%, não 56% por erro de ponto flutuante.
    if (budget && budget.general > 0) items.push({ scope: "general", name: "Limite mensal geral", limit: budget.general, used: s.total, pct: Math.floor(s.total * 100 / budget.general), level: level(s.total, budget.general) });
    Object.keys((budget && budget.cats) || {}).forEach(function (id) {
      var limit = budget.cats[id];
      if (!(limit > 0) || !map[id] || map[id].noConsumption) return;
      var used = s.byCat[id] || 0;
      items.push({ scope: id, name: map[id].name, limit: limit, used: used, pct: Math.floor(used * 100 / limit), level: level(used, limit) });
    });
    return items;
  }

  /* ---------- validação do formulário ---------- */

  function validateExpense(v, cats, today) {
    var errors = {}, map = catMap(cats);
    var name = String(v.name || "").trim();
    if (!name) errors.name = "Informe o nome da despesa.";
    else if (name.length > 80) errors.name = "Use no máximo 80 caracteres.";
    var amount = parseCents(v.value);
    if (isNaN(amount)) errors.value = "Informe um valor válido. Exemplo: 1.234,56";
    else if (amount <= 0) errors.value = "O valor precisa ser maior que zero.";
    else if (amount > MAX_AMOUNT_CENTS) errors.value = "Valor muito alto. Use um valor menor.";
    if (!map[v.category]) errors.category = "Escolha uma categoria.";
    if (isNaN(toDays(v.date))) errors.date = "Informe uma data válida.";
    if (!PAYMENTS.some(function (p) { return p[0] === v.payment; })) errors.payment = "Escolha a forma de pagamento.";
    if (!KINDS.some(function (k) { return k[0] === v.kind; })) errors.kind = "Escolha fixa ou variável.";
    var desc = String(v.desc || "").trim();
    if (desc.length > 300) errors.desc = "Use no máximo 300 caracteres.";
    var end = "";
    if (v.recurring && v.end) {
      if (isNaN(toDays(v.end))) errors.end = "Informe uma data final válida.";
      else if (!errors.date && toDays(v.end) < toDays(v.date)) errors.end = "A data final não pode ser antes da primeira ocorrência.";
      else end = v.end;
    }
    return { errors: errors, ok: Object.keys(errors).length === 0, expense: { name: name, amount: amount, category: v.category, date: v.date, payment: v.payment, kind: v.kind, desc: desc, recurring: !!v.recurring, end: end } };
  }

  function validateIncome(v) {
    var errors = {};
    var name = String(v.name || "").trim();
    if (!name) errors.name = "Informe o nome do ganho.";
    else if (name.length > 80) errors.name = "Use no máximo 80 caracteres.";
    var amount = parseCents(v.value);
    if (isNaN(amount)) errors.value = "Informe um valor válido. Exemplo: 1.234,56";
    else if (amount <= 0) errors.value = "O valor precisa ser maior que zero.";
    else if (amount > MAX_AMOUNT_CENTS) errors.value = "Valor muito alto. Use um valor menor.";
    if (!INCOME_CATEGORIES.some(function (c) { return c.id === v.category; })) errors.category = "Escolha uma categoria.";
    if (isNaN(toDays(v.date))) errors.date = "Informe uma data válida.";
    var desc = String(v.desc || "").trim();
    if (desc.length > 300) errors.desc = "Use no máximo 300 caracteres.";
    var end = "";
    if (v.recurring && v.end) {
      if (isNaN(toDays(v.end))) errors.end = "Informe uma data final válida.";
      else if (!errors.date && toDays(v.end) < toDays(v.date)) errors.end = "A data final não pode ser antes da primeira ocorrência.";
      else end = v.end;
    }
    return { errors: errors, ok: Object.keys(errors).length === 0, income: { name: name, amount: amount, category: v.category, date: v.date, desc: desc, recurring: !!v.recurring, end: end } };
  }

  function validateCategoryName(name, cats) {
    name = String(name || "").trim();
    if (!name) return "Informe o nome da categoria.";
    if (name.length > 40) return "Use no máximo 40 caracteres.";
    var low = name.toLowerCase();
    for (var i = 0; i < cats.length; i++) if (cats[i].name.toLowerCase() === low) return "Essa categoria já existe.";
    return "";
  }

  /* ---------- armazenamento ---------- */

  var STORAGE_KEY = "crisbusiness.gastos.v1";

  function uid() {
    try { if (root.crypto && root.crypto.randomUUID) return root.crypto.randomUUID(); } catch (e) { /* segue */ }
    return "id" + Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
  }

  function emptyState() { return { version: 1, expenses: [], categories: [], incomes: [], budget: { general: 0, cats: {} } }; }

  function sanitizeExpense(e, map) {
    if (!e || typeof e !== "object") return null;
    var name = String(e.name || "").trim().slice(0, 80);
    var amount = Number(e.amount);
    if (!name || !Number.isInteger(amount) || amount <= 0 || amount > MAX_AMOUNT_CENTS) return null;
    if (isNaN(toDays(e.date))) return null;
    var end = e.end && !isNaN(toDays(e.end)) ? e.end : "";
    return {
      id: typeof e.id === "string" && e.id ? e.id.slice(0, 80) : uid(),
      name: name, amount: amount,
      category: map[e.category] ? e.category : "outros",
      date: e.date,
      payment: PAYMENTS.some(function (p) { return p[0] === e.payment; }) ? e.payment : "outro",
      kind: e.kind === "fixa" ? "fixa" : "variavel",
      desc: String(e.desc || "").trim().slice(0, 300),
      recurring: !!e.recurring, end: e.recurring ? end : ""
    };
  }

  function sanitizeIncome(e) {
    if (!e || typeof e !== "object") return null;
    var name = String(e.name || "").trim().slice(0, 80);
    var amount = Number(e.amount);
    if (!name || !Number.isInteger(amount) || amount <= 0 || amount > MAX_AMOUNT_CENTS) return null;
    if (isNaN(toDays(e.date))) return null;
    var end = e.end && !isNaN(toDays(e.end)) ? e.end : "";
    return {
      id: typeof e.id === "string" && e.id ? e.id.slice(0, 80) : uid(),
      name: name, amount: amount,
      category: INCOME_CATEGORIES.some(function (c) { return c.id === e.category; }) ? e.category : "outros_ganhos",
      date: e.date,
      desc: String(e.desc || "").trim().slice(0, 300),
      recurring: !!e.recurring, end: e.recurring ? end : ""
    };
  }

  function sanitizeState(raw) {
    var st = emptyState(), skipped = 0;
    if (!raw || typeof raw !== "object") return { state: st, skipped: 0 };
    var nameToId = dict(), idSeen = dict(), remap = dict();
    DEFAULT_CATEGORIES.forEach(function (c) { nameToId[c.name.toLowerCase()] = c.id; idSeen[c.id] = true; });
    (Array.isArray(raw.categories) ? raw.categories : []).forEach(function (c) {
      if (!c || typeof c.id !== "string" || c.id.indexOf("c_") !== 0) return;
      var name = String(c.name || "").trim().slice(0, 40), id = c.id.slice(0, 60), key = name.toLowerCase();
      if (!name) return;
      if (nameToId[key]) { if (nameToId[key] !== c.id) remap[c.id] = nameToId[key]; return; } // mesmo nome: usa a categoria que já existe
      if (idSeen[id]) return;
      if (id !== c.id) remap[c.id] = id;
      nameToId[key] = id; idSeen[id] = true;
      st.categories.push({ id: id, name: name });
    });
    var map = catMap(allCategories(st.categories)), ids = dict();
    (Array.isArray(raw.expenses) ? raw.expenses : []).forEach(function (e) {
      if (e && typeof e === "object" && typeof e.category === "string" && remap[e.category]) e = Object.assign({}, e, { category: remap[e.category] });
      var x = sanitizeExpense(e, map);
      if (!x || ids[x.id]) { skipped++; return; }
      ids[x.id] = true; st.expenses.push(x);
    });
    var incIds = dict();
    (Array.isArray(raw.incomes) ? raw.incomes : []).forEach(function (e) {
      var x = sanitizeIncome(e);
      if (!x || incIds[x.id]) { skipped++; return; }
      incIds[x.id] = true; st.incomes.push(x);
    });
    var b = raw.budget || {};
    st.budget.general = Number.isInteger(b.general) && b.general > 0 && b.general <= MAX_AMOUNT_CENTS ? b.general : 0;
    Object.keys(b.cats || {}).forEach(function (id) {
      var v = b.cats[id], tid = remap[id] || id;
      if (map[tid] && !map[tid].noConsumption && Number.isInteger(v) && v > 0 && v <= MAX_AMOUNT_CENTS && !st.budget.cats[tid]) st.budget.cats[tid] = v;
    });
    return { state: st, skipped: skipped };
  }

  /** Lê do armazenamento. `status`: "ok" | "unavailable" | "corrupt" */
  function load(storage) {
    if (!storage) return { state: emptyState(), status: "unavailable" };
    var raw;
    try { raw = storage.getItem(STORAGE_KEY); } catch (e) { return { state: emptyState(), status: "unavailable" }; }
    if (!raw) return { state: emptyState(), status: "ok" };
    try { return { state: sanitizeState(JSON.parse(raw)).state, status: "ok" }; }
    catch (e) {
      try { storage.setItem(STORAGE_KEY + ".corrompido", raw); } catch (e2) { /* segue */ }
      return { state: emptyState(), status: "corrupt" };
    }
  }

  function save(storage, state) {
    if (!storage) return false;
    try { storage.setItem(STORAGE_KEY, JSON.stringify(state)); return true; } catch (e) { return false; }
  }

  /** Junta um backup ao que já existe: só entra o que ainda não está aqui (por id). */
  function mergeImport(state, text) {
    var raw = JSON.parse(text), src = raw && raw.data ? raw.data : raw;
    var res = sanitizeState(src), added = 0, have = dict();
    state.expenses.forEach(function (e) { have[e.id] = true; });
    if (!state.incomes) state.incomes = [];
    var haveInc = dict(), addedInc = 0;
    state.incomes.forEach(function (e) { haveInc[e.id] = true; });
    // Categorias: mesmo nome = mesma categoria (as despesas importadas passam para a que já existe).
    // Mesmo id com nome diferente = categoria nova com id novo (não mistura com a de quem importa).
    var localByName = dict(), localById = dict(), remap = dict();
    DEFAULT_CATEGORIES.forEach(function (c) { localByName[c.name.toLowerCase()] = c.id; localById[c.id] = c; });
    state.categories.forEach(function (c) { localByName[c.name.toLowerCase()] = c.id; localById[c.id] = c; });
    res.state.categories.forEach(function (c) {
      var key = c.name.toLowerCase();
      if (localByName[key]) { remap[c.id] = localByName[key]; return; }
      var id = c.id;
      if (localById[id]) { id = "c_" + uid(); remap[c.id] = id; }
      var nc = { id: id, name: c.name };
      state.categories.push(nc); localById[id] = nc; localByName[key] = id;
    });
    var map = catMap(allCategories(state.categories));
    res.state.expenses.forEach(function (e) {
      if (have[e.id]) return;
      if (remap[e.category]) e.category = remap[e.category];
      if (!map[e.category]) e.category = "outros";
      state.expenses.push(e); have[e.id] = true; added++;
    });
    res.state.incomes.forEach(function (e) {
      if (haveInc[e.id]) return;
      state.incomes.push(e); haveInc[e.id] = true; addedInc++;
    });
    if (!state.budget.general && res.state.budget.general) state.budget.general = res.state.budget.general;
    Object.keys(res.state.budget.cats).forEach(function (id) {
      var tid = remap[id] || id;
      if (map[tid] && !state.budget.cats[tid]) state.budget.cats[tid] = res.state.budget.cats[id];
    });
    return { added: added, addedIncomes: addedInc, skipped: res.skipped + (res.state.expenses.length - added) + (res.state.incomes.length - addedInc) };
  }

  function csvCell(v) {
    var s = String(v == null ? "" : v);
    if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; // evita fórmulas ao abrir no Excel
    return '"' + s.replace(/"/g, '""') + '"';
  }

  function toCSV(state) {
    var map = catMap(allCategories(state.categories));
    var incMap = catMap(INCOME_CATEGORIES);
    var rows = [["Movimento", "Nome", "Valor", "Categoria", "Data", "Forma de pagamento", "Tipo", "Recorrente (mensal)", "Termina em", "Descrição"]];
    state.expenses.forEach(function (e) {
      var pay = PAYMENTS.filter(function (p) { return p[0] === e.payment; })[0];
      rows.push(["Despesa", e.name, (e.amount / 100).toFixed(2).replace(".", ","), (map[e.category] || {}).name || "Outros", brDate(e.date), pay ? pay[1] : "Outro", e.kind === "fixa" ? "Fixa" : "Variável", e.recurring ? "Sim" : "Não", e.end ? brDate(e.end) : "", e.desc]);
    });
    (state.incomes || []).forEach(function (e) {
      rows.push(["Ganho", e.name, (e.amount / 100).toFixed(2).replace(".", ","), (incMap[e.category] || {}).name || "Outros ganhos", brDate(e.date), "", "", e.recurring ? "Sim" : "Não", e.end ? brDate(e.end) : "", e.desc]);
    });
    return "﻿" + rows.map(function (r) { return r.map(csvCell).join(";"); }).join("\r\n");
  }

  var api = {
    DEFAULT_CATEGORIES: DEFAULT_CATEGORIES, INCOME_CATEGORIES: INCOME_CATEGORIES, PAYMENTS: PAYMENTS, KINDS: KINDS, PRESETS: PRESETS, MAX_AMOUNT_CENTS: MAX_AMOUNT_CENTS,
    toDays: toDays, fromDays: fromDays, todayStr: todayStr, addMonths: addMonths, brDate: brDate, brShort: brShort, monthName: monthName, weekStart: weekStart, daysInMonth: daysInMonth,
    fmt: fmt, fmtShort: fmtShort, parseCents: parseCents, pct1: pct1,
    allCategories: allCategories, catMap: catMap, expand: expand, expandIncomes: expandIncomes, sumIncome: sumIncome, incomeBreakdown: incomeBreakdown,
    resolvePeriod: resolvePeriod, rangeText: rangeText, inRange: inRange,
    isConsumption: isConsumption, summarize: summarize, sumConsumption: sumConsumption, categoryBreakdown: categoryBreakdown,
    fixedVariable: fixedVariable, topExpenses: topExpenses, compare: compare,
    autoGranularity: autoGranularity, buildSeries: buildSeries, budgetStatus: budgetStatus,
    validateExpense: validateExpense, validateIncome: validateIncome, validateCategoryName: validateCategoryName,
    STORAGE_KEY: STORAGE_KEY, uid: uid, emptyState: emptyState, sanitizeState: sanitizeState, load: load, save: save, mergeImport: mergeImport, toCSV: toCSV
  };

  root.CBGastos = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);

/*
 * Cousner — telas da calculadora (formulários, resultados, gráfico e tabela).
 * As contas ficam em calc.js.
 */
(function () {
  "use strict";

  var C = window.CB;
  var $ = function (sel, root) { return (root || document).querySelector(sel); };

  var app = $("#app");
  if (!app || !C) return;

  /* ---------- estado ---------- */
  var S = {
    mode: document.body.getAttribute("data-mode") || null,
    c: { rate: { source: "custom", preset: "selic", value: "1", unit: "month" }, timeUnit: "year" },
    r: { rate: { source: "custom", preset: "selic", value: "8", unit: "year" } },
    result: { compound: null, retirement: null },
    chart: null
  };

  var ICON = {
    calc: '<svg viewBox="0 0 24 24"><rect x="5" y="3" width="14" height="18" rx="2.5"/><path d="M8.5 7.5h7M8.5 12h.01M12 12h.01M15.5 12h.01M8.5 16h.01M12 16h.01M15.5 16h.01"/></svg>',
    beach: '<svg viewBox="0 0 24 24"><path d="M3 18c2.5-3 5-3 7.5 0S15.5 21 18 18s2-2.5 3-3"/><path d="M12 14V4"/><path d="M6 8c1.5-3 4-4 6-4s4.5 1 6 4c-2-1.2-4-1.2-6 0-2-1.2-4-1.2-6 0z"/></svg>',
    back: '<svg viewBox="0 0 24 24"><path d="M19 12H5M11 6l-6 6 6 6"/></svg>',
    ok: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M8 12.5l3 3 5-6"/></svg>',
    warn: '<svg viewBox="0 0 24 24"><path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18h.01"/></svg>'
  };

  /* ---------- peças de HTML ---------- */

  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }

  function field(id, o) {
    return '<div class="field"><div class="input" id="w-' + id + '">' +
      (o.prefix ? "<span>" + o.prefix + "</span>" : "") +
      '<input id="' + id + '" aria-label="' + o.label + '" inputmode="' + (o.mode || "decimal") + '" value="' + esc(o.value || "") + '" placeholder="' + esc(o.placeholder || "") + '" autocomplete="off">' +
      (o.suffix ? "<span>" + o.suffix + "</span>" : "") +
      '</div><p class="msg" id="e-' + id + '" role="alert"></p></div>';
  }

  function block(title, hint, inner, cls) {
    return '<div class="block' + (cls ? " " + cls : "") + '"><h3>' + title + "</h3>" + (hint ? '<p class="hint">' + hint + "</p>" : "") + inner + "</div>";
  }

  function seg(name, options, value) {
    return '<div class="seg" role="group" data-seg="' + name + '">' + options.map(function (o) {
      return '<button type="button" data-v="' + o[0] + '" class="' + (o[0] === value ? "on" : "") + '">' + o[1] + "</button>";
    }).join("") + "</div>";
  }

  function findInv(id) {
    for (var i = 0; i < C.INVESTMENTS.length; i++) if (C.INVESTMENTS[i].id === id) return C.INVESTMENTS[i];
    return C.INVESTMENTS[0];
  }

  function rateBlockHTML(p) {
    var st = S[p].rate, inner = '<div class="stack">';
    inner += seg("src-" + p, [["preset", "Escolher um investimento"], ["custom", "Minha própria rentabilidade"]], st.source);
    if (st.source === "preset") {
      inner += '<div class="presets">' + C.INVESTMENTS.map(function (inv) {
        return '<button type="button" class="preset' + (st.preset === inv.id ? " on" : "") + '" data-preset="' + inv.id + '" data-p="' + p + '">' + inv.name + "</button>";
      }).join("") + "</div>";
      inner += '<p class="hint">' + findInv(st.preset).description + " Informe a taxa estimada que deseja considerar.</p>";
    }
    inner += '<div class="row">' + field(p + "-rate", { label: "Rentabilidade", suffix: "%", placeholder: "Ex.: 1", value: st.value }) +
      seg("unit-" + p, [["month", "Ao mês"], ["year", "Ao ano"]], st.unit) + "</div></div>";
    return block("Rentabilidade", "Como deseja definir a rentabilidade?", inner);
  }

  function renderRate(p) {
    var host = $("#rate-" + p), cur = $("#" + p + "-rate");
    if (cur) S[p].rate.value = cur.value;
    host.innerHTML = rateBlockHTML(p);
  }

  /* ---------- estrutura da tela ---------- */

  app.innerHTML =
    '<div class="hero"><h1 id="h1"></h1><p class="lead" id="lead"></p></div>' +
    '<div id="picker">' +
      '<h2 class="pick-title">O que você quer calcular?</h2>' +
      '<div class="modes">' +
        '<button type="button" class="mode main" data-mode-pick="compound"><div class="ico">' + ICON.calc + '</div><h3>Juros compostos</h3><p>Veja quanto seu dinheiro pode crescer ao longo do tempo.</p><span class="go">Começar →</span></button>' +
        '<button type="button" class="mode" data-mode-pick="retirement"><div class="ico">' + ICON.beach + '</div><h3>Planejamento para aposentadoria</h3><p>Descubra quanto você precisa investir para alcançar sua meta de aposentadoria.</p><span class="go">Começar →</span></button>' +
      "</div>" +
    "</div>" +
    '<div id="formArea" hidden>' +
      '<button type="button" class="back" id="back">' + ICON.back + " Trocar tipo de cálculo</button>" +
      '<form id="form-c" novalidate hidden>' +
        '<div class="grid2">' +
          block("Valor inicial", "Quanto você já tem para começar?", field("c-initial", { label: "Valor inicial", prefix: "R$", value: "1.000,00", placeholder: "0,00" })) +
          block("Aporte mensal", "Quanto você pretende investir por mês?", field("c-monthly", { label: "Aporte mensal", prefix: "R$", value: "500,00", placeholder: "0,00" })) +
        "</div>" +
        '<div id="rate-c"></div>' +
        block("Tempo", "Por quanto tempo você pretende investir?",
          '<div class="row">' + field("c-time", { label: "Tempo", mode: "numeric", value: "10", placeholder: "10" }) + '<div id="timeSeg"></div></div>') +
        '<button type="submit" class="calc">CALCULAR</button>' +
      "</form>" +
      '<form id="form-r" novalidate hidden>' +
        '<div class="grid2">' +
          block("Idade atual", "", field("r-age", { label: "Idade atual", mode: "numeric", suffix: "anos", value: "25" })) +
          block("Idade para se aposentar", "", field("r-retire", { label: "Idade desejada", mode: "numeric", suffix: "anos", value: "60" })) +
          block("Quanto você já possui investido?", "", field("r-initial", { label: "Valor investido", prefix: "R$", value: "5.000,00", placeholder: "0,00" })) +
          block("Quanto consegue investir por mês?", "", field("r-monthly", { label: "Aporte mensal", prefix: "R$", value: "1.000,00", placeholder: "0,00" })) +
        "</div>" +
        '<div id="rate-r"></div>' +
        block("Meta de aposentadoria", "Quanto você gostaria de receber por mês durante a aposentadoria?",
          field("r-goal", { label: "Renda mensal desejada", prefix: "R$", suffix: "/mês", value: "5.000,00" }) +
          '<p class="note">Consideramos que você viverá apenas dos rendimentos, preservando o patrimônio acumulado.</p>') +
        '<button type="submit" class="calc">CALCULAR</button>' +
      "</form>" +
    "</div>" +
    '<section id="results" hidden></section>';

  /* ---------- troca de modo ---------- */

  function setMode(mode) {
    S.mode = mode;
    var ret = mode === "retirement";
    $("#h1").innerHTML = ret ? "Planeje sua <em>aposentadoria</em>" : "Simule o crescimento do seu <em>dinheiro</em>";
    $("#lead").textContent = ret ? "Descubra quanto precisa investir para alcançar sua meta." : "Descubra quanto seus investimentos podem valer ao longo do tempo.";
    $("#picker").hidden = !!mode;
    $("#formArea").hidden = !mode;
    $("#form-c").hidden = mode !== "compound";
    $("#form-r").hidden = mode !== "retirement";
    showResults(false);
  }

  function renderTimeSeg() {
    $("#timeSeg").innerHTML = seg("time-c", [["month", "Meses"], ["year", "Anos"]], S.c.timeUnit);
  }

  /* ---------- cliques ---------- */

  app.addEventListener("click", function (e) {
    var t = e.target.closest("button");
    if (!t) return;

    if (t.hasAttribute("data-mode-pick")) { setMode(t.getAttribute("data-mode-pick")); return; }
    if (t.id === "back") { setMode(null); return; }

    if (t.hasAttribute("data-preset")) {
      var p = t.getAttribute("data-p"), inv = findInv(t.getAttribute("data-preset")), cur = $("#" + p + "-rate");
      if (cur) S[p].rate.value = cur.value;
      S[p].rate.preset = inv.id;
      S[p].rate.unit = inv.rateUnit;
      if (inv.rate != null) S[p].rate.value = String(inv.rate * 100).replace(".", ",");
      renderRate(p);
      return;
    }

    var g = t.closest("[data-seg]");
    if (!g) return;
    var name = g.getAttribute("data-seg"), v = t.getAttribute("data-v");
    if (name === "time-c") { S.c.timeUnit = v; renderTimeSeg(); return; }
    var kind = name.split("-")[0], pp = name.split("-")[1];
    var curIn = $("#" + pp + "-rate");
    if (curIn) S[pp].rate.value = curIn.value;
    if (kind === "src") S[pp].rate.source = v;
    if (kind === "unit") S[pp].rate.unit = v;
    renderRate(pp);
  });

  /* ---------- cálculo ---------- */

  function val(id) { return $("#" + id).value; }

  function showErrors(prefix, keys, errs) {
    keys.forEach(function (k) {
      var id = prefix + "-" + k, msg = errs[k] || "";
      $("#e-" + id).textContent = msg;
      $("#w-" + id).classList.toggle("err", !!msg);
      $("#" + id).setAttribute("aria-invalid", msg ? "true" : "false");
    });
    var first = keys.filter(function (k) { return errs[k]; })[0];
    if (first) $("#" + prefix + "-" + first).focus();
  }

  app.addEventListener("submit", function (e) {
    e.preventDefault();
    var errs = {};
    if (e.target.id === "form-c") {
      var st = S.c.rate, unit = S.c.timeUnit;
      var i = C.vMoney(val("c-initial"), "um valor inicial", errs, "initial");
      var m = C.vMoney(val("c-monthly"), "um aporte", errs, "monthly");
      var r = C.vRate(val("c-rate"), st.unit, errs, "rate");
      var t = C.vInteger(val("c-time"), errs, "time", 1, unit === "year" ? 100 : 1200,
        "Informe um período entre 1 e " + (unit === "year" ? "100 anos" : "1.200 meses") + ".");
      if (!errs.initial && !errs.monthly && i === 0 && m === 0) errs.monthly = "Informe um valor inicial ou um aporte mensal.";
      showErrors("c", ["initial", "monthly", "rate", "time"], errs);
      if (Object.keys(errs).length) return;
      S.result.compound = C.calcCompound({ initial: i, monthly: m, rate: r, rateUnit: st.unit, time: t, timeUnit: unit });
      showResults(true);
    } else if (e.target.id === "form-r") {
      var rs = S.r.rate;
      var a = C.vInteger(val("r-age"), errs, "age", 0, 110, "Informe uma idade válida.");
      var ra = C.vInteger(val("r-retire"), errs, "retire", 1, 120, "Informe uma idade válida.");
      if (!errs.age && !errs.retire && ra <= a) errs.retire = "A idade de aposentadoria deve ser maior que a idade atual.";
      var ri = C.vMoney(val("r-initial"), "um valor", errs, "initial");
      var rm = C.vMoney(val("r-monthly"), "um aporte", errs, "monthly");
      var rr = C.vRate(val("r-rate"), rs.unit, errs, "rate");
      if (!errs.rate && rr === 0) errs.rate = "Informe uma rentabilidade maior que zero.";
      var g = C.vMoney(val("r-goal"), "uma renda desejada", errs, "goal", { required: true });
      showErrors("r", ["age", "retire", "initial", "monthly", "rate", "goal"], errs);
      if (Object.keys(errs).length) return;
      S.result.retirement = C.calcRetirement({ currentAge: a, retireAge: ra, initial: ri, monthly: rm, rate: rr, rateUnit: rs.unit, goalIncome: g });
      showResults(true);
    }
  });

  /* ---------- resultados ---------- */

  function stat(label, value, hint, hero) {
    return '<div class="stat' + (hero ? " hero-stat" : "") + '"><div class="l">' + label + '</div><div class="v num">' + value + "</div>" + (hint ? '<div class="h">' + hint + "</div>" : "") + "</div>";
  }

  function panel(title, inner) {
    return '<section class="panel"><h3>' + title + "</h3>" + inner + "</section>";
  }

  function tableHTML(rows, byYear, ageStart) {
    var head = ageStart != null ? "Idade" : byYear ? "Ano" : "Mês";
    return '<div class="scroll"><table><thead><tr><th>' + head + "</th><th>Total investido</th><th>Rendimento no período</th><th>Rendimentos acumulados</th><th>Patrimônio</th></tr></thead><tbody class=\"num\">" +
      rows.map(function (p) {
        return "<tr><td>" + (ageStart != null ? (ageStart + p.label) + " anos" : p.label) + "</td><td>" + C.formatBRL(p.invested) + '</td><td class="up">' + C.formatBRL(p.interestInPeriod) + "</td><td>" + C.formatBRL(p.interest) + '</td><td class="tot">' + C.formatBRL(p.total) + "</td></tr>";
      }).join("") + "</tbody></table></div>";
  }

  var LEGEND = '<div class="legend"><span><i style="background:var(--gold)"></i>Patrimônio total</span><span><i style="background:var(--steel)"></i>Total investido</span></div>';

  function prepare(r, ageStart) {
    var byYear = r.months > 36 || ageStart != null;
    var rows = C.aggregate(r.points, byYear);
    var chartRows = (byYear
      ? [Object.assign({}, r.points[0], { label: 0 })].concat(rows)
      : r.points.map(function (p) { return Object.assign({}, p, { label: p.month }); }));
    return { byYear: byYear, rows: rows, chart: chartRows };
  }

  function showResults(scroll) {
    var host = $("#results"), key = S.mode, r = key && S.result[key];
    if (!r) { host.hidden = true; host.innerHTML = ""; S.chart = null; return; }
    var h = '<h2>Resultado da sua simulação</h2><div class="stack-lg">', f = r.final, d, xLabel, goal = null;

    if (key === "compound") {
      d = prepare(r);
      var annual = C.toAnnualRate(r.monthlyRate);
      h += '<div class="stats">' +
        stat("Patrimônio final", C.formatBRL(f.total), "Em " + C.formatPeriod(r.months), true) +
        stat("Total investido", C.formatBRL(f.invested), "Valor inicial + aportes") +
        stat("Total em rendimentos", C.formatBRL(f.interest), f.total > 0 ? C.formatPct(f.interest / f.total) + " do patrimônio" : "") +
        stat("Total de aportes", C.formatBRL(f.contributions), r.months + " aportes de " + C.formatBRL(r.monthly)) +
        "</div>" +
        '<p class="rate-line">Taxa equivalente: <b>' + C.formatPct(r.monthlyRate) + " ao mês</b> · <b>" + C.formatPct(annual) + " ao ano</b>" +
        (f.invested > 0 ? " · Seu dinheiro foi multiplicado por <b>" + (f.total / f.invested).toLocaleString("pt-BR", { maximumFractionDigits: 2 }) + "×</b>" : "") + "</p>";
      xLabel = function (x) { return (d.byYear ? "Ano " : "Mês ") + x; };
      h += panel("Evolução do patrimônio", LEGEND + '<div class="chart-host" id="chartHost"></div>');
      h += panel("Evolução " + (d.byYear ? "anual" : "mensal") + " detalhada", tableHTML(d.rows, d.byYear));
    } else {
      d = prepare(r, r.currentAge);
      var ok = r.gap <= 0, goalAge = r.goalMonth != null ? r.currentAge + r.goalMonth / 12 : null;
      h += '<div class="banner ' + (ok ? "ok" : "warn") + '">' + (ok ? ICON.ok : ICON.warn) + "<div>" +
        '<div class="t">' + (ok ? "Você está no caminho certo para atingir sua meta." : "Para atingir sua meta, considere aumentar seu aporte mensal.") + "</div>" +
        '<div class="d">' + (ok ? (goalAge != null ? "Você alcança a meta por volta dos " + Math.ceil(goalAge) + " anos." : "") :
          "Seria necessário investir cerca de " + C.formatBRL(r.neededMonthly) + " por mês para chegar lá aos " + r.retireAge + " anos.") + "</div></div></div>";
      h += '<div class="stats three">' +
        stat("Patrimônio estimado na aposentadoria", C.formatBRL(f.total), "Aos " + r.retireAge + " anos", true) +
        stat("Total investido", C.formatBRL(f.invested)) +
        stat("Total de rendimentos", C.formatBRL(f.interest)) +
        stat("Renda mensal estimada", C.formatBRL(r.estimatedIncome), "Meta: " + C.formatBRL(r.goalIncome) + "/mês") +
        stat("Patrimônio necessário", C.formatBRL(r.requiredPatrimony)) +
        stat("Quanto falta para a meta", ok ? "Meta atingida" : C.formatBRL(r.gap)) +
        "</div>";
      xLabel = function (x) { return (r.currentAge + x) + " anos"; };
      goal = { value: r.requiredPatrimony, x: r.goalMonth != null ? Math.ceil(r.goalMonth / 12) : null };
      h += panel("Evolução do patrimônio por idade", LEGEND + '<div class="chart-host" id="chartHost"></div>');
      h += panel("Evolução anual detalhada", tableHTML(d.rows, true, r.currentAge));
    }

    h += "</div>";
    host.innerHTML = h;
    host.hidden = false;
    S.chart = { rows: d.chart, xLabel: xLabel, goal: goal };
    drawChart();
    if (scroll) host.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  /* ---------- gráfico (SVG feito à mão) ---------- */

  var SVGNS = "http://www.w3.org/2000/svg";

  function niceMax(v) {
    if (!(v > 0)) return 1;
    var p = Math.pow(10, Math.floor(Math.log10(v))), steps = [1, 2, 2.5, 4, 5, 8, 10];
    for (var i = 0; i < steps.length; i++) if (steps[i] * p >= v) return steps[i] * p;
    return 10 * p;
  }

  function drawChart() {
    var host = $("#chartHost");
    if (!host || !S.chart) return;
    var rows = S.chart.rows, xLabel = S.chart.xLabel, goal = S.chart.goal;
    var w = Math.max(260, host.clientWidth), h = w < 520 ? 260 : 340;
    var L = 70, R = 12, T = 14, B = 32, iw = w - L - R, ih = h - T - B, N = Math.max(1, rows.length - 1);
    var maxV = 0;
    rows.forEach(function (p) { maxV = Math.max(maxV, p.total, p.invested); });
    var top = niceMax(maxV * 1.02);
    var X = function (i) { return L + (i / N) * iw; };
    var Y = function (v) { return T + ih - (v / top) * ih; };

    var s = "";
    for (var t = 0; t <= 4; t++) {
      var gv = top * t / 4, gy = Y(gv);
      s += '<line x1="' + L + '" x2="' + (w - R) + '" y1="' + gy + '" y2="' + gy + '" stroke="#B9C6BF" stroke-opacity=".45"/>';
      s += '<text x="' + (L - 8) + '" y="' + (gy + 4) + '" text-anchor="end" font-size="11" fill="#66736B" font-family="Poppins, sans-serif">' + C.formatBRLShort(gv) + "</text>";
    }
    var every = Math.max(1, Math.ceil(N / (w < 520 ? 4 : 7)));
    for (var i = 0; i <= N; i += every) {
      s += '<text x="' + X(i) + '" y="' + (h - 10) + '" text-anchor="' + (i === 0 ? "start" : "middle") + '" font-size="11" fill="#66736B" font-family="Poppins, sans-serif">' + xLabel(rows[i].label) + "</text>";
    }
    function path(key) { return rows.map(function (p, k) { return (k ? "L" : "M") + X(k).toFixed(1) + " " + Y(p[key]).toFixed(1); }).join(" "); }
    function area(key) { return path(key) + " L" + X(N).toFixed(1) + " " + Y(0).toFixed(1) + " L" + X(0).toFixed(1) + " " + Y(0).toFixed(1) + " Z"; }

    s += '<defs><linearGradient id="gTot" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#139A49" stop-opacity=".38"/><stop offset="1" stop-color="#139A49" stop-opacity="0"/></linearGradient>' +
      '<linearGradient id="gInv" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7B8780" stop-opacity=".55"/><stop offset="1" stop-color="#7B8780" stop-opacity=".05"/></linearGradient></defs>';
    s += '<path d="' + area("total") + '" fill="url(#gTot)"/><path d="' + area("invested") + '" fill="url(#gInv)"/>';
    s += '<path d="' + path("invested") + '" fill="none" stroke="#7B8780" stroke-width="2" stroke-linejoin="round"/>';
    s += '<path d="' + path("total") + '" fill="none" stroke="#139A49" stroke-width="2.6" stroke-linejoin="round"/>';

    if (goal && isFinite(goal.value) && goal.value <= top) {
      var gy2 = Y(goal.value);
      s += '<line x1="' + L + '" x2="' + (w - R) + '" y1="' + gy2 + '" y2="' + gy2 + '" stroke="#14201A" stroke-opacity=".75" stroke-dasharray="5 5"/>';
      s += '<text x="' + (L + 6) + '" y="' + (gy2 - 6) + '" font-size="12" fill="#14201A" font-family="Poppins, sans-serif">Meta</text>';
    }
    if (goal && goal.x != null) {
      for (var k = 0; k < rows.length; k++) {
        if (rows[k].label === goal.x) {
          s += '<line x1="' + X(k) + '" x2="' + X(k) + '" y1="' + T + '" y2="' + (T + ih) + '" stroke="#14201A" stroke-opacity=".75" stroke-dasharray="5 5"/>';
          break;
        }
      }
    }
    s += '<line id="guide" x1="0" x2="0" y1="' + T + '" y2="' + (T + ih) + '" stroke="#66736B" stroke-opacity=".6" visibility="hidden"/>';
    s += '<circle id="dotT" r="5" fill="#139A49" stroke="#FFFFFF" stroke-width="2" visibility="hidden"/>';
    s += '<circle id="dotI" r="4" fill="#7B8780" stroke="#FFFFFF" stroke-width="2" visibility="hidden"/>';
    var last = rows[N];
    s += '<circle cx="' + X(N) + '" cy="' + Y(last.total) + '" r="4.5" fill="#139A49" stroke="#FFFFFF" stroke-width="2"/>';

    host.innerHTML = '<svg viewBox="0 0 ' + w + " " + h + '" width="' + w + '" height="' + h + '" role="img" aria-label="Gráfico da evolução do patrimônio">' + s + '</svg><div class="tip" id="tip" hidden></div>';

    var svg = host.querySelector("svg"), tip = host.querySelector("#tip");
    var guide = svg.querySelector("#guide"), dotT = svg.querySelector("#dotT"), dotI = svg.querySelector("#dotI");

    function show(clientX) {
      var rect = svg.getBoundingClientRect();
      var k = Math.round(((clientX - rect.left) - L) / iw * N);
      k = Math.max(0, Math.min(N, k));
      var p = rows[k], x = X(k);
      guide.setAttribute("x1", x); guide.setAttribute("x2", x); guide.setAttribute("visibility", "visible");
      dotT.setAttribute("cx", x); dotT.setAttribute("cy", Y(p.total)); dotT.setAttribute("visibility", "visible");
      dotI.setAttribute("cx", x); dotI.setAttribute("cy", Y(p.invested)); dotI.setAttribute("visibility", "visible");
      tip.innerHTML = '<div class="tt">' + xLabel(p.label) + "</div>" +
        '<div class="tr"><span><i style="background:#7B8780"></i>Total investido</span><b>' + C.formatBRL(p.invested) + "</b></div>" +
        '<div class="tr"><span><i style="background:#139A49"></i>Rendimentos</span><b>' + C.formatBRL(p.interest) + "</b></div>" +
        '<div class="tr"><span><i style="background:#139A49"></i>Patrimônio</span><b>' + C.formatBRL(p.total) + "</b></div>";
      tip.hidden = false;
      var tw = tip.offsetWidth, left = x + 14;
      if (left + tw > w) left = x - tw - 14;
      tip.style.left = Math.max(0, left) + "px";
    }
    function hide() {
      guide.setAttribute("visibility", "hidden"); dotT.setAttribute("visibility", "hidden"); dotI.setAttribute("visibility", "hidden");
      tip.hidden = true;
    }
    svg.addEventListener("pointermove", function (e) { show(e.clientX); });
    svg.addEventListener("pointerdown", function (e) { show(e.clientX); });
    svg.addEventListener("pointerleave", hide);
  }

  var resizeTimer = null, lastW = 0;
  window.addEventListener("resize", function () {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(function () {
      var host = $("#chartHost");
      if (host && host.clientWidth !== lastW) { lastW = host.clientWidth; drawChart(); }
    }, 120);
  });

  /* ---------- início ---------- */
  renderRate("c");
  renderRate("r");
  renderTimeSeg();
  setMode(S.mode);
})();

/*
 * Cousner — Calculadora de Gastos: tela.
 * As contas ficam em gastos-core.js. Os dados ficam no localStorage deste navegador.
 */
(function () {
  "use strict";

  var G = window.CBGastos, CB = window.CB;
  if (!G || !CB) return;

  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var fmt = G.fmt;

  /* Cores das categorias (a primeira é o dourado da marca). Nunca é a única pista: sempre há nome e valor em texto. */
  var PALETTE = ["#E0A100", "#5BA8F5", "#3FB9A8", "#9B7BF0", "#F2766B", "#6CC070", "#C46A0C", "#E67BB5", "#8A93B8", "#B7D35A", "#4FD1E0", "#D8C7A0"];

  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; });
  }
  function pad(n) { return n < 10 ? "0" + n : "" + n; }
  function cap(s) { return s.charAt(0).toUpperCase() + s.slice(1); }
  function norm(s) { return String(s).normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase(); }
  function moneyInput(cents) { return (cents / 100).toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }

  /* ---------- armazenamento ---------- */

  var storage = null;
  try { storage = window.localStorage; storage.getItem(G.STORAGE_KEY); } catch (e) { storage = null; }
  var loaded = G.load(storage), data = loaded.state, storageStatus = loaded.status;

  function persist() {
    var ok = G.save(storage, data);
    if (!ok && storageStatus !== "unavailable") toast("Não foi possível salvar neste navegador. Faça um backup em “Seus dados” para não perder os registros.", "err");
    return ok;
  }

  /* ---------- estado da tela ---------- */

  var ST = { preset: "month", custom: { from: "", to: "" }, gran: "month", granUser: false, selCat: null, q: "", fCat: "", fPay: "", fKind: "", sort: "recent", limit: 15, editing: null, editingInc: null, incLimit: 8, pendingDelete: null };

  /* ---------- avisos rápidos ---------- */

  function toast(msg, kind) {
    var el = document.createElement("div");
    el.className = "toast " + (kind || "ok");
    el.textContent = msg;
    $("#toasts").appendChild(el);
    setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, kind === "ok" ? 4000 : 8000);
  }

  /* ---------- cálculo geral (a cada mudança) ---------- */

  function compute() {
    ST.today = G.todayStr();
    ST.cats = G.allCategories(data.categories);
    ST.map = G.catMap(ST.cats);
    ST.colors = {};
    var ci = 0;
    ST.cats.forEach(function (c) { ST.colors[c.id] = c.noConsumption ? "#7B8780" : PALETTE[ci++ % PALETTE.length]; });

    var ex = G.expand(data.expenses, ST.today);
    ST.real = ex.real; ST.future = ex.future;
    var first = null, firstAll = null;
    ST.real.forEach(function (o) { if (first === null || o.days < first) first = o.days; });
    ST.first = first === null ? null : G.fromDays(first);

    var exi = G.expandIncomes(data.incomes, ST.today);
    ST.incReal = exi.real; ST.incFuture = exi.future;
    firstAll = first;
    ST.incReal.forEach(function (o) { if (firstAll === null || o.days < firstAll) firstAll = o.days; });

    var per = G.resolvePeriod(ST.preset, ST.today, ST.custom, firstAll === null ? null : G.fromDays(firstAll));
    ST.per = per;
    ST.inPeriod = per.error ? [] : G.inRange(ST.real, per.cur);
    ST.incPeriod = per.error ? [] : G.inRange(ST.incReal, per.cur);
    ST.incTotal = G.sumIncome(ST.incPeriod);
    ST.cur = G.summarize(ST.inPeriod, ST.map);
    ST.prevOcc = per.prev && !per.error ? G.inRange(ST.real, per.prev) : null;
    ST.prev = ST.prevOcc ? G.summarize(ST.prevOcc, ST.map) : null;
    ST.breakdown = G.categoryBreakdown(ST.inPeriod, ST.cats);
    ST.prevBreakdown = ST.prevOcc ? G.categoryBreakdown(ST.prevOcc, ST.cats) : [];
    ST.top = G.topExpenses(ST.inPeriod, ST.map, 10);
    ST.fv = G.fixedVariable(ST.inPeriod, ST.map);
    ST.bud = G.budgetStatus(ST.real, data.budget, ST.cats, ST.today);

    if (!ST.granUser) ST.gran = G.autoGranularity(per.cur.fromD, per.cur.toD);
    ST.series = (ST.cur.count || ST.incPeriod.length) ? G.buildSeries(ST.inPeriod, ST.map, per.cur.fromD, per.cur.toD, ST.gran, ST.incPeriod) : null;
    ST.incBreakdown = G.incomeBreakdown(ST.incPeriod);
    if (ST.selCat && !ST.breakdown.some(function (b) { return b.id === ST.selCat; })) ST.selCat = null;
  }

  function dot(id) { return '<i style="background:' + (ST.colors[id] || "#7B8780") + '"></i>'; }
  function catName(id) { return (ST.map[id] || { name: "Outros" }).name; }
  function payName(id) { var p = G.PAYMENTS.filter(function (x) { return x[0] === id; })[0]; return p ? p[1] : "Outro"; }
  function kindName(id) { return id === "fixa" ? "Fixa" : "Variável"; }

  function stat(label, value, hint, cls, extra, small) {
    return '<div class="stat' + (cls ? " " + cls : "") + '"><div class="l">' + label + '</div><div class="v num' + (small ? " small" : "") + '">' + value + "</div>" + (hint ? '<div class="h">' + hint + "</div>" : "") + (extra || "") + "</div>";
  }

  /* ---------- período ---------- */

  function renderChips() {
    $("#chips").innerHTML = G.PRESETS.map(function (p) {
      return '<button type="button" class="chip' + (p[0] === ST.preset ? " on" : "") + '" data-preset="' + p[0] + '" aria-pressed="' + (p[0] === ST.preset) + '">' + p[1] + "</button>";
    }).join("");
    $("#customRange").hidden = ST.preset !== "custom";
    $("#rangeMsg").textContent = ST.per.error || "";
  }

  /* ---------- avisos de orçamento (topo) ---------- */

  function renderAlerts() {
    var rows = ST.bud.filter(function (b) { return b.level !== "ok"; }).map(function (b) {
      var over = b.level === "over", name = b.scope === "general" ? "do limite mensal geral" : "do limite de " + esc(b.name);
      return '<div class="banner ' + (over ? "err" : "warn") + '" role="status"><svg viewBox="0 0 24 24"><path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18h.01"/></svg><div><div class="t">' +
        (over ? (b.used > b.limit ? "Limite ultrapassado: " : "Limite atingido: ") : "Atenção: ") + "você usou " + b.pct + "% " + name + " neste mês.</div>" +
        '<div class="d">' + fmt(b.used) + " de " + fmt(b.limit) + (b.used > b.limit ? " (" + fmt(b.used - b.limit) + " acima)" : " (restam " + fmt(b.limit - b.used) + ")") + ". Você ainda pode registrar despesas normalmente.</div></div></div>";
    });
    $("#alerts").className = rows.length ? "alerts" : "";
    $("#alerts").innerHTML = rows.join("");
  }

  function renderStorageNote() {
    var h = "";
    if (storageStatus === "unavailable") h = '<div class="banner err" role="alert"><svg viewBox="0 0 24 24"><path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18h.01"/></svg><div><div class="t">Seu navegador não permite salvar dados neste site.</div><div class="d">Isso acontece em abas anônimas ou com o armazenamento bloqueado. As despesas ficam só nesta aba e somem ao fechá-la. Use “Exportar backup” em “Seus dados” antes de sair.</div></div></div>';
    else if (storageStatus === "corrupt") h = '<div class="banner err" role="alert"><svg viewBox="0 0 24 24"><path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18h.01"/></svg><div><div class="t">Os dados salvos não puderam ser lidos.</div><div class="d">Começamos com a lista vazia. A cópia antiga foi guardada no navegador com o nome “' + G.STORAGE_KEY + '.corrompido”.</div></div></div>';
    else h = '<p class="storage-note">Seus dados ficam salvos só neste navegador, neste aparelho. Eles não são enviados para nenhum servidor nem sincronizados com outros aparelhos. Faça backup em “Seus dados”, no fim da página.</p>';
    $("#storageNote").innerHTML = h;
  }

  /* ---------- resumo rápido ---------- */

  function renderQuick() {
    var t = G.toDays(ST.today), y = +ST.today.slice(0, 4), m = +ST.today.slice(5, 7);
    var sum = function (f, to) { return G.sumConsumption(G.inRange(ST.real, { fromD: f, toD: to }), ST.map); };
    var mFrom = G.toDays(y + "-" + pad(m) + "-01"), yFrom = G.toDays(y + "-01-01");
    var all = G.summarize(ST.real, ST.map);
    $("#quick").innerHTML =
      stat("Hoje", fmt(sum(t, t)), G.brDate(ST.today)) +
      stat("Últimos 7 dias", fmt(sum(t - 6, t)), G.brShort(t - 6) + " a " + G.brShort(t)) +
      stat("Mês atual", fmt(sum(mFrom, t)), cap(G.monthName(ST.today))) +
      stat("Ano atual", fmt(sum(yFrom, t)), String(y)) +
      stat("Total acumulado", fmt(all.total), ST.first ? "Desde " + G.brDate(ST.first) + " · " + all.count + (all.count === 1 ? " despesa" : " despesas") + ". Considera só o que foi registrado aqui." : "Nenhuma despesa registrada ainda");
  }

  /* ---------- números do período ---------- */

  function renderPeriod() {
    var per = ST.per, c = ST.cur;
    var h = '<h2 class="sec-title" id="hPeriod">' + esc(per.cur.label) + '</h2><p class="sec-sub">' + (per.error ? "Escolha as datas acima." : G.rangeText(per.cur) + ". Gastos de consumo, sem investimentos e transferências.") + "</p>";
    if (per.error) { $("#periodSec").innerHTML = h; return; }
    var cmp = "";
    if (ST.prev) {
      if (ST.prev.count > 0) {
        var d = G.compare(c.total, ST.prev.total);
        cmp = '<div class="cmp">' + (d.diff === 0 ? "Igual ao " : (d.diff > 0 ? "▲ " + fmt(d.diff) + " a mais" : "▼ " + fmt(-d.diff) + " a menos") + (d.pct !== null ? " (" + (d.diff > 0 ? "+" : "−") + G.pct1(Math.abs(d.pct)) + ")" : "") + " que ") +
          esc(per.prev.label) + " (" + G.rangeText(per.prev) + ")</div>";
      } else cmp = '<div class="cmp">Sem despesas em ' + esc(per.prev.label) + " (" + G.rangeText(per.prev) + ") para comparar.</div>";
    }
    var top = ST.breakdown[0];
    h += '<div class="stats five">' +
      stat("Gastos no período", fmt(c.total), c.count ? c.count + (c.count === 1 ? " despesa" : " despesas") : "Nenhuma despesa no período", "hero-stat", cmp) +
      stat("Despesas registradas", String(c.count), "No período selecionado") +
      stat("Valor médio por despesa", c.count ? fmt(c.avg) : "—", c.count ? "Total ÷ quantidade" : "") +
      stat("Categoria com maior gasto", top ? esc(top.name) : "—", top ? fmt(top.value) + " · " + G.pct1(top.pct) : "", "", "", true) +
      stat("Investimentos e aplicações", fmt(c.invest), "Separado dos gastos de consumo", "sep") + "</div>";
    if (c.transfer > 0) h += '<p class="note-line">Transferências entre contas no período: ' + fmt(c.transfer) + ". Não contam como gasto.</p>";
    $("#periodSec").innerHTML = h;
  }

  /* ---------- ganhos e saldo ---------- */

  function incCatName(id) { var c = G.INCOME_CATEGORIES.filter(function (x) { return x.id === id; })[0]; return c ? c.name : "Outros ganhos"; }

  function renderIncome() {
    var per = ST.per, c = ST.cur, inc = ST.incTotal;
    var h = '<div class="panel-head"><div><h2 id="hInc">Ganhos e saldo</h2><p>' + (per.error ? "Escolha as datas acima." : esc(per.cur.label) + " (" + G.rangeText(per.cur) + "). Saldo = ganhos menos gastos de consumo.") + '</p></div>' +
      '<button type="button" class="btn small" data-new-inc>+ Novo ganho</button></div>';
    if (per.error) { $("#incSec").innerHTML = h; return; }

    var bal = inc - c.total, cls = bal > 0 ? "pos" : bal < 0 ? "neg" : "";
    var balTxt = (bal < 0 ? "−" : "") + fmt(Math.abs(bal));
    h += '<div class="stats three inc-stats">' +
      stat("Ganhos no período", '<span class="pos">' + fmt(inc) + "</span>", ST.incPeriod.length ? ST.incPeriod.length + (ST.incPeriod.length === 1 ? " ganho" : " ganhos") : "Nenhum ganho no período") +
      stat("Gastos de consumo", fmt(c.total), "Sem investimentos e transferências") +
      stat("Saldo do período", '<span class="' + cls + '">' + balTxt + "</span>", inc > 0 ? "Você gastou " + Math.round(c.total * 100 / inc) + "% dos seus ganhos" : "Registre ganhos para ver o saldo") + "</div>";

    if (!data.incomes.length) {
      h += '<p class="empty"><b>Você ainda não registrou nenhum ganho</b>Registre salário, freelances, vendas e outras entradas para ver quanto sobra no período.<br><button type="button" class="btn gold" data-new-inc>+ Novo ganho</button></p>';
    } else if (!ST.incPeriod.length) {
      h += '<p class="note-line">Nenhum ganho no período selecionado. Escolha outro período ou registre um novo ganho.</p>';
    } else {
      var rows = ST.incPeriod.slice().sort(function (a, b) { return b.days - a.days || a.name.localeCompare(b.name, "pt-BR"); });
      var shown = rows.slice(0, ST.incLimit);
      h += '<ul class="mini inc-list" aria-label="Ganhos do período">' + shown.map(function (o) {
        return '<li><span class="nm">' + esc(o.name) + (o.recurring ? ' <span class="badge">Recorrente</span>' : "") + '<br><span class="d">' + G.brDate(o.date) + " · " + esc(incCatName(o.category)) + (o.desc ? " · " + esc(o.desc) : "") + '</span></span>' +
          '<span class="vl"><b class="pos">+ ' + fmt(o.amount) + '</b><button type="button" class="btn small" data-iedit="' + esc(o.id) + '" aria-label="Editar ' + esc(o.name) + '">Editar</button><button type="button" class="btn small" data-idel="' + esc(o.id) + '" aria-label="Excluir ' + esc(o.name) + '">Excluir</button></span></li>';
      }).join("") + "</ul>" +
        '<div class="list-foot"><span>Mostrando ' + shown.length + " de " + rows.length + (rows.length === 1 ? " ganho" : " ganhos") + "</span>" +
        (rows.length > shown.length ? '<button type="button" class="btn small" data-more-inc>Mostrar mais ' + Math.min(8, rows.length - shown.length) + "</button>" : "") + "</div>";
    }
    if (ST.incFuture.length) h += '<p class="note-line">Há ' + ST.incFuture.length + (ST.incFuture.length === 1 ? " ganho agendado" : " ganhos agendados") + " com data depois de hoje. Eles entram nos totais a partir da data deles.</p>";
    $("#incSec").innerHTML = h;
  }

  /* ---------- orçamento ---------- */

  function renderBudget() {
    var h = '<div class="panel-head"><div><h2 id="hBudget">Orçamento do mês</h2><p>' + cap(G.monthName(ST.today)) + ". Os limites valem para o mês atual e usam só gastos de consumo.</p></div>" +
      '<button type="button" class="btn small" data-budget>' + (ST.bud.length ? "Editar limites" : "Definir limites") + "</button></div>";
    if (!ST.bud.length) {
      h += '<p class="empty"><b>Nenhum limite definido</b>O orçamento é opcional. Defina um limite mensal geral e/ou por categoria para acompanhar quanto já foi usado.</p>';
    } else {
      h += '<div class="budget-list">' + ST.bud.map(function (b) {
        var w = Math.min(100, b.used / b.limit * 100), left = b.limit - b.used;
        var label = b.level === "over" ? "Limite atingido" : b.level === "warn" ? "Atenção: 80% ou mais" : "Dentro do limite";
        return "<div><div class=\"bud-top\"><b>" + esc(b.name) + '</b><span>' + fmt(b.used) + " de " + fmt(b.limit) + '</span></div><div class="track ' + (b.level === "ok" ? "" : b.level) + '" role="progressbar" aria-label="' + esc(b.name) + '" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + Math.min(100, b.pct) + '"><i style="width:' + w.toFixed(2) + '%"></i></div>' +
          '<div class="bud-bot"><span><span class="tag-s ' + b.level + '">' + label + "</span> " + b.pct + "% usado</span><span>" + (left >= 0 ? "Restam " + fmt(left) : "Acima do limite em " + fmt(-left)) + "</span></div></div>";
      }).join("") + "</div>";
    }
    $("#budgetSec").innerHTML = h;
  }

  /* ---------- gráfico de rosca ---------- */

  function arc(cx, cy, r, a0, a1) {
    var x0 = cx + r * Math.cos(a0), y0 = cy + r * Math.sin(a0), x1 = cx + r * Math.cos(a1), y1 = cy + r * Math.sin(a1);
    return "M" + x0.toFixed(2) + " " + y0.toFixed(2) + " A" + r + " " + r + " 0 " + (a1 - a0 > Math.PI ? 1 : 0) + " 1 " + x1.toFixed(2) + " " + y1.toFixed(2);
  }

  function renderCat() {
    var items = ST.breakdown, total = ST.cur.total;
    var h = '<div class="panel-head"><div><h2 id="hCat">Gastos por categoria</h2><p>Participação de cada categoria no período. Clique para ver as despesas.</p></div></div>';
    if (!items.length) {
      h += '<p class="empty"><b>Sem gastos no período</b>Registre despesas para ver a divisão por categoria.</p>';
    } else {
      var svg = '<svg viewBox="0 0 220 220" width="220" height="220" role="group" aria-label="Gráfico de rosca: gastos por categoria">', a = -Math.PI / 2;
      if (items.length === 1) svg += '<circle cx="110" cy="110" r="88" fill="none" stroke="' + ST.colors[items[0].id] + '" stroke-width="34"></circle>';
      else items.forEach(function (it) {
        var sweep = it.value / total * Math.PI * 2, gap = sweep > 0.06 ? 0.012 : 0;
        svg += '<path d="' + arc(110, 110, 88, a + gap, a + sweep - gap) + '" stroke="' + ST.colors[it.id] + '" stroke-width="' + (ST.selCat === it.id ? 40 : 34) + '" class="' + (ST.selCat === it.id ? "sel" : "") + '" data-cat="' + esc(it.id) + '" aria-hidden="true"><title>' + esc(it.name) + ": " + fmt(it.value) + " (" + G.pct1(it.pct) + ")</title></path>";
        a += sweep;
      });
      svg += '<text x="110" y="104" text-anchor="middle" font-size="12" fill="#66736B" font-family="Poppins, sans-serif">Total</text><text x="110" y="126" text-anchor="middle" font-size="' + (fmt(total).length > 12 ? 15 : 18) + '" font-weight="700" fill="#14201A" font-family="Poppins, sans-serif">' + fmt(total) + "</text></svg>";
      h += '<div class="donut-wrap' + (ST.selCat ? " has-sel" : "") + '">' + svg + '<ul class="catlist">' + items.map(function (it) {
        return '<li><button type="button" data-cat="' + esc(it.id) + '" class="' + (ST.selCat === it.id ? "sel" : "") + '" aria-pressed="' + (ST.selCat === it.id) + '">' + dot(it.id) + '<span class="nm">' + esc(it.name) + '</span><span class="vl">' + fmt(it.value) + '</span><span class="pc">' + G.pct1(it.pct) + "</span></button></li>";
      }).join("") + "</ul></div>";
      if (ST.selCat) {
        var list = ST.inPeriod.filter(function (o) { return o.category === ST.selCat; }).sort(function (x, y) { return y.amount - x.amount; });
        h += '<div class="detail-box"><h3><span><i class="sq"></i>' + esc(catName(ST.selCat)) + ' · ' + list.length + (list.length === 1 ? " despesa" : " despesas") + '</span><button type="button" class="btn small" data-cat-close>Fechar</button></h3><ul class="mini">' +
          list.slice(0, 50).map(function (o) { return '<li><span class="nm"><button type="button" class="linklike" data-det="' + esc(o.key) + '">' + esc(o.name) + '</button><br><span class="d">' + G.brDate(o.date) + " · " + payName(o.payment) + '</span></span><span class="vl">' + fmt(o.amount) + "</span></li>"; }).join("") +
          "</ul>" + (list.length > 50 ? '<p class="note-line">…e mais ' + (list.length - 50) + " despesas. Veja todas no histórico.</p>" : "") + "</div>";
      }
    }
    $("#catSec").innerHTML = h;
    var sq = $("#catSec .detail-box .sq");
    if (sq && ST.selCat) sq.style.background = ST.colors[ST.selCat];
  }

  /* ---------- fixas x variáveis ---------- */

  function renderFV() {
    var f = ST.fv, tot = f.fixa + f.variavel;
    var h = '<div class="panel-head"><div><h2 id="hFv">Gastos fixos e variáveis</h2><p>Comparação no período selecionado.</p></div></div>';
    if (!tot) h += '<p class="empty"><b>Sem gastos no período</b>Marque cada despesa como fixa ou variável para ver a comparação.</p>';
    else {
      var pf = f.fixa / tot * 100, pv = f.variavel / tot * 100;
      h += '<div class="fv-bar" role="img" aria-label="Fixos: ' + G.pct1(pf) + ". Variáveis: " + G.pct1(pv) + '"><span style="width:' + pf + '%;background:#139A49"></span><span style="width:' + pv + '%;background:#5BA8F5"></span></div>' +
        '<div class="fv-rows"><div class="fv-row"><i style="background:#139A49"></i><div>Fixos<small>' + f.fixaCount + (f.fixaCount === 1 ? " despesa" : " despesas") + " · " + G.pct1(pf) + "</small></div><b>" + fmt(f.fixa) + "</b></div>" +
        '<div class="fv-row"><i style="background:#5BA8F5"></i><div>Variáveis<small>' + f.variavelCount + (f.variavelCount === 1 ? " despesa" : " despesas") + " · " + G.pct1(pv) + "</small></div><b>" + fmt(f.variavel) + "</b></div></div>";
    }
    $("#fvSec").innerHTML = h;
  }

  /* ---------- evolução (barras) ---------- */

  var GRANS = [["day", "Diário"], ["week", "Semanal"], ["month", "Mensal"], ["year", "Anual"]];

  function renderEvo() {
    var h = '<div class="panel-head"><div><h2 id="hEvo">Evolução de ganhos e gastos</h2><p>Ganhos e gastos de consumo ao longo do tempo, dentro do período selecionado.</p></div></div>';
    h += '<div class="seg gran" role="group" aria-label="Agrupar por">' + GRANS.map(function (g) {
      return '<button type="button" data-gran="' + g[0] + '" class="' + (ST.gran === g[0] ? "on" : "") + '" aria-pressed="' + (ST.gran === g[0]) + '">' + g[1] + "</button>";
    }).join("") + "</div>";
    if (!ST.series) h += '<p class="empty"><b>Sem gastos nem ganhos no período</b>Registre despesas e ganhos para ver como eles evoluem.</p>';
    else if (ST.series.length > 500) h += '<p class="empty"><b>Período longo demais para este agrupamento</b>Escolha Semanal, Mensal ou Anual.</p>';
    else {
      var hi = ST.incTotal > 0;
      h += '<div class="chart-legend"><span><i style="background:#D42B35"></i>Gastos</span>' + (hi ? '<span><i style="background:#139A49"></i>Ganhos</span>' : "") + "</div>" +
        '<div class="chart-host" id="evoHost"></div>' +
        '<details class="dt"><summary>Ver os dados do gráfico em tabela</summary><div class="scroll"><table><thead><tr><th>Período</th><th>Gastos</th>' + (hi ? "<th>Ganhos</th><th>Saldo</th>" : "") + '<th>Despesas</th></tr></thead><tbody class="num">' +
        ST.series.map(function (b) { var sd = b.income - b.total; return "<tr><td>" + esc(b.full) + "</td><td>" + fmt(b.total) + "</td>" + (hi ? "<td>" + fmt(b.income) + "</td><td>" + (sd < 0 ? "−" : "") + fmt(Math.abs(sd)) + "</td>" : "") + "<td>" + b.count + "</td></tr>"; }).join("") + "</tbody></table></div></details>";
    }
    $("#evoSec").innerHTML = h;
    drawEvo();
  }

  function niceMax(v) {
    if (!(v > 0)) return 100;
    var p = Math.pow(10, Math.floor(Math.log10(v))), s = [1, 2, 2.5, 4, 5, 8, 10];
    for (var i = 0; i < s.length; i++) if (s[i] * p >= v) return s[i] * p;
    return 10 * p;
  }

  function drawEvo() {
    var host = $("#evoHost");
    if (!host || !ST.series) return;
    var b = ST.series, n = b.length, w = Math.max(260, host.clientWidth), h = w < 520 ? 240 : 320;
    var L = 66, R = 8, T = 12, B = 30, iw = w - L - R, ih = h - T - B, max = 0;
    b.forEach(function (x) { max = Math.max(max, x.total, x.income); });
    var hasInc = ST.incTotal > 0;
    var top = niceMax(max * 1.05), slot = iw / n, gw = Math.max(1, slot * (n > 60 ? 0.9 : 0.7)), bw = hasInc ? gw / 2 : gw;
    var Y = function (v) { return T + ih - v / top * ih; };
    var GOLD = "#D42B35", GOLD_HI = "#E8505A", GREEN = "#139A49", GREEN_HI = "#22B35C";
    var s = "";
    for (var t = 0; t <= 4; t++) {
      var gv = top * t / 4, gy = Y(gv);
      s += '<line x1="' + L + '" x2="' + (w - R) + '" y1="' + gy + '" y2="' + gy + '" stroke="#B9C6BF" stroke-opacity=".45"/><text x="' + (L - 8) + '" y="' + (gy + 4) + '" text-anchor="end" font-size="11" fill="#66736B" font-family="Poppins, sans-serif">' + G.fmtShort(gv) + "</text>";
    }
    function bar(i, x, v, f, hi, wd) {
      var y = Y(v), bh = Math.max(0, T + ih - y);
      return '<rect data-i="' + i + '" data-f="' + f + '" data-hi="' + hi + '" x="' + x.toFixed(2) + '" y="' + y.toFixed(2) + '" width="' + wd.toFixed(2) + '" height="' + bh.toFixed(2) + '" rx="' + (wd > 6 ? 3 : 0) + '" fill="' + f + '"/>';
    }
    var every = Math.max(1, Math.ceil(n / Math.max(2, Math.floor(iw / 58))));
    b.forEach(function (x, i) {
      var gx = L + i * slot + (slot - gw) / 2;
      s += bar(i, gx, x.total, GOLD, GOLD_HI, bw);
      if (hasInc) s += bar(i, gx + bw, x.income, GREEN, GREEN_HI, bw);
      if (i % every === 0) s += '<text x="' + (L + i * slot + slot / 2).toFixed(1) + '" y="' + (h - 10) + '" text-anchor="middle" font-size="11" fill="#66736B" font-family="Poppins, sans-serif">' + esc(x.label) + "</text>";
    });
    host.innerHTML = '<svg viewBox="0 0 ' + w + " " + h + '" width="' + w + '" height="' + h + '" role="group" aria-label="Gráfico de barras: ganhos e gastos ao longo do tempo. Os mesmos dados estão na tabela abaixo.">' + s + '</svg><div class="tip" id="evoTip" hidden></div>';

    var svg = host.querySelector("svg"), tip = host.querySelector("#evoTip"), last = null;
    function paint(i, on) {
      Array.prototype.forEach.call(svg.querySelectorAll('rect[data-i="' + i + '"]'), function (r) { r.setAttribute("fill", r.getAttribute(on ? "data-hi" : "data-f")); });
    }
    function show(clientX) {
      var rect = svg.getBoundingClientRect(), i = Math.floor(((clientX - rect.left) - L) / slot);
      i = Math.max(0, Math.min(n - 1, i));
      if (last !== null) paint(last, false);
      last = i; paint(i, true);
      var sd = b[i].income - b[i].total;
      tip.innerHTML = '<div class="tt">' + esc(b[i].full) + '</div><div class="tr"><span>Gastos</span><b>' + fmt(b[i].total) + "</b></div>" +
        (hasInc ? '<div class="tr"><span>Ganhos</span><b>' + fmt(b[i].income) + '</b></div><div class="tr"><span>Saldo</span><b>' + (sd < 0 ? "−" : "") + fmt(Math.abs(sd)) + "</b></div>" : "") +
        '<div class="tr"><span>Despesas</span><b>' + b[i].count + "</b></div>";
      tip.hidden = false;
      var cx = L + i * slot + slot / 2, tw = tip.offsetWidth, left = cx + 14;
      if (left + tw > w) left = cx - tw - 14;
      tip.style.left = Math.max(0, left) + "px";
    }
    svg.addEventListener("pointermove", function (e) { show(e.clientX); });
    svg.addEventListener("pointerdown", function (e) { show(e.clientX); });
    svg.addEventListener("pointerleave", function () { tip.hidden = true; if (last !== null) { paint(last, false); last = null; } });
  }

  /* ---------- ganhos por categoria (rosca) ---------- */

  var INC_PALETTE = ["#139A49", "#2AA7B5", "#4A8FE0", "#8A63E0", "#E0A100", "#C46A0C", "#8A93B8"];

  function renderIncCat() {
    var items = ST.incBreakdown, total = ST.incTotal;
    var h = '<div class="panel-head"><div><h2 id="hIncCat">Ganhos por categoria</h2><p>De onde vieram os seus ganhos no período.</p></div></div>';
    if (!items.length) {
      h += '<p class="empty"><b>Sem ganhos no período</b>Registre ganhos para ver a divisão por categoria.</p>';
    } else {
      var col = function (it) { return INC_PALETTE[it.index % INC_PALETTE.length]; };
      var svg = '<svg viewBox="0 0 220 220" width="220" height="220" role="img" aria-label="Gráfico de rosca: ganhos por categoria">', a = -Math.PI / 2;
      if (items.length === 1) svg += '<circle cx="110" cy="110" r="88" fill="none" stroke="' + col(items[0]) + '" stroke-width="34"></circle>';
      else items.forEach(function (it) {
        var sweep = it.value / total * Math.PI * 2, gap = sweep > 0.06 ? 0.012 : 0;
        svg += '<path d="' + arc(110, 110, 88, a + gap, a + sweep - gap) + '" stroke="' + col(it) + '" stroke-width="34"><title>' + esc(it.name) + ": " + fmt(it.value) + " (" + G.pct1(it.pct) + ")</title></path>";
        a += sweep;
      });
      svg += '<text x="110" y="104" text-anchor="middle" font-size="12" fill="#66736B" font-family="Poppins, sans-serif">Total</text><text x="110" y="126" text-anchor="middle" font-size="' + (fmt(total).length > 12 ? 15 : 18) + '" font-weight="700" fill="#14201A" font-family="Poppins, sans-serif">' + fmt(total) + "</text></svg>";
      h += '<div class="donut-wrap">' + svg + '<ul class="catlist">' + items.map(function (it) {
        return '<li><div class="static-row"><i style="background:' + col(it) + '"></i><span class="nm">' + esc(it.name) + '</span><span class="vl">' + fmt(it.value) + '</span><span class="pc">' + G.pct1(it.pct) + "</span></div></li>";
      }).join("") + "</ul></div>";
    }
    $("#incCatSec").innerHTML = h;
  }

  /* ---------- maiores despesas ---------- */

  function renderTop() {
    var h = '<div class="panel-head"><div><h2 id="hTop">Maiores despesas</h2><p>As 10 despesas de maior valor no período.</p></div></div>';
    if (!ST.top.length) h += '<p class="empty"><b>Sem gastos no período</b>As maiores despesas aparecem aqui assim que houver registros.</p>';
    else {
      var max = ST.top[0].amount;
      h += '<ol class="rank">' + ST.top.map(function (o, i) {
        return '<li><span class="pos">' + (i + 1) + '</span><div><button type="button" class="linklike nm" data-det="' + esc(o.key) + '">' + esc(o.name) + '</button><div class="sub">' + esc(catName(o.category)) + " · " + G.brDate(o.date) + '</div></div><span class="vl">' + fmt(o.amount) + '</span><span class="rbar"><i style="width:' + (o.amount / max * 100).toFixed(2) + '%"></i></span></li>';
      }).join("") + "</ol>";
    }
    $("#topSec").innerHTML = h;
  }

  /* ---------- histórico ---------- */

  function buildHistoryShell() {
    $("#histSec").innerHTML = '<div class="panel-head"><div><h2 id="hHist">Histórico de despesas</h2><p id="histMeta"></p></div></div>' +
      '<div class="filters">' +
      '<div class="input sm"><input type="search" id="hq" placeholder="Pesquisar pelo nome" aria-label="Pesquisar pelo nome da despesa" autocomplete="off"></div>' +
      '<div class="input sm"><select id="hCatF" aria-label="Filtrar por categoria"></select></div>' +
      '<div class="input sm"><select id="hPayF" aria-label="Filtrar por forma de pagamento"><option value="">Todos os pagamentos</option>' + G.PAYMENTS.map(function (p) { return '<option value="' + p[0] + '">' + p[1] + "</option>"; }).join("") + "</select></div>" +
      '<div class="input sm"><select id="hKindF" aria-label="Filtrar por tipo de despesa"><option value="">Fixas e variáveis</option><option value="fixa">Só fixas</option><option value="variavel">Só variáveis</option></select></div>' +
      '<div class="input sm"><select id="hSort" aria-label="Ordenar por"><option value="recent">Mais recentes</option><option value="old">Mais antigas</option><option value="high">Maior valor</option><option value="low">Menor valor</option></select></div>' +
      '</div><div id="histBody"></div>';
  }

  function renderHistory() {
    var sel = $("#hCatF"), keep = ST.fCat;
    sel.innerHTML = '<option value="">Todas as categorias</option>' + ST.cats.map(function (c) { return '<option value="' + esc(c.id) + '">' + esc(c.name) + "</option>"; }).join("");
    if (!ST.map[keep]) { keep = ""; ST.fCat = ""; }
    sel.value = keep;

    var q = norm(ST.q.trim());
    var rows = ST.inPeriod.filter(function (o) {
      return (!ST.fCat || o.category === ST.fCat) && (!ST.fPay || o.payment === ST.fPay) && (!ST.fKind || o.kind === ST.fKind) && (!q || norm(o.name).indexOf(q) !== -1);
    });
    rows.sort(function (a, b) {
      if (ST.sort === "old") return a.days - b.days || a.name.localeCompare(b.name, "pt-BR");
      if (ST.sort === "high") return b.amount - a.amount || b.days - a.days;
      if (ST.sort === "low") return a.amount - b.amount || b.days - a.days;
      return b.days - a.days || a.name.localeCompare(b.name, "pt-BR");
    });
    var filtering = ST.fCat || ST.fPay || ST.fKind || q;
    $("#histMeta").textContent = "Período: " + ST.per.cur.label + (ST.per.error ? "" : " (" + G.rangeText(ST.per.cur) + ")") + ". Para mudar as datas, use o seletor de período no topo da página.";

    var body = $("#histBody");
    if (!rows.length) {
      body.innerHTML = data.expenses.length === 0
        ? '<p class="empty"><b>Você ainda não registrou nenhuma despesa</b>Comece com a primeira: toque em “Nova despesa”, informe nome, valor, categoria e data.<br><button type="button" class="btn gold" data-new>+ Nova despesa</button></p>'
        : '<p class="empty"><b>' + (filtering ? "Nenhuma despesa com esses filtros" : "Nenhuma despesa no período") + "</b>" + (filtering ? "Limpe a pesquisa ou os filtros para ver mais resultados." : "Escolha outro período ou registre uma nova despesa.") + "</p>";
      return;
    }
    var shown = rows.slice(0, ST.limit);
    body.innerHTML = '<div class="scroll"><table class="hist"><thead><tr><th>Despesa</th><th>Data</th><th>Pagamento</th><th>Tipo</th><th class="r">Valor</th><th class="r"><span class="sr-only">Ações</span></th></tr></thead><tbody>' +
      shown.map(function (o) {
        var badges = (o.recurring ? '<span class="badge">Recorrente</span>' : "") + (ST.map[o.category] && ST.map[o.category].noConsumption ? '<span class="badge">Não conta como gasto</span>' : "");
        return '<tr data-key="' + esc(o.key) + '"><td><button type="button" class="linklike nm" data-det="' + esc(o.key) + '">' + esc(o.name) + "</button>" + badges + '<div class="cat">' + dot(o.category) + esc(catName(o.category)) + "</div></td><td>" + G.brDate(o.date) + "</td><td>" + payName(o.payment) + "</td><td>" + kindName(o.kind) + '</td><td class="r num"><b>' + fmt(o.amount) + '</b></td><td class="acts"><button type="button" class="btn small" data-edit="' + esc(o.id) + '" aria-label="Editar ' + esc(o.name) + '">Editar</button><button type="button" class="btn small" data-del="' + esc(o.id) + '" aria-label="Excluir ' + esc(o.name) + '">Excluir</button></td></tr>';
      }).join("") + '</tbody></table></div><div class="list-foot"><span>Mostrando ' + shown.length + " de " + rows.length + (rows.length === 1 ? " despesa" : " despesas") + "</span>" +
      (rows.length > shown.length ? '<button type="button" class="btn small" data-more>Mostrar mais ' + Math.min(15, rows.length - shown.length) + "</button>" : "") + "</div>";
  }

  /* ---------- agendadas ---------- */

  function renderFuture() {
    var sec = $("#futureSec"), list = ST.future.slice().sort(function (a, b) { return a.days - b.days; });
    sec.hidden = !list.length;
    if (!list.length) { sec.innerHTML = ""; return; }
    sec.innerHTML = '<div class="panel-head"><div><h2 id="hFuture">Despesas agendadas (' + list.length + ')</h2><p>Têm data depois de hoje. Entram nos totais e gráficos só a partir da data delas.</p></div></div><ul class="mini">' +
      list.map(function (o) { return '<li><span class="nm"><button type="button" class="linklike" data-det="' + esc(o.key) + '">' + esc(o.name) + '</button>' + (o.recurring ? ' <span class="badge">Recorrente</span>' : "") + '<br><span class="d">' + G.brDate(o.date) + " · " + esc(catName(o.category)) + '</span></span><span class="vl">' + fmt(o.amount) + ' <button type="button" class="btn small" data-edit="' + esc(o.id) + '">Editar</button> <button type="button" class="btn small" data-del="' + esc(o.id) + '">Excluir</button></span></li>'; }).join("") + "</ul>";
  }

  /* ---------- seus dados ---------- */

  function renderData() {
    $("#dataSec").innerHTML = '<div class="panel-head"><div><h2 id="hData">Seus dados</h2><p>' + data.expenses.length + (data.expenses.length === 1 ? " despesa registrada" : " despesas registradas") + ", " + data.incomes.length + (data.incomes.length === 1 ? " ganho" : " ganhos") + " e " + data.categories.length + (data.categories.length === 1 ? " categoria personalizada" : " categorias personalizadas") + ".</p></div></div>" +
      '<p class="body-text">Tudo fica guardado apenas no navegador deste aparelho. Se você limpar os dados do navegador, trocar de aparelho ou usar outro navegador, os registros não aparecem. Use o backup para guardar uma cópia ou levar seus dados para outro lugar.</p>' +
      '<div class="data-actions"><button type="button" class="btn" data-export-json>Exportar backup (JSON)</button><button type="button" class="btn" data-export-csv>Exportar planilha (CSV)</button><button type="button" class="btn" data-import>Importar backup</button><button type="button" class="btn danger" data-wipe>Apagar todos os dados</button></div>';
  }

  /* ---------- relatório em PDF ---------- */

  function makeReport() {
    if (ST.per.error) { toast(ST.per.error, "warn"); return; }
    if (!window.CBRelatorio) { toast("O gerador de relatório não foi carregado. Recarregue a página.", "err"); return; }
    var btn = $("#btnReport"); btn.disabled = true;
    var rows = ST.inPeriod.slice().sort(function (a, b) { return b.days - a.days || a.name.localeCompare(b.name, "pt-BR"); });
    toast("Gerando o relatório…", "ok");
    window.CBRelatorio.gerar({
      today: ST.today, per: ST.per, cur: ST.cur, prev: ST.prev, breakdown: ST.breakdown, fv: ST.fv, top: ST.top, bud: ST.bud,
      occs: ST.inPeriod, map: ST.map, colors: ST.colors, rows: rows,
      catName: catName, payName: payName, kindName: kindName
    }).then(function () { toast("Relatório baixado.", "ok"); },
      function () { toast("Não foi possível gerar o PDF. Verifique a conexão com a internet e tente de novo.", "err"); })
      .then(function () { btn.disabled = false; });
  }

  /* ---------- tudo junto ---------- */

  function render() {
    compute();
    renderChips(); renderStorageNote(); renderAlerts(); renderQuick(); renderPeriod(); renderIncome(); renderBudget();
    renderCat(); renderFV(); renderEvo(); renderIncCat(); renderTop(); renderHistory(); renderFuture(); renderData();
  }

  /* =====================================================================
     Janelas (nova despesa, detalhes, confirmação, orçamento)
     ===================================================================== */

  function closeDlg(el) { if (el.open) el.close(); }

  var FIELD_IDS = { name: "fName", value: "fValue", category: "fCat", date: "fDate", payment: "fPay", kind: "kFixa", desc: "fDesc", end: "fEnd" };

  function showFormErrors(errors) {
    var first = null;
    Object.keys(FIELD_IDS).forEach(function (k) {
      var id = FIELD_IDS[k], msg = errors[k] || "", e = $("#e-" + id), w = $("#w-" + id);
      if (e) e.textContent = msg;
      if (w) w.classList.toggle("err", !!msg);
      var inp = $("#" + id); if (inp) inp.setAttribute("aria-invalid", msg ? "true" : "false");
      if (msg && !first) first = id;
    });
    if (first) $("#" + first).focus();
  }

  function fillCatSelect(selected) {
    $("#fCat").innerHTML = '<option value="">Escolha uma categoria</option>' + ST.cats.map(function (c) { return '<option value="' + esc(c.id) + '">' + esc(c.name) + (c.noConsumption ? " (não conta como gasto)" : "") + "</option>"; }).join("") + '<option value="__new__">＋ Nova categoria…</option>';
    $("#fCat").value = selected || "";
  }

  function syncRecurring() {
    var on = $("#fRec").checked;
    $("#recBox").hidden = !on;
    $("#lblDate").textContent = on ? "Data da primeira ocorrência" : "Data da despesa";
  }

  function openForm(id) {
    var e = id ? data.expenses.filter(function (x) { return x.id === id; })[0] : null;
    ST.editing = e ? e.id : null;
    $("#expTitle").textContent = e ? "Editar despesa" : "Nova despesa";
    $("#btnSave").textContent = e ? "Salvar alterações" : "Salvar despesa";
    $("#fName").value = e ? e.name : "";
    $("#fValue").value = e ? moneyInput(e.amount) : "";
    $("#fDate").value = e ? e.date : ST.today;
    $("#fPay").innerHTML = G.PAYMENTS.map(function (p) { return '<option value="' + p[0] + '">' + p[1] + "</option>"; }).join("");
    $("#fPay").value = e ? e.payment : "pix";
    fillCatSelect(e ? e.category : "");
    $("#newCatRow").hidden = true; $("#fNewCat").value = ""; $("#e-fNewCat").textContent = "";
    $("#kFixa").checked = !!(e && e.kind === "fixa"); $("#kVar").checked = !(e && e.kind === "fixa");
    $("#fDesc").value = e ? e.desc : "";
    $("#fRec").checked = !!(e && e.recurring);
    $("#fEnd").value = e ? e.end : "";
    syncRecurring();
    showFormErrors({});
    var dlg = $("#dlgExp");
    if (!dlg.open) dlg.showModal();
    $("#fName").focus();
  }

  function saveExpense(ev) {
    ev.preventDefault();
    var kind = $("input[name=kind]:checked");
    var v = { name: $("#fName").value, value: $("#fValue").value, category: $("#fCat").value, date: $("#fDate").value, payment: $("#fPay").value, kind: kind ? kind.value : "", desc: $("#fDesc").value, recurring: $("#fRec").checked, end: $("#fEnd").value };
    var r = G.validateExpense(v, ST.cats, ST.today);
    if (v.category === "__new__") r.errors.category = "Adicione a nova categoria ou escolha uma da lista.";
    showFormErrors(r.errors);
    if (Object.keys(r.errors).length) return;
    var x = r.expense;
    if (ST.editing) {
      x.id = ST.editing;
      data.expenses = data.expenses.map(function (e) { return e.id === ST.editing ? x : e; });
    } else { x.id = G.uid(); data.expenses.push(x); }
    var wasEditing = !!ST.editing;
    persist();
    closeDlg($("#dlgExp"));
    ST.limit = Math.max(ST.limit, 15);
    render();
    var msg = wasEditing ? "Despesa atualizada." : "Despesa salva.", kindT = "ok";
    if (x.recurring || x.date.slice(0, 7) === ST.today.slice(0, 7)) {
      var rel = ST.bud.filter(function (b) { return b.level !== "ok" && (b.scope === "general" || b.scope === x.category); });
      if (rel.length) { kindT = "warn"; msg += " Atenção: " + rel.map(function (b) { return "você usou " + b.pct + "% " + (b.scope === "general" ? "do limite mensal geral" : "do limite de " + b.name); }).join("; ") + "."; }
    }
    if (x.date > ST.today && !x.recurring) msg += " Ela entra nos totais a partir de " + G.brDate(x.date) + ".";
    toast(msg, kindT);
  }

  /* ---------- ganhos (janela) ---------- */

  var INC_FIELDS = { name: "iName", value: "iValue", category: "iCat", date: "iDate", desc: "iDesc", end: "iEnd" };

  function showIncErrors(errors) {
    var first = null;
    Object.keys(INC_FIELDS).forEach(function (k) {
      var id = INC_FIELDS[k], msg = errors[k] || "", e = $("#e-" + id), w = $("#w-" + id);
      if (e) e.textContent = msg;
      if (w) w.classList.toggle("err", !!msg);
      var inp = $("#" + id); if (inp) inp.setAttribute("aria-invalid", msg ? "true" : "false");
      if (msg && !first) first = id;
    });
    if (first) $("#" + first).focus();
  }

  function syncIncRecurring() {
    var on = $("#iRec").checked;
    $("#iRecBox").hidden = !on;
    $("#lblIDate").textContent = on ? "Data da primeira ocorrência" : "Data do ganho";
  }

  function openIncForm(id) {
    var e = id ? data.incomes.filter(function (x) { return x.id === id; })[0] : null;
    ST.editingInc = e ? e.id : null;
    $("#incTitle").textContent = e ? "Editar ganho" : "Novo ganho";
    $("#btnIncSave").textContent = e ? "Salvar alterações" : "Salvar ganho";
    $("#iName").value = e ? e.name : "";
    $("#iValue").value = e ? moneyInput(e.amount) : "";
    $("#iDate").value = e ? e.date : ST.today;
    $("#iCat").innerHTML = '<option value="">Escolha uma categoria</option>' + G.INCOME_CATEGORIES.map(function (c) { return '<option value="' + c.id + '">' + esc(c.name) + "</option>"; }).join("");
    $("#iCat").value = e ? e.category : "";
    $("#iDesc").value = e ? e.desc : "";
    $("#iRec").checked = !!(e && e.recurring);
    $("#iEnd").value = e ? e.end : "";
    syncIncRecurring();
    showIncErrors({});
    var dlg = $("#dlgInc");
    if (!dlg.open) dlg.showModal();
    $("#iName").focus();
  }

  function saveIncome(ev) {
    ev.preventDefault();
    var v = { name: $("#iName").value, value: $("#iValue").value, category: $("#iCat").value, date: $("#iDate").value, desc: $("#iDesc").value, recurring: $("#iRec").checked, end: $("#iEnd").value };
    var r = G.validateIncome(v);
    showIncErrors(r.errors);
    if (Object.keys(r.errors).length) return;
    var x = r.income, wasEditing = !!ST.editingInc;
    if (wasEditing) {
      x.id = ST.editingInc;
      data.incomes = data.incomes.map(function (e) { return e.id === ST.editingInc ? x : e; });
    } else { x.id = G.uid(); data.incomes.push(x); }
    persist();
    closeDlg($("#dlgInc"));
    render();
    var msg = wasEditing ? "Ganho atualizado." : "Ganho salvo.";
    if (x.date > ST.today && !x.recurring) msg += " Ele entra nos totais a partir de " + G.brDate(x.date) + ".";
    toast(msg, "ok");
  }

  function askDeleteIncome(id) {
    var e = data.incomes.filter(function (x) { return x.id === id; })[0]; if (!e) return;
    $("#cfTitle").textContent = "Excluir ganho?";
    $("#cfText").textContent = "“" + e.name + "” (" + fmt(e.amount) + ") será excluído" + (e.recurring ? ", junto com todas as ocorrências mensais dele. Se ele só terminou, edite o ganho e informe a data em “Termina em”" : "") + ". Essa ação não pode ser desfeita.";
    $("#cfOk").textContent = "Excluir"; $("#cfOk").className = "btn danger";
    ST.confirmAction = function () {
      data.incomes = data.incomes.filter(function (x) { return x.id !== id; });
      persist(); render(); toast("Ganho excluído.", "ok");
    };
    $("#dlgConfirm").showModal();
    $("#cfOk").focus();
  }

  function findOcc(key) {
    return ST.real.concat(ST.future).filter(function (o) { return o.key === key; })[0];
  }

  function openDetails(key) {
    var o = findOcc(key); if (!o) return;
    var e = data.expenses.filter(function (x) { return x.id === o.id; })[0]; if (!e) return;
    var nonCons = ST.map[o.category] && ST.map[o.category].noConsumption;
    var rows = [["Valor", fmt(o.amount), "big"], ["Categoria", esc(catName(o.category)) + (nonCons ? " (não conta como gasto)" : "")], ["Data", G.brDate(o.date)], ["Pagamento", payName(o.payment)], ["Tipo", kindName(o.kind)]];
    if (e.recurring) rows.push(["Recorrência", "Todo mês, desde " + G.brDate(e.date) + (e.end ? ", até " + G.brDate(e.end) : "") + ". A ocorrência mostrada é a de " + G.brDate(o.date) + "."]);
    if (o.days > G.toDays(ST.today)) rows.push(["Situação", "Agendada. Entra nos totais a partir da data."]);
    rows.push(["Descrição", e.desc ? esc(e.desc) : "—"]);
    $("#detBody").innerHTML = '<p class="sec-title" style="margin:0">' + esc(e.name) + '</p><dl class="det">' + rows.map(function (r) { return "<dt>" + r[0] + "</dt><dd" + (r[2] ? ' class="' + r[2] + '"' : "") + ">" + r[1] + "</dd>"; }).join("") + "</dl>";
    var lastOcc = null;
    ST.real.forEach(function (x) { if (x.id === e.id && (!lastOcc || x.date > lastOcc)) lastOcc = x.date; });
    var canEnd = e.recurring && lastOcc && (!e.end || e.end > lastOcc);
    $("#detFoot").innerHTML = (canEnd ? '<button type="button" class="btn" data-endrec="' + esc(e.id) + '">Encerrar recorrência</button>' : "") +
      '<button type="button" class="btn" data-edit="' + esc(e.id) + '">Editar</button><button type="button" class="btn danger" data-del="' + esc(e.id) + '">Excluir</button>';
    var dlg = $("#dlgDet"); if (!dlg.open) dlg.showModal();
  }

  function askDelete(id) {
    var e = data.expenses.filter(function (x) { return x.id === id; })[0]; if (!e) return;
    ST.pendingDelete = id;
    $("#cfTitle").textContent = "Excluir despesa?";
    $("#cfText").textContent = "“" + e.name + "” (" + fmt(e.amount) + ") será excluída" + (e.recurring ? ", junto com todas as ocorrências mensais dela. Se você só quer parar de contar daqui para a frente, use “Encerrar recorrência” nos detalhes" : "") + ". Essa ação não pode ser desfeita.";
    $("#cfOk").textContent = "Excluir"; $("#cfOk").className = "btn danger";
    ST.confirmAction = function () {
      data.expenses = data.expenses.filter(function (x) { return x.id !== id; });
      persist(); render(); toast("Despesa excluída.", "ok");
    };
    closeDlg($("#dlgDet"));
    $("#dlgConfirm").showModal();
    $("#cfOk").focus();
  }

  function askWipe() {
    $("#cfTitle").textContent = "Apagar todos os dados?";
    $("#cfText").textContent = "Todas as despesas, categorias personalizadas e limites de orçamento deste navegador serão apagados. Se quiser guardar uma cópia, exporte o backup antes. Essa ação não pode ser desfeita.";
    $("#cfOk").textContent = "Apagar tudo"; $("#cfOk").className = "btn danger";
    ST.confirmAction = function () { data = G.emptyState(); ST.selCat = null; persist(); render(); toast("Todos os dados foram apagados.", "ok"); };
    $("#dlgConfirm").showModal(); $("#cfOk").focus();
  }

  /* ---------- orçamento (janela) ---------- */

  function openBudget() {
    var cons = ST.cats.filter(function (c) { return !c.noConsumption; });
    var h = '<p class="body-text">Deixe em branco o que não quiser limitar. Os limites valem para cada mês e usam só gastos de consumo. Você receberá avisos em 80% e em 100%, mas nada é bloqueado.</p>' +
      '<div class="bd-row"><label for="bGeneral">Limite mensal geral</label><div class="input sm" id="w-bGeneral"><span>R$</span><input id="bGeneral" inputmode="decimal" placeholder="0,00" value="' + (data.budget.general ? moneyInput(data.budget.general) : "") + '"></div></div><p class="msg" id="e-bGeneral"></p>' +
      '<p class="bd-sec">Limite por categoria</p><div class="bd-cats">' + cons.map(function (c, i) {
        return '<div class="bd-row"><label for="bc' + i + '">' + esc(c.name) + '</label><div class="input sm" id="w-bc' + i + '"><span>R$</span><input id="bc' + i + '" data-cat="' + esc(c.id) + '" inputmode="decimal" placeholder="0,00" value="' + (data.budget.cats[c.id] ? moneyInput(data.budget.cats[c.id]) : "") + '"></div></div><p class="msg" id="e-bc' + i + '"></p>';
      }).join("") + "</div>";
    if (data.categories.length) {
      h += '<p class="bd-sec">Suas categorias</p><div class="bd-cats">' + data.categories.map(function (c) {
        var used = data.expenses.some(function (e) { return e.category === c.id; });
        return '<div class="cc-row"><span>' + esc(c.name) + '</span><button type="button" class="btn small" data-rmcat="' + esc(c.id) + '"' + (used ? ' disabled title="Há despesas nesta categoria"' : "") + ">" + (used ? "Em uso" : "Remover") + "</button></div>";
      }).join("") + "</div>";
    }
    $("#bdBody").innerHTML = h;
    var dlg = $("#dlgBudget"); if (!dlg.open) dlg.showModal();
    $("#bGeneral").focus();
  }

  function saveBudget(ev) {
    ev.preventDefault();
    var ok = true, nb = { general: 0, cats: {} };
    function read(input, errId, wId, apply) {
      var txt = input.value.trim(), msg = "";
      if (txt) {
        var c = G.parseCents(txt);
        if (isNaN(c)) msg = "Informe um valor válido. Exemplo: 1.500,00";
        else if (c < 0) msg = "O limite não pode ser negativo.";
        else if (c > G.MAX_AMOUNT_CENTS) msg = "Valor muito alto.";
        else if (c > 0) apply(c);
      }
      $("#" + errId).textContent = msg; $("#" + wId).classList.toggle("err", !!msg);
      if (msg) { if (ok) input.focus(); ok = false; }
    }
    read($("#bGeneral"), "e-bGeneral", "w-bGeneral", function (c) { nb.general = c; });
    $$("#bdBody input[data-cat]").forEach(function (inp) { read(inp, "e-" + inp.id, "w-" + inp.id, function (c) { nb.cats[inp.getAttribute("data-cat")] = c; }); });
    if (!ok) return;
    data.budget = nb; persist(); closeDlg($("#dlgBudget")); render(); toast("Orçamento salvo.", "ok");
  }

  /* ---------- backup ---------- */

  function download(name, text, type) {
    var blob = new Blob([text], { type: type }), a = document.createElement("a");
    a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 800);
  }

  function importFile(file) {
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) { toast("Arquivo grande demais (máximo 5 MB).", "err"); return; }
    var fr = new FileReader();
    fr.onload = function () {
      try {
        var r = G.mergeImport(data, String(fr.result));
        persist(); render();
        var n = r.added + r.addedIncomes;
        toast(n + (n === 1 ? " registro importado" : " registros importados") + (r.skipped ? ". " + r.skipped + " ignorado(s) por já existirem ou estarem inválidos." : "."), n ? "ok" : "warn");
      } catch (e) { toast("Não foi possível ler esse arquivo. Use um backup exportado por esta página.", "err"); }
    };
    fr.onerror = function () { toast("Não foi possível abrir o arquivo.", "err"); };
    fr.readAsText(file);
  }

  /* =====================================================================
     Eventos
     ===================================================================== */

  function goPreset(id) {
    ST.preset = id; ST.granUser = false; ST.limit = 15; ST.incLimit = 8; ST.selCat = null;
    if (id === "custom") {
      if (!ST.custom.from) ST.custom.from = ST.today.slice(0, 8) + "01";
      if (!ST.custom.to) ST.custom.to = ST.today;
      $("#dFrom").value = ST.custom.from; $("#dTo").value = ST.custom.to;
    }
    render();
    var b = $('[data-preset="' + id + '"]'); if (b) b.focus();
  }

  document.addEventListener("click", function (e) {
    var t = e.target;
    var b = t.closest && t.closest("button, tr[data-key], path[data-cat]");
    if (!b) return;

    if (b.hasAttribute("data-preset")) return goPreset(b.getAttribute("data-preset"));
    if (b.id === "btnNew" || b.hasAttribute("data-new")) return openForm(null);
    if (b.id === "btnNewInc" || b.hasAttribute("data-new-inc")) return openIncForm(null);
    if (b.hasAttribute("data-iedit")) return openIncForm(b.getAttribute("data-iedit"));
    if (b.hasAttribute("data-idel")) return askDeleteIncome(b.getAttribute("data-idel"));
    if (b.hasAttribute("data-more-inc")) { ST.incLimit += 8; renderIncome(); return; }
    if (b.id === "btnBudget" || b.hasAttribute("data-budget")) return openBudget();
    if (b.id === "btnReport") return makeReport();
    if (b.hasAttribute("data-gran")) { ST.gran = b.getAttribute("data-gran"); ST.granUser = true; compute(); renderEvo(); var gb = $('[data-gran="' + ST.gran + '"]'); if (gb) gb.focus(); return; }
    if (b.hasAttribute("data-cat")) { var id = b.getAttribute("data-cat"); ST.selCat = ST.selCat === id ? null : id; renderCat(); var cb = $('#catSec button[data-cat="' + id + '"]'); if (cb) cb.focus(); return; }
    if (b.hasAttribute("data-cat-close")) { ST.selCat = null; renderCat(); return; }
    if (b.hasAttribute("data-more")) { ST.limit += 15; renderHistory(); return; }
    if (b.hasAttribute("data-edit")) { closeDlg($("#dlgDet")); return openForm(b.getAttribute("data-edit")); }
    if (b.hasAttribute("data-del")) return askDelete(b.getAttribute("data-del"));
    if (b.hasAttribute("data-endrec")) {
      var eid = b.getAttribute("data-endrec"), last = null;
      ST.real.forEach(function (x) { if (x.id === eid && (!last || x.date > last)) last = x.date; });
      if (last) { data.expenses = data.expenses.map(function (x) { if (x.id === eid) { x.end = last; } return x; }); persist(); closeDlg($("#dlgDet")); render(); toast("Recorrência encerrada. As ocorrências até " + G.brDate(last) + " foram mantidas.", "ok"); }
      return;
    }
    if (b.hasAttribute("data-export-json")) { download("cousner-gastos-" + ST.today + ".json", JSON.stringify({ app: "Cousner", version: 1, exportedAt: new Date().toISOString(), data: data }, null, 2), "application/json"); toast("Backup exportado.", "ok"); return; }
    if (b.hasAttribute("data-export-csv")) { download("cousner-gastos-" + ST.today + ".csv", G.toCSV(data), "text/csv;charset=utf-8"); toast("Planilha exportada.", "ok"); return; }
    if (b.hasAttribute("data-import")) { $("#fileImport").value = ""; $("#fileImport").click(); return; }
    if (b.hasAttribute("data-wipe")) return askWipe();
    if (b.hasAttribute("data-rmcat")) {
      var cid = b.getAttribute("data-rmcat");
      if (data.expenses.some(function (x) { return x.category === cid; })) return;
      data.categories = data.categories.filter(function (c) { return c.id !== cid; }); delete data.budget.cats[cid];
      persist(); render(); openBudget(); return;
    }
    if (b.hasAttribute("data-close")) { var d = b.closest("dialog"); if (d) closeDlg(d); return; }
    if (b.hasAttribute("data-det")) return openDetails(b.getAttribute("data-det"));
    if (b.tagName === "tr" || b.tagName === "TR") return openDetails(b.getAttribute("data-key"));
  });

  $("#cfOk").addEventListener("click", function () { var f = ST.confirmAction; ST.confirmAction = null; closeDlg($("#dlgConfirm")); if (f) f(); });
  $("#expForm").addEventListener("submit", saveExpense);
  $("#bdForm").addEventListener("submit", saveBudget);
  $("#fileImport").addEventListener("change", function (e) {
    var f = e.target.files && e.target.files[0];
    e.target.value = ""; // permite escolher o mesmo arquivo de novo
    importFile(f);
  });
  $("#fRec").addEventListener("change", syncRecurring);
  $("#incForm").addEventListener("submit", saveIncome);
  $("#iRec").addEventListener("change", syncIncRecurring);

  $("#fCat").addEventListener("change", function () {
    var isNew = $("#fCat").value === "__new__";
    $("#newCatRow").hidden = !isNew;
    if (isNew) $("#fNewCat").focus();
  });
  function addCategory() {
    var name = $("#fNewCat").value, err = G.validateCategoryName(name, ST.cats);
    $("#e-fNewCat").textContent = err; $("#w-fNewCat").classList.toggle("err", !!err);
    if (err) { $("#fNewCat").focus(); return; }
    var c = { id: "c_" + G.uid(), name: name.trim() };
    data.categories.push(c); persist();
    ST.cats = G.allCategories(data.categories); ST.map = G.catMap(ST.cats);
    fillCatSelect(c.id); $("#newCatRow").hidden = true; $("#fNewCat").value = "";
    toast("Categoria “" + c.name + "” criada.", "ok");
    renderHistory();
  }
  $("#btnAddCat").addEventListener("click", addCategory);
  $("#fNewCat").addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); addCategory(); } });

  $("#dFrom").addEventListener("change", function (e) { ST.custom.from = e.target.value; ST.granUser = false; ST.limit = 15; render(); });
  $("#dTo").addEventListener("change", function (e) { ST.custom.to = e.target.value; ST.granUser = false; ST.limit = 15; render(); });

  // pesquisa e filtros do histórico (atualiza só a tabela, sem perder o foco)
  document.addEventListener("input", function (e) { if (e.target.id === "hq") { ST.q = e.target.value; ST.limit = 15; renderHistory(); } });
  document.addEventListener("change", function (e) {
    var id = e.target.id;
    if (id === "hCatF") ST.fCat = e.target.value; else if (id === "hPayF") ST.fPay = e.target.value; else if (id === "hKindF") ST.fKind = e.target.value; else if (id === "hSort") ST.sort = e.target.value; else return;
    ST.limit = 15; renderHistory();
  });

  // janelas: fecham ao clicar fora (menos as de formulário, para não perder o que foi digitado)
  $$("dialog").forEach(function (d) {
    d.addEventListener("click", function (e) { if (e.target === d && d.id !== "dlgExp" && d.id !== "dlgBudget" && d.id !== "dlgInc") d.close(); });
  });

  var rt = null, lastW = 0;
  window.addEventListener("resize", function () {
    clearTimeout(rt);
    rt = setTimeout(function () { var h = $("#evoHost"); if (h && h.clientWidth !== lastW) { lastW = h.clientWidth; drawEvo(); } }, 120);
  });

  // se a aba ficar aberta até a virada do dia, atualiza ao voltar para ela
  document.addEventListener("visibilitychange", function () { if (!document.hidden && G.todayStr() !== ST.today && !document.querySelector("dialog[open]")) render(); });

  /* ---------- início ---------- */
  buildHistoryShell();
  render();

})();

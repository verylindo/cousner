/* Cousner — menu do celular e ano do rodapé (carregado em todas as páginas). */
(function () {
  "use strict";
  var btn = document.getElementById("navBtn"), nav = document.getElementById("nav");
  if (btn && nav) {
    btn.addEventListener("click", function () {
      var open = nav.classList.toggle("open");
      btn.setAttribute("aria-expanded", String(open));
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && nav.classList.contains("open")) { nav.classList.remove("open"); btn.setAttribute("aria-expanded", "false"); btn.focus(); }
    });
    if (!nav.querySelector('[data-cousner-plans]')) {
      var plans = document.createElement("a");
      plans.href = "/planos";
      plans.textContent = "Cousner Pro";
      plans.dataset.cousnerPlans = "true";
      nav.appendChild(plans);
      var account = document.createElement("a");
      account.href = "/conta";
      account.textContent = "Minha conta";
      account.dataset.cousnerAccount = "true";
      nav.appendChild(account);
    }
  }
  if (nav && !nav.querySelector('[data-cousner-open-pro]')) {
    var pro = document.createElement("a");
    pro.href = "/treinador";
    pro.textContent = "Treinador Pro grátis";
    pro.dataset.cousnerOpenPro = "true";
    nav.appendChild(pro);
  }
  var y = document.getElementById("year");
  if (y) y.textContent = new Date().getFullYear();
})();

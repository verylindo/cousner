import {
  ArrowRight,
  BookOpen,
  CalendarDays,
  ChartNoAxesCombined,
  Check,
  Goal,
  ShieldCheck,
  Sparkles,
  Wallet,
} from "lucide-react";
import { Link } from "wouter";
import { SiteLayout } from "@/components/SiteLayout";
import { PageMetadata } from "@/components/PageMetadata";

const freeTools = [
  { icon: ChartNoAxesCombined, title: "Calculadoras", text: "Simule juros compostos e organize um plano de aposentadoria." },
  { icon: Wallet, title: "Gastos e ganhos", text: "Acompanhe o orçamento, categorias, saldo e histórico." },
  { icon: Goal, title: "Metas e cofrinhos", text: "Defina objetivos, acompanhe aportes e veja o ritmo da meta." },
];

const trainerSteps = [
  ["01", "Entenda", "Veja o panorama da sua vida financeira com dados registrados e informações que você declarar."],
  ["02", "Priorize", "Organize os pontos de atenção em uma sequência clara, sem dicas soltas nem promessas."],
  ["03", "Acompanhe", "Transforme a prioridade em ação e compare sua evolução ao longo do tempo."],
];

export default function Home() {
  return (
    <SiteLayout>
      <PageMetadata title="Cousner — organize suas finanças com clareza" description="Ferramentas gratuitas para juros compostos, aposentadoria, gastos, ganhos e metas. Conheça o Treinador Financeiro Cousner Pro." />
      <main>
        <section className="hero-section">
          <div className="hero-copy">
            <div className="eyebrow"><span className="eyebrow-dot" /> ORGANIZE. ENTENDA. DECIDA.</div>
            <h1>Seu dinheiro merece <em>clareza.</em></h1>
            <p className="hero-lead">Comece com ferramentas gratuitas para cuidar do dia a dia. O Treinador Financeiro Pro também está aberto para qualquer pessoa, sem cadastro ou pagamento.</p>
            <div className="hero-actions">
              <a href="/gratis/index.html" className="button button-green">Usar grátis <ArrowRight size={17} /></a>
              <button type="button" className="button button-disabled" disabled aria-disabled="true">Em breve</button>
            </div>
            <div className="hero-trust"><ShieldCheck size={17} /><span>Sem conta para usar as ferramentas grátis. Seus registros ficam neste navegador.</span></div>
          </div>

          <div className="hero-visual" aria-label="Resumo do método do Treinador Financeiro">
            <div className="visual-glow" />
            <div className="coach-card">
            <div className="coach-card-top"><span className="coach-mark"><Sparkles size={16} /></span><span>COUSNER PRO</span><span className="coach-lock">GRÁTIS</span></div>
              <h2>Mais clareza.<br /><span>Um passo de cada vez.</span></h2>
              <div className="coach-line" />
              <div className="coach-flow">
                {trainerSteps.map(([num, title, desc]) => (
                  <div className="coach-step" key={num}>
                    <span className="step-num">{num}</span>
                    <div><strong>{title}</strong><p>{desc}</p></div>
                  </div>
                ))}
              </div>
              <div className="coach-card-bottom"><span>Diagnóstico baseado nos seus dados</span><span className="red-spark">✦</span></div>
            </div>
            <div className="float-note"><span className="float-note-icon"><Check size={16} /></span><span>Sem recomendar produtos<br />de investimento específicos</span></div>
          </div>
        </section>

        <section className="trust-strip">
          <div><strong>Pro aberto agora</strong><span>Sem cadastro ou pagamento</span></div>
          <div><strong>Seus dados, no seu navegador</strong><span>Sem envio automático para servidor</span></div>
          <div><strong>Decisões com contexto</strong><span>O Treinador explica o raciocínio</span></div>
        </section>

        <section className="section free-section" id="gratis">
          <div className="section-heading">
            <div><div className="eyebrow eyebrow-muted">UM BOM COMEÇO, SEM CUSTO</div><h2>O essencial para organizar <em>suas finanças.</em></h2></div>
            <a className="text-link" href="/gratis/index.html">Abrir as ferramentas <ArrowRight size={16} /></a>
          </div>
          <div className="free-grid">
            {freeTools.map(({ icon: Icon, title, text }) => (
              <article className="free-card" key={title}>
                <span className="free-icon"><Icon size={21} /></span><h3>{title}</h3><p>{text}</p>
              </article>
            ))}
          </div>
          <div className="free-callout"><div><strong>Comece agora, sem criar uma conta.</strong><span>Use as ferramentas no seu ritmo. Você pode exportar seus dados pelo próprio Cousner.</span></div><a href="/gratis/index.html" className="button button-light">Entrar no Cousner grátis <ArrowRight size={16} /></a></div>
        </section>

        <section className="section pro-section">
          <div className="pro-intro">
            <div className="eyebrow eyebrow-red"><Sparkles size={14} /> PARA IR ALÉM DO REGISTRO</div>
            <h2>Não é só saber <em>quanto saiu.</em><br />É entender o que fazer primeiro.</h2>
            <p>O Treinador Financeiro junta seu orçamento, suas metas e o que você informar sobre dívidas e patrimônio. Então mostra prioridades e um caminho possível — com os números à vista.</p>
            <button type="button" className="button button-disabled" disabled aria-disabled="true">Em breve</button>
          </div>
          <div className="pro-features">
            <div className="pro-feature"><span>01</span><div><strong>Diagnóstico explicado</strong><p>Critérios visíveis, informação faltante identificada e nenhuma nota quando não há dados suficientes.</p></div></div>
            <div className="pro-feature"><span>02</span><div><strong>Dívidas e patrimônio</strong><p>Compare estratégias de quitação, acompanhe ativos e passivos e visualize sua evolução.</p></div></div>
            <div className="pro-feature"><span>03</span><div><strong>Previsões e acompanhamento</strong><p>Antecipe períodos apertados, simule decisões de compra e registre o que mudou.</p></div></div>
            <div className="pro-feature"><span>04</span><div><strong>Aprendizado no seu momento</strong><p>Lições curtas ligadas à etapa financeira em que você está.</p></div></div>
            <div className="pro-note"><Check size={16} /><span>O Pro está aberto sem conta, assinatura ou cartão. Seus registros continuam somente neste navegador, como na versão entregue.</span></div>
          </div>
        </section>

        <section className="section how-section">
          <div className="section-heading centered-heading"><div className="eyebrow eyebrow-muted">CLAREZA SEM ATALHOS</div><h2>Um método simples. <em>Decisões suas.</em></h2><p>O Cousner organiza informações e explica possibilidades. Você decide o que faz sentido para sua vida.</p></div>
          <div className="how-grid">
            <article><span className="how-number">01</span><Wallet size={20} /><h3>Registre</h3><p>Comece pelo que já acontece: seus ganhos, gastos e objetivos.</p></article>
            <article><span className="how-number">02</span><ChartNoAxesCombined size={20} /><h3>Compreenda</h3><p>Veja padrões e prioridades em vez de encarar números soltos.</p></article>
            <article><span className="how-number">03</span><BookOpen size={20} /><h3>Aprenda</h3><p>Receba contexto para dar o próximo passo com mais segurança.</p></article>
            <article><span className="how-number">04</span><CalendarDays size={20} /><h3>Acompanhe</h3><p>Volte ao seu plano e observe o que mudou com o tempo.</p></article>
          </div>
        </section>

        <section className="closing-cta">
          <div><div className="eyebrow eyebrow-red">SEU PRÓXIMO PASSO COMEÇA AQUI</div><h2>Organize primeiro.<br /><em>Decida com clareza.</em></h2></div>
          <div><p>As ferramentas gratuitas e o Treinador Pro estão disponíveis agora, sem cadastro nem pagamento.</p><button type="button" className="button button-disabled" disabled aria-disabled="true">Em breve</button></div>
        </section>
      </main>
    </SiteLayout>
  );
}

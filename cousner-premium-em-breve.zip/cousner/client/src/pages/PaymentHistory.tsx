import { ArrowRight, Check } from "lucide-react";
import { Link } from "wouter";
import { PageMetadata } from "@/components/PageMetadata";
import { SiteLayout } from "@/components/SiteLayout";

export default function PaymentHistory() {
  return (
    <SiteLayout>
      <PageMetadata title="Cobranças — Cousner Pro gratuito" description="O Cousner Pro está aberto sem pagamento ou assinatura." noindex />
      <main className="payments-page">
        <div className="payments-heading">
          <div className="account-icon"><Check size={22} /></div>
          <div className="eyebrow eyebrow-muted">SEM COBRANÇA</div>
          <h1>O Cousner Pro está gratuito</h1>
          <p>Não há assinatura, checkout ou pagamento para usar o Treinador neste momento.</p>
          <button type="button" className="button button-disabled" disabled aria-disabled="true">Em breve</button>
        </div>
        <p className="payments-privacy">Os registros do Treinador Financeiro permanecem somente no navegador usado e não são sincronizados com uma conta.</p>
      </main>
    </SiteLayout>
  );
}

import { ArrowRight, Check, Minus, Sparkles } from "lucide-react";
import { SiteLayout } from "@/components/SiteLayout";
import { PageMetadata } from "@/components/PageMetadata";

const rows = [
  ["Calculadoras de juros compostos e aposentadoria", true, true],
  ["Gastos, ganhos, orçamento, gráficos e PDF", true, true],
  ["Metas e cofrinhos", true, true],
  ["Diagnóstico e prioridades do Treinador", false, true],
  ["Gestão e estratégias para quitar dívidas", false, true],
  ["Patrimônio, previsões e simulador de compras", false, true],
  ["Lições contextualizadas e histórico", false, true],
] as const;

export default function Plans() {
  return (
    <SiteLayout>
      <PageMetadata title="Cousner Pro aberto gratuitamente" description="Use o Treinador Financeiro Cousner Pro sem cadastro, assinatura ou pagamento." />
      <main className="plans-page">
        <div className="plans-hero">
          <div className="eyebrow eyebrow-muted">ACESSO GRATUITO · SEM CADASTRO</div>
          <h1>O Cousner Pro está <em>aberto para todos.</em></h1>
          <p>Use as ferramentas de organização financeira e o Treinador Pro sem criar conta, informar cartão ou iniciar uma assinatura. O Pro está grátis neste momento; não é uma promessa de gratuidade permanente.</p>
        </div>
        <div className="plan-cards">
          <article className="plan-card plan-free">
            <div className="plan-kicker">FERRAMENTAS DO DIA A DIA</div><h2>Grátis</h2><p className="plan-desc">Calculadoras e ferramentas para organizar suas finanças.</p>
            <div className="plan-price"><strong>R$ 0</strong><span>/ sem cadastro</span></div>
            <a href="/gratis/index.html" className="button button-outline button-full">Usar as ferramentas grátis <ArrowRight size={16} /></a>
            <ul><li><Check size={16} /> Calculadoras de investimentos e aposentadoria</li><li><Check size={16} /> Gastos, ganhos, orçamento e PDF</li><li><Check size={16} /> Metas e cofrinhos</li></ul>
          </article>
          <article className="plan-card plan-pro">
            <div className="plan-badge"><Sparkles size={14} /> COUSNER PRO · ABERTO</div><div className="plan-kicker">SEM PAGAMENTO</div><h2>Treinador Pro</h2><p className="plan-desc">Diagnóstico, prioridades e acompanhamento para sair do registro e chegar à decisão.</p>
            <div className="plan-price plan-price-pending"><strong>R$ 0</strong><span>/ grátis no momento</span></div>
            <button type="button" className="button button-full button-disabled" disabled aria-disabled="true">Em breve</button>
            <p className="plan-note">Sem login, assinatura ou cartão. Seus dados do Treinador ficam apenas no navegador usado.</p>
            <ul><li><Check size={16} /> Tudo o que existe nas ferramentas Grátis</li><li><Check size={16} /> Diagnóstico e prioridade financeira</li><li><Check size={16} /> Dívidas: avalanche x bola de neve</li><li><Check size={16} /> Patrimônio, previsão e simulador de compra</li><li><Check size={16} /> Educação contextual e histórico</li></ul>
          </article>
        </div>
        <section className="plan-comparison"><div className="comparison-heading"><div><div className="eyebrow eyebrow-muted">COMPARE COM CALMA</div><h2>O que você pode usar</h2></div><p>As ferramentas do dia a dia e todos os recursos do Treinador Pro estão abertos agora.</p></div><div className="comparison-table-wrap"><table className="comparison-table"><thead><tr><th>Recurso</th><th>Ferramentas grátis</th><th>Treinador Pro aberto</th></tr></thead><tbody>{rows.map(([name, free, pro]) => <tr key={name}><td>{name}</td><td>{free ? <Check className="table-check" size={18} /> : <Minus className="table-minus" size={18} />}</td><td>{pro ? <Check className="table-check" size={18} /> : <Minus className="table-minus" size={18} />}</td></tr>)}</tbody></table></div></section>
      </main>
    </SiteLayout>
  );
}

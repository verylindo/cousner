import { ArrowRight, Check, ShieldCheck } from "lucide-react";
import { Link } from "wouter";
import { SiteLayout } from "@/components/SiteLayout";
import { PageMetadata } from "@/components/PageMetadata";

export default function Account() {
  return (
    <SiteLayout>
      <PageMetadata title="Acesso Cousner — Pro gratuito" description="O Treinador Financeiro Cousner Pro está aberto sem login ou pagamento." noindex />
      <main className="account-page">
        <div className="account-card">
          <div className="account-icon"><ShieldCheck size={23} /></div>
          <div className="eyebrow eyebrow-muted">ACESSO ABERTO</div>
          <h1>Não precisa criar uma conta</h1>
          <div className="subscription-status status-active"><Check size={18} /><div><strong>Cousner Pro gratuito no momento</strong><span>Qualquer pessoa pode abrir o Treinador, sem assinatura ou cartão.</span></div></div>
          <div className="account-pending"><p>Seus registros do Treinador ficam apenas no armazenamento deste navegador e não são enviados para uma conta. Em um dispositivo ou perfil compartilhado, outras pessoas poderão ver esses registros.</p><button type="button" className="button button-full button-disabled" disabled aria-disabled="true">Em breve</button></div>
        </div>
      </main>
    </SiteLayout>
  );
}

import { ArrowRight, Check, ShieldCheck } from "lucide-react";
import { Link } from "wouter";
import { SiteLayout } from "@/components/SiteLayout";
import { PageMetadata } from "@/components/PageMetadata";

export default function Trainer() {
  return (
    <SiteLayout>
      <PageMetadata title="Treinador Financeiro — Cousner Pro gratuito" description="Acesse gratuitamente o Treinador Financeiro Cousner Pro, sem cadastro, conta ou pagamento." />
      <main className="trainer-shell">
        <div className="trainer-active">
          <div className="trainer-toolbar">
            <div><div className="eyebrow eyebrow-muted">COUSNER PRO · ACESSO GRATUITO</div><h1>Treinador Financeiro</h1></div>
            <span className="active-badge"><Check size={15} /> Aberto para todos</span>
          </div>
          <p className="trainer-privacy"><ShieldCheck size={16} /> Sem login, assinatura ou cartão. Seus dados ficam somente neste navegador, sem sincronização para o servidor. Outras pessoas que usam este mesmo perfil do navegador podem ver esses dados; exporte seu arquivo se quiser guardar uma cópia.</p>
          <p className="trainer-privacy">O Treinador Financeiro Cousner Pro chega em breve.</p>
          <div className="trainer-return"><Link href="/" className="text-link">Voltar ao início <ArrowRight size={16} /></Link></div>
        </div>
      </main>
    </SiteLayout>
  );
}

import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import Account from "@/pages/Account";
import Home from "@/pages/Home";
import Plans from "@/pages/Plans";
import Trainer from "@/pages/Trainer";
import PaymentHistory from "@/pages/PaymentHistory";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/planos" component={Plans} />
      <Route path="/conta" component={Account} />
      <Route path="/pagamentos" component={PaymentHistory} />
      <Route path="/treinador" component={Trainer} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

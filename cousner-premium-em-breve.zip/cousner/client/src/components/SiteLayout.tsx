import { Link } from "wouter";
import { ArrowRight, Menu } from "lucide-react";
import { useState, type ReactNode } from "react";

export function SiteHeader() {
  const [open, setOpen] = useState(false);

  return (
    <header className="site-nav">
      <div className="site-nav-inner">
        <Link href="/" className="brand" aria-label="Cousner, início">
          <img src="/gratis/img/logo-cousner.png" alt="Cousner" />
        </Link>
        <button
          className="menu-toggle"
          type="button"
          aria-label={open ? "Fechar menu" : "Abrir menu"}
          aria-expanded={open}
          onClick={() => setOpen(!open)}
        >
          <Menu size={22} />
        </button>
        <nav className={open ? "site-links is-open" : "site-links"} aria-label="Navegação principal">
          <a href="/gratis/index.html">Ferramentas grátis</a>
          <Link href="/treinador">Treinador Pro grátis</Link>
          <button type="button" className="nav-cta nav-cta-soon" disabled aria-disabled="true">Em breve</button>
        </nav>
      </div>
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="site-footer-new">
      <div className="footer-inner">
        <Link href="/" className="footer-brand">
          <img src="/gratis/img/logo-cousner.png" alt="Cousner" />
        </Link>
        <p>Organização financeira com clareza, sem promessas de rentabilidade.</p>
        <div className="footer-links">
          <a href="/gratis/index.html">Grátis</a>
          <Link href="/treinador">Treinador Pro grátis</Link>
          <Link href="/gratis/sobre.html">Sobre</Link>
        </div>
        <small>© {new Date().getFullYear()} Cousner · Conteúdo educacional. Simulações são estimativas.</small>
      </div>
    </footer>
  );
}

export function SiteLayout({ children }: { children: ReactNode }) {
  return (
    <div className="marketing-shell">
      <SiteHeader />
      {children}
      <SiteFooter />
    </div>
  );
}

import { useEffect } from "react";

type Props = { title: string; description: string; noindex?: boolean };

function setMeta(attribute: "name" | "property", key: string, content: string) {
  let element = document.head.querySelector<HTMLMetaElement>(`meta[${attribute}="${key}"]`);
  if (!element) {
    element = document.createElement("meta");
    element.setAttribute(attribute, key);
    document.head.appendChild(element);
  }
  element.content = content;
  return element;
}

export function PageMetadata({ title, description, noindex = false }: Props) {
  useEffect(() => {
    document.title = title;
    setMeta("name", "description", description);
    setMeta("property", "og:title", title);
    setMeta("property", "og:description", description);
    setMeta("property", "og:site_name", "Cousner");
    const robots = noindex ? setMeta("name", "robots", "noindex, nofollow, noarchive") : null;
    return () => {
      if (robots?.isConnected) robots.remove();
    };
  }, [title, description, noindex]);
  return null;
}

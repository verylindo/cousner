import { useState } from "react";
import { ArrowRight, LockKeyhole, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";

type Props = { full?: boolean; className?: string };

export function BillingCta({ full = false, className = "" }: Props) {
  const auth = useAuth();
  const offer = trpc.billing.offer.useQuery();
  const status = trpc.billing.status.useQuery(undefined, {
    enabled: !auth.loading && auth.isAuthenticated,
    retry: false,
  });
  const [pending, setPending] = useState(false);
  const buttonClass = `button ${full ? "button-full " : ""}${className}`.trim();

  const beginCheckout = async () => {
    const checkoutTab = window.open("about:blank", "_blank");
    if (checkoutTab) checkoutTab.opener = null;
    toast.info("Abrindo o checkout seguro do Stripe em uma nova aba.");
    setPending(true);
    try {
      const response = await fetch("/api/billing/checkout", {
        method: "POST",
        credentials: "include",
        headers: { Accept: "application/json" },
      });
      const payload = await response.json() as { url?: unknown; code?: string };
      if (!response.ok || typeof payload.url !== "string") throw new Error(payload.code || "checkout_unavailable");
      const checkoutUrl = new URL(payload.url);
      if (checkoutUrl.protocol !== "https:" || checkoutUrl.hostname !== "checkout.stripe.com") throw new Error("invalid_checkout_url");
      if (checkoutTab) checkoutTab.location.replace(checkoutUrl.toString());
      else {
        const fallback = window.open(checkoutUrl.toString(), "_blank", "noopener,noreferrer");
        if (!fallback) throw new Error("popup_blocked");
      }
    } catch {
      checkoutTab?.close();
      toast.error("A assinatura ainda não está disponível. Nenhum pagamento foi iniciado.");
    } finally {
      setPending(false);
    }
  };

  if (auth.loading || (auth.isAuthenticated && status.isLoading)) {
    return <button className={`${buttonClass} button-disabled`} disabled>Conferindo acesso…</button>;
  }
  if (status.data?.active) {
    return <Link href="/treinador" className={`${buttonClass} button-red`}>Abrir o Treinador <ArrowRight size={16} /></Link>;
  }
  if (!auth.isAuthenticated) {
    return <Link href="/conta" className={`${buttonClass} button-outline`}>Entrar para assinar <ArrowRight size={16} /></Link>;
  }
  if (status.error || !offer.data?.ready) {
    return <button type="button" className={`${buttonClass} button-disabled`} disabled aria-disabled="true"><LockKeyhole size={15} /> Assinatura ainda não disponível</button>;
  }

  return <button type="button" className={`${buttonClass} button-red`} onClick={() => void beginCheckout()} disabled={pending}>
    <Sparkles size={16} /> {pending ? "Abrindo checkout…" : "Assinar Cousner Pro"}
  </button>;
}

import { and, desc, eq, isNull } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { CheckoutIntent, InsertCheckoutIntent, InsertUser, users } from "../drizzle/schema";
import { ENV } from './_core/env';
import { InsertPaymentHistory, InsertSubscription, checkoutIntents, paymentHistory, stripeWebhookEvents, subscriptions } from "../drizzle/schema";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function getSubscriptionForUser(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.select().from(subscriptions).where(eq(subscriptions.userId, userId)).limit(1);
  return result[0];
}

export async function getSubscriptionForStripeId(stripeSubscriptionId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(subscriptions).where(eq(subscriptions.stripeSubscriptionId, stripeSubscriptionId)).limit(1);
  return result[0];
}

export async function getSubscriptionForStripeCustomer(stripeCustomerId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(subscriptions).where(eq(subscriptions.stripeCustomerId, stripeCustomerId)).limit(1);
  return result[0];
}

export async function getPaymentHistoryForUser(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.select({
    itemName: paymentHistory.itemName,
    amountTotal: paymentHistory.amountTotal,
    currency: paymentHistory.currency,
    paymentStatus: paymentHistory.paymentStatus,
    eventCreatedAt: paymentHistory.eventCreatedAt,
  }).from(paymentHistory)
    .where(eq(paymentHistory.userId, userId))
    .orderBy(desc(paymentHistory.eventCreatedAt))
    .limit(100);
}

export async function createCheckoutIntent(intent: InsertCheckoutIntent): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(checkoutIntents).values(intent);
}

export async function getCheckoutIntent(intentId: string): Promise<CheckoutIntent | undefined> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.select().from(checkoutIntents).where(eq(checkoutIntents.id, intentId)).limit(1);
  return result[0];
}

export async function attachCheckoutSession(intentId: string, sessionId: string, customerId?: string | null): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(checkoutIntents).set({
    stripeCheckoutSessionId: sessionId,
    ...(customerId ? { stripeCustomerId: customerId } : {}),
    updatedAt: new Date(),
  }).where(eq(checkoutIntents.id, intentId));
}

export async function failCheckoutIntent(intentId: string): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(checkoutIntents).set({ status: "failed", updatedAt: new Date() })
    .where(and(eq(checkoutIntents.id, intentId), eq(checkoutIntents.status, "pending"), isNull(checkoutIntents.stripeCheckoutSessionId)));
}

function isDuplicateEntry(error: unknown): boolean {
  if (!error || typeof error !== "object") return false;
  const candidate = error as { code?: string; errno?: number; cause?: unknown };
  return candidate.code === "ER_DUP_ENTRY" || candidate.errno === 1062 || isDuplicateEntry(candidate.cause);
}

/** Store verified Stripe events and subscription state atomically; duplicate deliveries are no-ops. */
export async function processStripeWebhookEvent(
  event: { id: string; type: string; created: number },
  update?: InsertSubscription,
  purchase?: InsertPaymentHistory,
  fulfillment?: { intentId: string; userId: number; priceId: string; sessionId: string; customerId: string; subscriptionId: string },
): Promise<boolean> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  try {
    let fulfillmentApplied = true;
    await db.transaction(async tx => {
      await tx.insert(stripeWebhookEvents).values({
        eventId: event.id,
        eventType: event.type,
        eventCreated: event.created,
      });

      if (fulfillment) {
        const intents = await tx.select().from(checkoutIntents)
          .where(eq(checkoutIntents.id, fulfillment.intentId)).limit(1).for("update");
        const intent = intents[0];
        const sessionMatches = intent && (!intent.stripeCheckoutSessionId || intent.stripeCheckoutSessionId === fulfillment.sessionId);
        const customerMatches = intent && (!intent.stripeCustomerId || intent.stripeCustomerId === fulfillment.customerId);
        const stateMatches = intent && (intent.status === "pending" || (intent.status === "fulfilled" && intent.stripeCheckoutSessionId === fulfillment.sessionId));
        const updateMatches = update && update.userId === fulfillment.userId && update.priceId === fulfillment.priceId &&
          update.stripeSubscriptionId === fulfillment.subscriptionId;
        const purchaseMatches = purchase && purchase.userId === fulfillment.userId &&
          purchase.stripeCheckoutSessionId === fulfillment.sessionId && purchase.stripeSubscriptionId === fulfillment.subscriptionId;
        const eligible = Boolean(intent && intent.userId === fulfillment.userId && intent.priceId === fulfillment.priceId &&
          sessionMatches && customerMatches && stateMatches && updateMatches && purchaseMatches && event.created * 1000 <= intent.expiresAt.getTime());
        if (!eligible) {
          fulfillmentApplied = false;
          return;
        }
        await tx.update(checkoutIntents).set({
          stripeCheckoutSessionId: fulfillment.sessionId,
          stripeCustomerId: fulfillment.customerId,
          stripeSubscriptionId: fulfillment.subscriptionId,
          status: "fulfilled",
          updatedAt: new Date(),
        }).where(eq(checkoutIntents.id, fulfillment.intentId));
      }

      if (purchase) {
        await tx.insert(paymentHistory).values(purchase).onDuplicateKeyUpdate({
          set: {
            userId: purchase.userId,
            ...(purchase.stripePaymentIntentId ? { stripePaymentIntentId: purchase.stripePaymentIntentId } : {}),
            ...(purchase.stripeCheckoutSessionId ? { stripeCheckoutSessionId: purchase.stripeCheckoutSessionId } : {}),
            ...(purchase.stripeInvoiceId ? { stripeInvoiceId: purchase.stripeInvoiceId } : {}),
            stripeSubscriptionId: purchase.stripeSubscriptionId ?? null,
            itemName: purchase.itemName,
            amountTotal: purchase.amountTotal,
            currency: purchase.currency,
            paymentStatus: purchase.paymentStatus,
            eventCreatedAt: purchase.eventCreatedAt,
          },
        });
      }

      if (!update) return;
      const current = await tx.select().from(subscriptions).where(eq(subscriptions.userId, update.userId)).limit(1);
      if (current[0] && current[0].lastStripeEventCreated > (update.lastStripeEventCreated ?? 0)) return;

      await tx.insert(subscriptions).values(update).onDuplicateKeyUpdate({
        set: {
          stripeCustomerId: update.stripeCustomerId ?? null,
          stripeSubscriptionId: update.stripeSubscriptionId ?? null,
          priceId: update.priceId ?? null,
          status: update.status,
          currentPeriodEnd: update.currentPeriodEnd ?? null,
          cancelAtPeriodEnd: update.cancelAtPeriodEnd ?? false,
          lastStripeEventCreated: update.lastStripeEventCreated ?? 0,
          updatedAt: new Date(),
        },
      });
    });
    return fulfillmentApplied;
  } catch (error) {
    if (isDuplicateEntry(error)) {
      const prior = await db.select({ eventId: stripeWebhookEvents.eventId })
        .from(stripeWebhookEvents)
        .where(eq(stripeWebhookEvents.eventId, event.id))
        .limit(1);
      if (prior.length) return false;
    }
    throw error;
  }
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    throw new Error("Database is not available");
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// TODO: add feature queries here as your schema grows.

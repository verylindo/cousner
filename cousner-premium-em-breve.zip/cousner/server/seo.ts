type SeoPage = {
  title: string;
  description: string;
  body: string;
  noindex?: boolean;
  status?: number;
};

const pages: Record<string, SeoPage> = {
  "/": {
    title: "Cousner — organize suas finanças com clareza",
    description: "Ferramentas grátis e Treinador Financeiro Pro gratuito, sem cadastro ou pagamento.",
    body: `<main class="initial-content" style="max-width:760px;margin:12vh auto;padding:24px;color:#14201A;font-family:Poppins,sans-serif"><p style="font-size:11px;letter-spacing:.16em;color:#D42B35">COUSNER · ORGANIZE. ENTENDA. DECIDA.</p><h1 style="font-size:clamp(38px,7vw,66px);line-height:1.12;font-weight:500">Seu dinheiro merece clareza.</h1><p style="max-width:610px;color:#55635B;line-height:1.8">Use gratuitamente as ferramentas de organização e o Treinador Financeiro Cousner Pro. Não é necessário criar conta ou informar pagamento.</p><p><a href="/gratis/index.html" style="color:#0C7A38">Abrir ferramentas grátis</a> · <a href="/treinador" style="color:#0C7A38">Abrir o Treinador Pro</a></p></main>`,
  },
  "/planos": {
    title: "Planos Cousner — Grátis e Pro",
    description: "Use sem custo as ferramentas do Cousner e o Treinador Financeiro Pro, sem cadastro ou pagamento.",
    body: `<main class="initial-content" style="max-width:760px;margin:10vh auto;padding:24px;color:#14201A;font-family:Poppins,sans-serif"><p style="font-size:11px;letter-spacing:.16em;color:#D42B35">ACESSO GRATUITO · SEM CADASTRO</p><h1 style="font-size:clamp(36px,6vw,58px);line-height:1.15;font-weight:500">O Cousner Pro está aberto para todos.</h1><p style="max-width:620px;color:#55635B;line-height:1.8">Use sem pagamento as calculadoras, as ferramentas de gastos e metas e o Treinador Financeiro Pro, com diagnóstico, dívidas, patrimônio, previsões e acompanhamento.</p><p>Não é necessária conta, assinatura ou cartão.</p><p><a href="/gratis/index.html" style="color:#0C7A38">Usar ferramentas grátis</a> · <a href="/treinador" style="color:#0C7A38">Abrir Treinador Pro</a></p></main>`,
  },
  "/conta": {
    title: "Minha conta — Cousner",
    description: "O Treinador Financeiro Cousner Pro está aberto sem login ou pagamento.",
    body: `<main class="initial-content" style="max-width:660px;margin:12vh auto;padding:24px;color:#14201A;font-family:Poppins,sans-serif"><h1>Não precisa criar uma conta</h1><p>O Treinador Pro está aberto gratuitamente, sem assinatura ou cartão.</p><p><a href="/treinador" style="color:#0C7A38">Abrir Treinador Pro</a></p></main>`,
    noindex: true,
  },
  "/treinador": {
    title: "Treinador Financeiro — Cousner Pro",
    description: "Treinador Financeiro Cousner Pro gratuito, aberto a todos e sem cadastro.",
    body: `<main class="initial-content" style="max-width:660px;margin:12vh auto;padding:24px;color:#14201A;font-family:Poppins,sans-serif"><h1>Treinador Financeiro Cousner Pro</h1><p>O acesso está liberado gratuitamente para qualquer visitante, sem conta ou pagamento.</p><p><a href="/paid/pro/treinador.html" style="color:#0C7A38">Abrir o Treinador</a></p></main>`,
  },
  "/pagamentos": {
    title: "Cobranças — Cousner Pro gratuito",
    description: "O Cousner Pro está aberto sem pagamento ou assinatura.",
    body: `<main class="initial-content" style="max-width:660px;margin:12vh auto;padding:24px;color:#14201A;font-family:Poppins,sans-serif"><h1>Nenhuma cobrança do Cousner Pro</h1><p>O Treinador Pro está aberto gratuitamente. Não há assinatura nem pagamento necessários para usar os recursos.</p><p><a href="/treinador" style="color:#0C7A38">Abrir o Treinador</a></p></main>`,
    noindex: true,
  },
  "/404": {
    title: "Página não encontrada — Cousner",
    description: "A página que você procurou não foi encontrada no Cousner.",
    body: `<main class="initial-content" style="max-width:660px;margin:12vh auto;padding:24px;color:#14201A;font-family:Poppins,sans-serif"><h1>Página não encontrada</h1><p>Este endereço não existe ou foi movido. Você pode voltar ao início ou abrir as ferramentas grátis.</p><p><a href="/" style="color:#0C7A38">Início</a> · <a href="/gratis/index.html" style="color:#0C7A38">Ferramentas grátis</a></p></main>`,
    noindex: true,
    status: 404,
  },
};

function escapeAttribute(value: string): string {
  return value.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function upsertMeta(html: string, attribute: "name" | "property", key: string, content: string): string {
  const escapedKey = key.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const expression = new RegExp(`<meta\\s+${attribute}=["']${escapedKey}["']\\s+content=["'][^"']*["']\\s*\\/?\\s*>`, "i");
  const tag = `<meta ${attribute}="${key}" content="${escapeAttribute(content)}" />`;
  return expression.test(html) ? html.replace(expression, tag) : html.replace("</head>", `    ${tag}\n  </head>`);
}

function configuredPublicOrigin(): string | undefined {
  try {
    const url = new URL(process.env.PUBLIC_APP_URL || "");
    if (url.protocol !== "https:" || url.username || url.password || url.pathname !== "/" || url.search || url.hash) return undefined;
    return url.origin;
  } catch {
    return undefined;
  }
}

export function renderInitialHtml(template: string, rawPath: string): { html: string; status: number; noindex: boolean } {
  let pathname = "/";
  try { pathname = decodeURIComponent(rawPath.split("?", 1)[0] || "/"); } catch { pathname = rawPath.split("?", 1)[0] || "/"; }
  const page = pages[pathname] ?? {
    title: "Página não encontrada — Cousner",
    description: "A página que você procurou não foi encontrada no Cousner.",
    body: pages["/404"].body,
    noindex: true,
    status: 404,
  };

  let html = template.replace(/<title>[\s\S]*?<\/title>/i, `<title>${escapeAttribute(page.title)}</title>`);
  html = upsertMeta(html, "name", "description", page.description);
  html = upsertMeta(html, "property", "og:title", page.title);
  html = upsertMeta(html, "property", "og:description", page.description);
  html = upsertMeta(html, "property", "og:site_name", "Cousner");
  html = upsertMeta(html, "property", "og:type", "website");
  html = html.replace(/\s*<meta\s+property=["']og:image["'][^>]*>/i, "");
  html = html.replace(/\s*<link\s+rel=["']canonical["'][^>]*>/i, "");
  html = html.replace(/\s*<meta\s+property=["']og:url["'][^>]*>/i, "");

  if (page.noindex) {
    html = upsertMeta(html, "name", "robots", "noindex, nofollow, noarchive");
  } else {
    html = html.replace(/\s*<meta\s+name=["']robots["'][^>]*>/i, "");
    html = upsertMeta(html, "name", "twitter:card", "summary");
    html = upsertMeta(html, "name", "twitter:title", page.title);
    html = upsertMeta(html, "name", "twitter:description", page.description);
    const origin = configuredPublicOrigin();
    if (origin) {
      const canonical = `${origin}${pathname === "/" ? "/" : pathname}`;
      html = upsertMeta(html, "property", "og:url", canonical);
      html = upsertMeta(html, "property", "og:image", `${origin}/gratis/img/og-cousner.png`);
      html = upsertMeta(html, "name", "twitter:card", "summary_large_image");
      html = upsertMeta(html, "name", "twitter:title", page.title);
      html = upsertMeta(html, "name", "twitter:description", page.description);
      html = upsertMeta(html, "name", "twitter:image", `${origin}/gratis/img/og-cousner.png`);
      const canonicalTag = `<link rel="canonical" href="${escapeAttribute(canonical)}" />`;
      html = html.replace("</head>", `    ${canonicalTag}\n  </head>`);
    }
  }

  const placeholder = /<div id="root">[\s\S]*?<\/div>/i;
  if (placeholder.test(html)) html = html.replace(placeholder, `<div id="root">${page.body}</div>`);
  return { html, status: page.status ?? 200, noindex: Boolean(page.noindex) };
}

import { createHmac, timingSafeEqual } from "node:crypto";

const SIGNATURE_TOLERANCE_SECONDS = 300;

export function verifyStripeSignature(
  rawBody: Buffer,
  signatureHeader: string | undefined,
  secret: string,
  nowSeconds = Math.floor(Date.now() / 1000),
): boolean {
  if (!signatureHeader || !secret || !Buffer.isBuffer(rawBody)) return false;
  const parts = signatureHeader.split(",").map(part => part.split("=", 2));
  const timestampText = parts.find(([key]) => key === "t")?.[1];
  const timestamp = Number(timestampText);
  if (!timestampText || !Number.isSafeInteger(timestamp) || Math.abs(nowSeconds - timestamp) > SIGNATURE_TOLERANCE_SECONDS) return false;

  const expected = createHmac("sha256", secret).update(`${timestamp}.`).update(rawBody).digest();
  const signatures = parts.filter(([key, value]) => key === "v1" && value).map(([, value]) => {
    try { return Buffer.from(value!, "hex"); } catch { return Buffer.alloc(0); }
  });
  return signatures.some(candidate => candidate.length === expected.length && timingSafeEqual(candidate, expected));
}

export function parseStripeEvent(rawBody: Buffer): { id: string; type: string; created: number; data?: { object?: Record<string, unknown> } } {
  const parsed: unknown = JSON.parse(rawBody.toString("utf8"));
  if (!parsed || typeof parsed !== "object") throw new Error("Invalid Stripe event");
  const event = parsed as Record<string, unknown>;
  if (typeof event.id !== "string" || typeof event.type !== "string" || typeof event.created !== "number") {
    throw new Error("Incomplete Stripe event");
  }
  return event as { id: string; type: string; created: number; data?: { object?: Record<string, unknown> } };
}

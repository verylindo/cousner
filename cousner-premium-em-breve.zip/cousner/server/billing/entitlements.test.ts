import { describe, expect, it } from "vitest";
import type { Request } from "express";
import { isProEntitled } from "./products";
import { checkoutMatchesIntent, checkoutUserId, subscriptionHasExpectedPrice } from "./routes";
import { getSessionCookieOptions } from "../_core/cookies";

describe("Cousner Pro entitlement binding", () => {
  it("grants only the active configured Pro price before period end", () => {
    expect(isProEntitled({ status: "active", priceId: "price_cousner", currentPeriodEnd: "2099-01-01T00:00:00.000Z" }, "price_cousner")).toBe(true);
    expect(isProEntitled({ status: "trialing", priceId: "price_cousner", currentPeriodEnd: null }, "price_cousner")).toBe(true);
  });

  it("denies other prices, expired periods, inactive states, and missing configuration", () => {
    expect(isProEntitled({ status: "active", priceId: "price_other", currentPeriodEnd: null }, "price_cousner")).toBe(false);
    expect(isProEntitled({ status: "active", priceId: "price_cousner", currentPeriodEnd: "2000-01-01T00:00:00.000Z" }, "price_cousner")).toBe(false);
    expect(isProEntitled({ status: "past_due", priceId: "price_cousner", currentPeriodEnd: null }, "price_cousner")).toBe(false);
    expect(isProEntitled({ status: "active", priceId: "price_cousner", currentPeriodEnd: null }, undefined)).toBe(false);
  });

  it("allows exactly one configured recurring price in a subscription", () => {
    expect(subscriptionHasExpectedPrice({ items: { data: [{ price: { id: "price_cousner" } }] } }, "price_cousner")).toBe(true);
    expect(subscriptionHasExpectedPrice({ items: { data: [{ price: { id: "price_other" } }] } }, "price_cousner")).toBe(false);
    expect(subscriptionHasExpectedPrice({ items: { data: [{ price: { id: "price_cousner" } }, { price: { id: "price_other" } }] } }, "price_cousner")).toBe(false);
    expect(subscriptionHasExpectedPrice({ items: { data: [{ price: { id: "price_cousner" } }] } }, undefined)).toBe(false);
  });

  it("requires the Checkout client reference and session metadata to name the same account", () => {
    expect(checkoutUserId({ client_reference_id: "17", metadata: { user_id: "17" } })).toBe(17);
    expect(checkoutUserId({ client_reference_id: "17", metadata: { user_id: "18" } })).toBeUndefined();
    expect(checkoutUserId({ metadata: { user_id: "17" } })).toBeUndefined();
    expect(checkoutUserId({ client_reference_id: "17" })).toBeUndefined();
  });

  it("fulfills only the unexpired server-created Checkout intent for its exact user, session, customer and price", () => {
    const intent = {
      id: "a".repeat(64), userId: 17, priceId: "price_cousner", status: "pending" as const,
      stripeCheckoutSessionId: null, stripeCustomerId: null, expiresAt: new Date("2099-01-01T00:00:00.000Z"),
    };
    const session = {
      id: "cs_cousner", client_reference_id: "17",
      metadata: { user_id: "17", checkout_intent_id: intent.id },
      mode: "subscription", status: "complete", payment_status: "paid",
      customer: "cus_cousner", subscription: "sub_cousner",
    };
    const eventCreated = 1_790_000_000;
    expect(checkoutMatchesIntent(session, intent, "price_cousner", eventCreated)).toBe(true);
    expect(checkoutMatchesIntent({ ...session, metadata: { ...session.metadata, checkout_intent_id: "wrong" } }, intent, "price_cousner", eventCreated)).toBe(false);
    expect(checkoutMatchesIntent(session, intent, "price_other", eventCreated)).toBe(false);
    expect(checkoutMatchesIntent({ ...session, id: "cs_other" }, { ...intent, stripeCheckoutSessionId: "cs_cousner" }, "price_cousner", eventCreated)).toBe(false);
    expect(checkoutMatchesIntent(session, { ...intent, stripeCustomerId: "cus_other" }, "price_cousner", eventCreated)).toBe(false);
    expect(checkoutMatchesIntent({ ...session, client_reference_id: "18" }, intent, "price_cousner", eventCreated)).toBe(false);
    expect(checkoutMatchesIntent({ ...session, payment_status: "unpaid" }, intent, "price_cousner", eventCreated)).toBe(false);
    expect(checkoutMatchesIntent(session, { ...intent, status: "failed" }, "price_cousner", eventCreated)).toBe(false);
    expect(checkoutMatchesIntent(session, { ...intent, expiresAt: new Date("2000-01-01T00:00:00.000Z") }, "price_cousner", eventCreated)).toBe(false);
  });
});

describe("session cookie policy", () => {
  const requestForHost = (hostname: string) => ({ hostname }) as Request;

  it("uses cross-site Secure cookies for Preview and non-Secure Lax cookies only for local development", () => {
    expect(getSessionCookieOptions(requestForHost("8328-preview.manus.computer"))).toMatchObject({ sameSite: "none", secure: true, httpOnly: true });
    expect(getSessionCookieOptions(requestForHost("localhost"))).toMatchObject({ sameSite: "lax", secure: false, httpOnly: true });
  });
});

import { createHmac } from "node:crypto";
import { describe, expect, it } from "vitest";
import { parseStripeEvent, verifyStripeSignature } from "./stripe";

const secret = "whsec_test_only";
const timestamp = 1_700_000_000;
const payload = Buffer.from(JSON.stringify({ id: "evt_1", type: "checkout.session.completed", created: timestamp }));

function signatureFor(body: Buffer, time = timestamp) {
  const digest = createHmac("sha256", secret).update(`${time}.`).update(body).digest("hex");
  return `t=${time},v1=${digest}`;
}

describe("Stripe webhook verification", () => {
  it("accepts a valid signature within the tolerance window", () => {
    expect(verifyStripeSignature(payload, signatureFor(payload), secret, timestamp + 10)).toBe(true);
  });

  it("rejects an altered body", () => {
    expect(verifyStripeSignature(Buffer.from(`${payload.toString()} `), signatureFor(payload), secret, timestamp)).toBe(false);
  });

  it("rejects an old timestamp", () => {
    expect(verifyStripeSignature(payload, signatureFor(payload), secret, timestamp + 301)).toBe(false);
  });

  it("rejects a missing or malformed signature", () => {
    expect(verifyStripeSignature(payload, undefined, secret, timestamp)).toBe(false);
    expect(verifyStripeSignature(payload, "t=bad,v1=00", secret, timestamp)).toBe(false);
  });

  it("parses only events with an identifier, type and timestamp", () => {
    expect(parseStripeEvent(payload).id).toBe("evt_1");
    expect(() => parseStripeEvent(Buffer.from("{}"))).toThrow("Incomplete Stripe event");
  });
});

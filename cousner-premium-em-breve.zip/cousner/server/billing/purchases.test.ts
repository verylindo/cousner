import { describe, expect, it } from "vitest";
import { purchaseFromCheckout, purchaseFromPaymentIntent } from "./routes";

const event = { created: 1_790_000_000 };

describe("Stripe purchase history mapping", () => {
  it("links a completed Checkout session to the matching application user", () => {
    const purchase = purchaseFromCheckout({
      id: "cs_test_1",
      client_reference_id: "42",
      metadata: { user_id: "42" },
      payment_intent: "pi_test_1",
      invoice: "in_test_1",
      subscription: "sub_test_1",
      amount_total: 1200,
      currency: "brl",
      payment_status: "paid",
    }, event, 42);
    expect(purchase).toMatchObject({
      id: "pi_test_1",
      stripePaymentIntentId: "pi_test_1",
      stripeCheckoutSessionId: "cs_test_1",
      stripeInvoiceId: "in_test_1",
      stripeSubscriptionId: "sub_test_1",
      userId: 42,
      itemName: "Cousner Pro",
      amountTotal: 1200,
      currency: "brl",
      paymentStatus: "paid",
      eventCreatedAt: new Date(event.created * 1000),
    });
  });

  it("fails closed when Checkout identity references disagree", () => {
    expect(purchaseFromCheckout({
      id: "cs_test_2",
      client_reference_id: "42",
      metadata: { user_id: "43" },
      amount_total: 1200,
      currency: "brl",
    }, event, 42)).toBeUndefined();
  });

  it("accepts a zero total for a no-payment-required trial session", () => {
    const purchase = purchaseFromCheckout({
      id: "cs_trial_1",
      client_reference_id: "42",
      metadata: { user_id: "42" },
      amount_total: 0,
      currency: "BRL",
      payment_status: "no_payment_required",
    }, event, 42);
    expect(purchase).toMatchObject({ amountTotal: 0, paymentStatus: "no_payment_required", currency: "brl" });
  });

  it("does not persist unsafe totals or invalid currency codes", () => {
    const base = { id: "cs_test_3", client_reference_id: "42", metadata: { user_id: "42" } };
    expect(purchaseFromCheckout({ ...base, amount_total: Number.MAX_SAFE_INTEGER + 1, currency: "brl" }, event, 42)).toBeUndefined();
    expect(purchaseFromCheckout({ ...base, amount_total: 1200, currency: "not-a-currency" }, event, 42)).toBeUndefined();
  });

  it("maps renewed/failed PaymentIntents to the account and stable invoice", () => {
    expect(purchaseFromPaymentIntent({
      id: "pi_renewal_1", invoice: "in_renewal_1", amount: 3500, amount_received: 3500, currency: "brl",
    }, event, "paid", 42, "sub_1")).toMatchObject({
      id: "pi_renewal_1", stripePaymentIntentId: "pi_renewal_1", stripeInvoiceId: "in_renewal_1",
      userId: 42, stripeSubscriptionId: "sub_1", amountTotal: 3500, currency: "brl", paymentStatus: "paid",
    });
    expect(purchaseFromPaymentIntent({
      id: "pi_failed_1", invoice: "in_failed_1", amount: 3500, currency: "brl",
    }, event, "failed", 42)).toMatchObject({ paymentStatus: "failed", amountTotal: 3500, userId: 42 });
  });
});

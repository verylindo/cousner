import express, { type Express, type Request } from "express";
import fs from "node:fs/promises";
import path from "node:path";
import { randomBytes } from "node:crypto";
import type { CheckoutIntent, InsertPaymentHistory, InsertSubscription, SubscriptionStatus } from "../../drizzle/schema";
import * as db from "../db";
import { sdk } from "../_core/sdk";
import { parseStripeEvent, verifyStripeSignature } from "./stripe";
import { COUSNER_PRO_PRODUCT, COUSNER_PRO_PUBLIC_FREE, getProBillingConfig, isProEntitled } from "./products";

const STRIPE_API = "https://api.stripe.com/v1";
const HANDLED_EVENTS = new Set([
  "payment_intent.succeeded",
  "payment_intent.payment_failed",
  "customer.subscription.created",
  "customer.subscription.updated",
  "customer.subscription.deleted",
  "checkout.session.completed",
]);
const ACTIVE_STATUSES = new Set<SubscriptionStatus>(["active", "trialing", "past_due", "canceled", "incomplete", "unpaid", "paused"]);
const PRO_ASSET_ROOT = path.resolve(process.cwd(), "server/protected");

type StripeEvent = ReturnType<typeof parseStripeEvent>;
type CheckoutFulfillment = {
  intentId: string;
  userId: number;
  priceId: string;
  sessionId: string;
  customerId: string;
  subscriptionId: string;
};

type CheckoutResolution = {
  update: InsertSubscription;
  purchase: InsertPaymentHistory;
  fulfillment: CheckoutFulfillment;
};

function getObject(value: unknown): Record<string, unknown> | undefined {
  return value && typeof value === "object" ? value as Record<string, unknown> : undefined;
}

function stringValue(value: unknown): string | undefined {
  return typeof value === "string" && value.length ? value : undefined;
}

function stripeId(value: unknown): string | null {
  if (typeof value === "string") return value;
  const object = getObject(value);
  return typeof object?.id === "string" ? object.id : null;
}

function getUserId(metadata: unknown): number | undefined {
  const userId = Number(getObject(metadata)?.user_id);
  return Number.isSafeInteger(userId) && userId > 0 ? userId : undefined;
}

function normalizeSubscriptionStatus(value: unknown): SubscriptionStatus {
  const status = stringValue(value);
  return status && ACTIVE_STATUSES.has(status as SubscriptionStatus) ? status as SubscriptionStatus : "incomplete";
}

export function subscriptionHasExpectedPrice(object: Record<string, unknown>, expectedPriceId: string | undefined): boolean {
  if (!expectedPriceId) return false;
  const items = getObject(object.items)?.data;
  if (!Array.isArray(items) || items.length !== 1) return false;
  const price = getObject(getObject(items[0])?.price);
  return stringValue(price?.id) === expectedPriceId;
}

function subscriptionWrite(
  object: Record<string, unknown>,
  event: { created: number },
  userId: number,
  expectedPriceId: string | undefined,
): InsertSubscription | undefined {
  const subscriptionId = stringValue(object.id);
  if (!subscriptionId) return undefined;
  const items = getObject(object.items)?.data;
  const firstItem = Array.isArray(items) ? getObject(items[0]) : undefined;
  const price = getObject(firstItem?.price);
  const periodEnd = Number(object.current_period_end);
  const endDate = Number.isFinite(periodEnd) && periodEnd > 0 ? new Date(periodEnd * 1000) : null;
  const priceMatches = subscriptionHasExpectedPrice(object, expectedPriceId);
  return {
    userId,
    stripeCustomerId: stripeId(object.customer),
    stripeSubscriptionId: subscriptionId,
    priceId: stringValue(price?.id) ?? null,
    status: priceMatches ? normalizeSubscriptionStatus(object.status) : "incomplete",
    currentPeriodEnd: endDate && Number.isFinite(endDate.getTime()) ? endDate : null,
    cancelAtPeriodEnd: object.cancel_at_period_end === true,
    lastStripeEventCreated: event.created,
  };
}

export function checkoutUserId(object: Record<string, unknown>): number | undefined {
  const metadataUserId = getUserId(object.metadata);
  const reference = Number(object.client_reference_id);
  const referenceUserId = Number.isSafeInteger(reference) && reference > 0 ? reference : undefined;
  return metadataUserId && referenceUserId === metadataUserId ? metadataUserId : undefined;
}

export function checkoutMatchesIntent(
  session: Record<string, unknown>,
  intent: Pick<CheckoutIntent, "id" | "userId" | "priceId" | "stripeCheckoutSessionId" | "stripeCustomerId" | "status" | "expiresAt">,
  expectedPriceId: string | undefined,
  eventCreated: number,
): boolean {
  const metadata = getObject(session.metadata);
  const sessionId = stringValue(session.id);
  const sessionUserId = checkoutUserId(session);
  const customerId = stripeId(session.customer);
  const subscriptionId = stripeId(session.subscription);
  const expiry = new Date(intent.expiresAt).getTime();
  const intentStateMatches = intent.status === "pending" ||
    (intent.status === "fulfilled" && intent.stripeCheckoutSessionId === sessionId);
  return Boolean(
    expectedPriceId && intent.priceId === expectedPriceId &&
    sessionId && sessionUserId === intent.userId && customerId && subscriptionId &&
    stringValue(metadata?.checkout_intent_id) === intent.id &&
    session.mode === COUSNER_PRO_PRODUCT.checkoutMode && session.status === "complete" &&
    ["paid", "no_payment_required"].includes(stringValue(session.payment_status) || "") &&
    intentStateMatches && (!intent.stripeCheckoutSessionId || intent.stripeCheckoutSessionId === sessionId) &&
    (!intent.stripeCustomerId || intent.stripeCustomerId === customerId) &&
    Number.isSafeInteger(eventCreated) && eventCreated > 0 && Number.isFinite(expiry) && eventCreated * 1000 <= expiry
  );
}

function safeAmount(value: unknown): number | undefined {
  return typeof value === "number" && Number.isSafeInteger(value) && value >= 0 ? value : undefined;
}

function paymentCurrency(value: unknown): string | undefined {
  const currency = stringValue(value)?.toLowerCase();
  return currency && /^[a-z]{3}$/.test(currency) ? currency : undefined;
}

export function purchaseFromCheckout(
  object: Record<string, unknown>,
  event: { created: number },
  verifiedUserId: number,
): InsertPaymentHistory | undefined {
  const sessionId = stringValue(object.id);
  const userId = checkoutUserId(object);
  const amountTotal = object.amount_total === null ? 0 : safeAmount(object.amount_total);
  const currency = paymentCurrency(object.currency);
  if (!sessionId || !userId || userId !== verifiedUserId || amountTotal === undefined || !currency || !Number.isSafeInteger(event.created) || event.created <= 0) return undefined;
  const paymentIntentId = stripeId(object.payment_intent);
  return {
    id: paymentIntentId ?? sessionId,
    stripePaymentIntentId: paymentIntentId,
    stripeCheckoutSessionId: sessionId,
    stripeInvoiceId: stripeId(object.invoice),
    userId,
    stripeSubscriptionId: stripeId(object.subscription),
    itemName: COUSNER_PRO_PRODUCT.name,
    amountTotal,
    currency,
    paymentStatus: ["paid", "unpaid", "no_payment_required"].includes(stringValue(object.payment_status) || "")
      ? stringValue(object.payment_status)!
      : "processing",
    eventCreatedAt: new Date(event.created * 1000),
  };
}

export function purchaseFromPaymentIntent(
  object: Record<string, unknown>,
  event: { created: number },
  paymentStatus: "paid" | "failed",
  userId: number,
  subscriptionId?: string | null,
): InsertPaymentHistory | undefined {
  const paymentIntentId = stringValue(object.id);
  const amountTotal = paymentStatus === "paid"
    ? safeAmount(object.amount_received) ?? safeAmount(object.amount)
    : safeAmount(object.amount);
  const currency = paymentCurrency(object.currency);
  if (!paymentIntentId || amountTotal === undefined || !currency || !Number.isSafeInteger(event.created) || event.created <= 0) return undefined;
  return {
    id: paymentIntentId,
    stripePaymentIntentId: paymentIntentId,
    stripeCheckoutSessionId: null,
    stripeInvoiceId: stripeId(object.invoice),
    userId,
    stripeSubscriptionId: subscriptionId ?? stripeId(object.subscription),
    itemName: COUSNER_PRO_PRODUCT.name,
    amountTotal,
    currency,
    paymentStatus,
    eventCreatedAt: new Date(event.created * 1000),
  };
}

async function retrieveStripeObject(pathname: string, secretKey: string): Promise<Record<string, unknown>> {
  const response = await fetch(`${STRIPE_API}${pathname}`, {
    method: "GET",
    headers: { Authorization: `Bearer ${secretKey}` },
  });
  const payload = getObject(await response.json());
  if (!response.ok || !payload) throw new Error("Stripe object retrieval failed");
  return payload;
}

async function resolveCheckoutFulfillment(
  session: Record<string, unknown>,
  event: StripeEvent,
  priceId: string,
  secretKey: string,
): Promise<CheckoutResolution | undefined> {
  const metadata = getObject(session.metadata);
  const intentId = stringValue(metadata?.checkout_intent_id);
  const userId = checkoutUserId(session);
  const sessionId = stringValue(session.id);
  const customerId = stripeId(session.customer);
  const subscriptionId = stripeId(session.subscription);
  if (!intentId || !userId || !sessionId || !customerId || !subscriptionId) return undefined;

  const intent = await db.getCheckoutIntent(intentId);
  if (!intent || !checkoutMatchesIntent(session, intent, priceId, event.created)) return undefined;

  const subscription = await retrieveStripeObject(`/subscriptions/${encodeURIComponent(subscriptionId)}`, secretKey);
  const subscriptionMetadata = getObject(subscription.metadata);
  if (stringValue(subscription.id) !== subscriptionId || stripeId(subscription.customer) !== customerId) return undefined;
  if (getUserId(subscription.metadata) !== userId || stringValue(subscriptionMetadata?.checkout_intent_id) !== intentId) return undefined;
  if (!subscriptionHasExpectedPrice(subscription, priceId)) return undefined;

  const update = subscriptionWrite(subscription, event, userId, priceId);
  const purchase = purchaseFromCheckout(session, event, userId);
  if (!update || !purchase) return undefined;

  return {
    update,
    purchase,
    fulfillment: { intentId, userId, priceId, sessionId, customerId, subscriptionId },
  };
}

function invoiceSubscriptionId(invoice: Record<string, unknown>): string | null {
  const topLevel = stripeId(invoice.subscription);
  if (topLevel) return topLevel;
  const parent = getObject(invoice.parent);
  const details = getObject(parent?.subscription_details);
  return stripeId(details?.subscription);
}

async function retrieveSubscriptionInvoice(
  invoiceId: string,
  customerId: string,
  subscriptionId: string,
  secretKey: string,
): Promise<Record<string, unknown> | undefined> {
  const invoice = await retrieveStripeObject(`/invoices/${encodeURIComponent(invoiceId)}`, secretKey);
  if (stripeId(invoice.customer) !== customerId || invoiceSubscriptionId(invoice) !== subscriptionId) return undefined;
  return invoice;
}

export function registerStripeWebhook(app: Express) {
  app.post("/api/stripe/webhook", express.raw({ type: "application/json", limit: "1mb" }), async (req, res) => {
    if (COUSNER_PRO_PUBLIC_FREE) return res.status(200).json({ received: true, billing: "disabled" });
    const billing = getProBillingConfig();
    const secret = billing.webhookSecret;
    if (!secret) return res.status(503).json({ code: "webhook_not_configured" });
    if (!Buffer.isBuffer(req.body)) return res.status(400).json({ code: "invalid_webhook_body" });
    if (!verifyStripeSignature(req.body, req.get("stripe-signature"), secret)) {
      return res.status(400).json({ code: "invalid_signature" });
    }

    let event: StripeEvent;
    try {
      event = parseStripeEvent(req.body);
    } catch {
      return res.status(400).json({ code: "invalid_event" });
    }

    try {
      let update: InsertSubscription | undefined;
      let purchase: InsertPaymentHistory | undefined;
      let fulfillment: CheckoutFulfillment | undefined;
      const object = getObject(event.data?.object);

      if (event.type.startsWith("customer.subscription.") && HANDLED_EVENTS.has(event.type) && object) {
        const subscriptionId = stringValue(object.id);
        const customerId = stripeId(object.customer);
        const existing = subscriptionId ? await db.getSubscriptionForStripeId(subscriptionId) : undefined;
        // Subscription metadata alone never grants access. The ID/customer pair must already be
        // anchored to a verified Checkout fulfillment in the database.
        if (existing && customerId && existing.stripeCustomerId === customerId) {
          update = subscriptionWrite(object, event, existing.userId, billing.priceId);
        }
      }

      if (event.type === "checkout.session.completed" && object) {
        if (!billing.secretKey || !billing.priceId) {
          return res.status(503).json({ code: "fulfillment_not_configured" });
        }
        const resolution = await resolveCheckoutFulfillment(object, event, billing.priceId, billing.secretKey);
        if (resolution) {
          update = resolution.update;
          purchase = resolution.purchase;
          fulfillment = resolution.fulfillment;
        }
      }

      if ((event.type === "payment_intent.succeeded" || event.type === "payment_intent.payment_failed") && object) {
        const customerId = stripeId(object.customer);
        const invoiceId = stripeId(object.invoice);
        const existing = customerId ? await db.getSubscriptionForStripeCustomer(customerId) : undefined;
        const invoiceEligible = Boolean(existing && customerId && existing.stripeCustomerId === customerId &&
          existing.stripeSubscriptionId && invoiceId && billing.secretKey &&
          subscriptionHasExpectedPrice({
            items: { data: [{ price: { id: existing.priceId } }] },
          }, billing.priceId));
        if (invoiceEligible && existing && customerId && invoiceId && existing.stripeSubscriptionId && billing.secretKey) {
          const invoice = await retrieveSubscriptionInvoice(invoiceId, customerId, existing.stripeSubscriptionId, billing.secretKey);
          if (invoice) {
            purchase = purchaseFromPaymentIntent(
              object,
              event,
              event.type === "payment_intent.succeeded" ? "paid" : "failed",
              existing.userId,
              existing.stripeSubscriptionId,
            );
          }
        }
      }

      if (!HANDLED_EVENTS.has(event.type)) return res.status(200).json({ received: true });
      await db.processStripeWebhookEvent(event, update, purchase, fulfillment);
      return res.status(200).json({ received: true });
    } catch {
      // Never log customer payloads, subscription values, or financial information.
      console.error("[Stripe webhook] Verified event could not be stored or reconciled");
      return res.status(500).json({ code: "webhook_processing_failed" });
    }
  });
}

function isStripeCheckoutUrl(raw: unknown): raw is string {
  if (typeof raw !== "string") return false;
  try {
    const url = new URL(raw);
    return url.protocol === "https:" && url.hostname === "checkout.stripe.com" && !url.username && !url.password;
  } catch {
    return false;
  }
}

export function registerBillingCheckout(app: Express) {
  app.post("/api/billing/checkout", async (req, res) => {
    if (COUSNER_PRO_PUBLIC_FREE) return res.status(410).json({ code: "pro_public_free" });
    let user;
    try {
      user = await sdk.authenticateRequest(req);
    } catch {
      return res.status(401).json({ code: "authentication_required" });
    }

    const billing = getProBillingConfig();
    const origin = billing.publicOrigin;
    if (!billing.ready || !origin || req.get("origin") !== origin) {
      return res.status(503).json({ code: "billing_not_configured" });
    }
    const secretKey = billing.secretKey;
    const priceId = billing.priceId;
    if (!secretKey || !priceId) return res.status(503).json({ code: "billing_not_configured" });

    let intentCreated = false;
    let sessionCreated = false;
    let intentId: string | undefined;
    try {
      const existing = await db.getSubscriptionForUser(user.id);
      if (isProEntitled(existing, priceId)) return res.status(409).json({ code: "subscription_already_active" });

      intentId = randomBytes(32).toString("hex");
      const expiresAt = new Date(Date.now() + 48 * 60 * 60 * 1000);
      await db.createCheckoutIntent({ id: intentId, userId: user.id, priceId, expiresAt });
      intentCreated = true;

      const params = new URLSearchParams();
      params.set("mode", COUSNER_PRO_PRODUCT.checkoutMode);
      params.append("payment_method_types[]", "card");
      params.set("allow_promotion_codes", "true");
      params.set("client_reference_id", String(user.id));
      params.set("line_items[0][price]", priceId);
      params.set("line_items[0][quantity]", "1");
      params.set("success_url", `${origin}/conta?checkout=return&session_id={CHECKOUT_SESSION_ID}`);
      params.set("cancel_url", `${origin}/planos?checkout=cancelled`);
      params.set("metadata[user_id]", String(user.id));
      params.set("metadata[checkout_intent_id]", intentId);
      params.set("subscription_data[metadata][user_id]", String(user.id));
      params.set("subscription_data[metadata][checkout_intent_id]", intentId);
      if (user.email) {
        params.set("customer_email", user.email);
        params.set("metadata[customer_email]", user.email);
        params.set("subscription_data[metadata][customer_email]", user.email);
      }
      if (user.name) {
        params.set("metadata[customer_name]", user.name);
        params.set("subscription_data[metadata][customer_name]", user.name);
      }

      const response = await fetch(`${STRIPE_API}/checkout/sessions`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${secretKey}`,
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: params,
      });
      const result = await response.json() as { id?: unknown; url?: unknown; customer?: unknown };
      const sessionId = stringValue(result.id);
      sessionCreated = Boolean(sessionId);
      if (!response.ok || !sessionId || !isStripeCheckoutUrl(result.url)) {
        await db.failCheckoutIntent(intentId);
        return res.status(502).json({ code: "checkout_unavailable" });
      }
      await db.attachCheckoutSession(intentId, sessionId, stripeId(result.customer));
      res.set("Cache-Control", "no-store");
      return res.json({ url: result.url });
    } catch {
      if (intentCreated && !sessionCreated && intentId) {
        try { await db.failCheckoutIntent(intentId); } catch { /* Keep the response generic. */ }
      }
      return res.status(503).json({ code: "checkout_unavailable" });
    }
  });
}

export function registerPublicProAssets(app: Express) {
  if (!COUSNER_PRO_PUBLIC_FREE) return;
  app.use("/paid/pro", async (req: Request, res) => {
    // Versão "Em breve": o Pro não é entregue.
    return res.status(404).type("text").send("Em breve.");
  });
  app.use("/paid/pro", async (req: Request, res) => {
    res.set({
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
      "Referrer-Policy": "no-referrer",
      "X-Robots-Tag": "noindex, nofollow, noarchive",
    });
    if (req.method !== "GET" && req.method !== "HEAD") return res.status(405).end();
    try {
      const decoded = decodeURIComponent(req.path);
      const relative = decoded.replace(/^\/+/, "") || "treinador.html";
      const candidate = path.resolve(PRO_ASSET_ROOT, relative);
      const root = await fs.realpath(PRO_ASSET_ROOT);
      const resolved = await fs.realpath(candidate);
      if (!resolved.startsWith(`${root}${path.sep}`)) return res.status(404).end();
      const info = await fs.stat(resolved);
      if (!info.isFile()) return res.status(404).end();
      if (path.extname(resolved).toLowerCase() === ".html") {
        const html = await fs.readFile(resolved, "utf8");
        if (!html.includes("</head>")) return res.status(500).end();
        return res.type("html").send(html.replace("</head>", '<meta name="cousner-pro-access" content="public-free">\n</head>'));
      }
      return res.sendFile(resolved, error => {
        if (error && !res.headersSent) res.status(404).end();
      });
    } catch {
      return res.status(404).type("text").send("Arquivo não encontrado.");
    }
  });
}

export function registerProAssetGate(app: Express) {
  app.use("/paid/pro", async (req: Request, res, _next) => {
    res.set({
      "Cache-Control": "private, no-store, max-age=0",
      "X-Content-Type-Options": "nosniff",
      "Referrer-Policy": "no-referrer",
      "X-Robots-Tag": "noindex, nofollow, noarchive",
    });
    if (req.method !== "GET" && req.method !== "HEAD") return res.status(405).end();

    let user;
    try {
      user = await sdk.authenticateRequest(req);
    } catch {
      return res.status(401).type("text").send("Entre com uma conta Cousner para acessar esta área.");
    }

    try {
      const subscription = await db.getSubscriptionForUser(user.id);
      if (!isProEntitled(subscription, getProBillingConfig().priceId)) {
        return res.status(403).type("text").send("Acesso Cousner Pro não autorizado.");
      }

      const decoded = decodeURIComponent(req.path);
      const relative = decoded.replace(/^\/+/, "") || "treinador.html";
      const candidate = path.resolve(PRO_ASSET_ROOT, relative);
      if (!candidate.startsWith(`${PRO_ASSET_ROOT}${path.sep}`)) return res.status(404).end();
      const info = await fs.stat(candidate);
      if (!info.isFile()) return res.status(404).end();
      if (path.extname(candidate).toLowerCase() === ".html") {
        const html = await fs.readFile(candidate, "utf8");
        if (!html.includes("</head>")) return res.status(500).end();
        return res.type("html").send(html.replace("</head>", '<meta name="cousner-pro-access" content="verified">\n</head>'));
      }
      return res.sendFile(candidate, error => {
        if (error && !res.headersSent) res.status(404).end();
      });
    } catch {
      return res.status(503).type("text").send("Não foi possível confirmar sua assinatura agora.");
    }
  });
}

// Decisão atual do proprietário: o Pro fica aberto para qualquer visitante, sem cobrança.
// Não derive este modo de uma variável de ambiente controlável externamente.
export const COUSNER_PRO_PUBLIC_FREE = true;

export const COUSNER_PRO_PRODUCT = {
  name: "Cousner Pro",
  checkoutMode: "subscription" as const,
};

export type ProBillingConfig = {
  ready: boolean;
  displayPrice: string | null;
  priceId: string | undefined;
  secretKey: string | undefined;
  webhookSecret: string | undefined;
  publicOrigin: string | undefined;
};

export function isProEntitled(
  subscription: { status?: string | null; priceId?: string | null; currentPeriodEnd?: Date | string | null } | undefined,
  expectedPriceId: string | undefined,
  now = Date.now(),
): boolean {
  if (!subscription || !expectedPriceId || subscription.priceId !== expectedPriceId) return false;
  if (subscription.status !== "active" && subscription.status !== "trialing") return false;
  if (subscription.currentPeriodEnd == null) return true;
  const periodEnd = new Date(subscription.currentPeriodEnd).getTime();
  return Number.isFinite(periodEnd) && periodEnd > now;
}

function parsePublicOrigin(raw: string | undefined, nodeEnv: string | undefined): string | undefined {
  try {
    if (!raw) return undefined;
    const url = new URL(raw);
    if (url.username || url.password || url.pathname !== "/" || url.search || url.hash) return undefined;
    if (url.protocol !== "https:" && !(nodeEnv === "development" && url.protocol === "http:" && ["localhost", "127.0.0.1"].includes(url.hostname))) return undefined;
    return url.origin;
  } catch {
    return undefined;
  }
}

export function getProBillingConfig(env: NodeJS.ProcessEnv = process.env): ProBillingConfig {
  const secretKey = env.STRIPE_SECRET_KEY?.trim() || undefined;
  const webhookSecret = env.STRIPE_WEBHOOK_SECRET?.trim() || undefined;
  const priceId = env.STRIPE_PRO_PRICE_ID?.trim() || undefined;
  const displayPrice = env.PRO_PRICE_DISPLAY?.trim().slice(0, 80) || undefined;
  const publicOrigin = parsePublicOrigin(env.PUBLIC_APP_URL, env.NODE_ENV);
  const ready = Boolean(secretKey && webhookSecret && priceId && displayPrice && publicOrigin);
  return { ready, displayPrice: ready ? displayPrice! : null, priceId, secretKey, webhookSecret, publicOrigin };
}

/*
 * Cousner Pro — Educação financeira contextual.
 * Cada lição aparece conforme o que o diagnóstico encontrou. Os números dos exemplos são
 * calculados aqui, na hora, com as mesmas fórmulas do restante do Cousner (nada é digitado à mão).
 * Conteúdo educacional: não é recomendação individual de investimento.
 */
(function (root) {
  "use strict";

  var CB = root.CB, T = root.CBTreinador;
  function money(v) { return CB.formatBRL(v); }
  function pct(v, d) { return (v * 100).toLocaleString("pt-BR", { minimumFractionDigits: d || 0, maximumFractionDigits: d || 0 }) + "%"; }

  var LESSONS = [
    {
      id: "juros_compostos", title: "Juros compostos: a favor e contra você", minutes: 3,
      tags: ["juros_altos", "juros_moderados", "deficit"],
      body: [
        "Nos juros compostos, os juros de cada mês são calculados sobre o saldo que já inclui os juros dos meses anteriores. Por isso o valor cresce cada vez mais rápido.",
        "O mesmo mecanismo que faz um investimento crescer faz uma dívida crescer. A diferença é o lado em que você está: quem investe recebe os juros, quem deve paga.",
        "Quanto maior a taxa e quanto mais tempo passa, maior o efeito. Por isso dívidas com juros altos devem ser tratadas primeiro."
      ],
      example: function () {
        var a = 1000 * Math.pow(1.03, 12), b = 1000 * Math.pow(1.12, 12);
        return "Exemplo: uma dívida de " + money(1000) + " sem nenhum pagamento por 12 meses vira " + money(a) + " a 3% ao mês e " + money(b) + " a 12% ao mês: " + (b / a).toLocaleString("pt-BR", { maximumFractionDigits: 1 }) + " vezes mais.";
      }
    },
    {
      id: "credito_cartao", title: "Cartão, rotativo e cheque especial", minutes: 3,
      tags: ["juros_altos", "deficit", "comprometimento"],
      body: [
        "O crédito rotativo do cartão e o cheque especial estão entre os créditos mais caros. Eles são pensados para uso muito curto, não para financiar o mês.",
        "Pagar apenas o mínimo da fatura significa que o restante vira dívida com juros altos. Se o pagamento for menor que os juros do mês, o saldo cresce mesmo pagando.",
        "Antes de parcelar a fatura ou entrar no cheque especial, compare o custo total (CET) com outras opções, como um empréstimo com taxa menor para quitar a dívida cara."
      ],
      example: function () {
        var bal = 2000, r = 0.12, juros = bal * r;
        return "Exemplo: com saldo de " + money(bal) + " a 12% ao mês, só os juros do mês são " + money(juros) + ". Se você pagar menos que isso, a dívida aumenta; se pagar exatamente isso, ela fica parada.";
      }
    },
    {
      id: "negociar", title: "Como negociar dívidas", minutes: 4,
      tags: ["juros_altos", "juros_moderados", "taxa_desconhecida"],
      body: [
        "1. Levante tudo: quanto você deve, a quem, a taxa e as parcelas. É o que o Cousner pede na aba Dívidas.",
        "2. Saiba quanto pode pagar por mês sem faltar o essencial (moradia, alimentação, saúde, transporte).",
        "3. Procure o credor pelos canais oficiais. Peça o saldo para pagamento à vista e as condições de parcelamento, compare o custo total e peça desconto: dívidas antigas costumam ter margem.",
        "4. Só aceite o que cabe no orçamento e peça tudo por escrito. Guarde os comprovantes de pagamento.",
        "5. Desconfie de contatos que cobram taxa antecipada ou mandam boleto por canais não oficiais: confirme sempre pelo site ou aplicativo do credor."
      ],
      example: function () {
        var d = 5000, antes = d * 0.1, depois = (d * 0.6) * 0.1;
        return "Exemplo: se uma dívida de " + money(d) + " com juros de 10% ao mês for quitada com 40% de desconto, o saldo cai para " + money(d * 0.6) + " e os juros mensais, de " + money(antes) + " para " + money(depois) + ".";
      }
    },
    {
      id: "avalanche_neve", title: "Avalanche x bola de neve", minutes: 3,
      tags: ["juros_altos", "juros_moderados"],
      body: [
        "Avalanche: você paga o mínimo de todas as dívidas e usa todo o dinheiro extra na de maior taxa de juros. Em geral é o método que gera menos juros no total.",
        "Bola de neve: o dinheiro extra vai para a dívida de menor saldo. Você quita dívidas pequenas mais cedo, e isso pode ajudar a manter a motivação.",
        "Nos dois métodos, quando uma dívida é quitada, o valor da parcela dela passa a ser usado na próxima. Na aba Dívidas, o Cousner calcula os dois com os seus números."
      ],
      example: null
    },
    {
      id: "orcamento", title: "Montando um orçamento que funciona", minutes: 4,
      tags: ["deficit", "poupanca_baixa", "comprometimento"],
      body: [
        "Um orçamento é o plano de para onde cada real vai antes de o mês começar. Comece pelo que é obrigatório (moradia, alimentação, saúde, transporte e dívidas) e só depois distribua o restante.",
        "Separe o que é fixo do que é variável: o que é variável é onde costuma ser mais fácil ajustar sem mudar sua vida.",
        "Pague a si mesmo primeiro: logo que receber, separe o valor que quer guardar, em vez de esperar sobrar no fim do mês.",
        "Acompanhe por 30 dias antes de ajustar. Em Gastos > Orçamento você define limites e recebe avisos ao se aproximar deles."
      ],
      example: function () {
        var r = 5000, v = r * 0.1;
        return "Exemplo: para uma renda de " + money(r) + ", guardar 10% é " + money(v) + " por mês, ou " + money(v * 12) + " em um ano (sem contar rendimento).";
      }
    },
    {
      id: "reserva", title: "Reserva de emergência e liquidez", minutes: 4,
      tags: ["reserva_baixa", "reserva_parcial"],
      body: [
        "A reserva de emergência é um dinheiro separado para imprevistos, como problema de saúde, conserto urgente ou perda de renda. Ela não é para gastos planejados nem para investir em busca de lucro.",
        "Uma referência comum é guardar de 3 a 6 meses dos seus gastos essenciais. Quem tem renda instável ou muitos dependentes costuma precisar de mais.",
        "As duas características importantes são liquidez (poder resgatar rápido, de preferência no mesmo dia) e baixo risco (o valor não pode cair justamente quando você precisar). Exemplos comuns de opções são contas remuneradas, títulos do Tesouro Selic e CDBs com liquidez diária. Compare taxas, custos e proteção do FGC (que tem limite por CPF e instituição).",
        "Comece pequeno: a primeira meta pode ser 1 mês de gastos. O hábito importa mais que o valor inicial."
      ],
      example: function () {
        var g = 3000;
        return "Exemplo: para gastos de " + money(g) + " por mês, a reserva de 3 meses é " + money(g * 3) + " e a de 6 meses é " + money(g * 6) + ". Guardando " + money(300) + " por mês, os 3 meses levam " + Math.ceil(g * 3 / 300) + " meses (sem contar rendimento).";
      }
    },
    {
      id: "compra_parcelada", title: "Quanto custa o parcelamento", minutes: 3,
      tags: ["deficit", "comprometimento"],
      body: [
        "Toda parcela embute uma taxa de juros, mesmo quando o anúncio não fala em juros. Se o valor parcelado é maior que o à vista, a diferença são juros.",
        "Compare sempre o preço à vista com a soma das parcelas. O simulador do Cousner (aba Simulador) calcula a taxa de juros que está escondida no parcelamento.",
        "Comprar parcelado não é errado. O que importa é a parcela caber no orçamento sem tirar dinheiro da reserva ou das dívidas mais urgentes."
      ],
      example: function () {
        var price = 1200, n = 12, p = Math.round(T.pmt(price * 100, 0.02, n)) / 100;
        return "Exemplo: um item de " + money(price) + " em " + n + " parcelas de " + money(p) + " custa " + money(p * n) + " no total: " + money(p * n - price) + " de juros, que equivalem a 2% ao mês.";
      }
    },
    {
      id: "renda_fixa", title: "Renda fixa, CDI e Tesouro Direto: o básico", minutes: 5,
      tags: ["invest_irregular"],
      body: [
        "Na renda fixa, você empresta dinheiro a um emissor (um banco ou o governo) e ele se compromete a devolver com juros em uma regra definida na contratação.",
        "O CDI é uma taxa de referência do mercado. Muitos CDBs e outras aplicações pagam um percentual dele (por exemplo, 100% do CDI). A Selic é a taxa básica de juros da economia, e o Tesouro Selic acompanha essa taxa.",
        "No Tesouro Direto, há títulos que pagam taxa definida na compra (prefixados), que acompanham a Selic, ou que pagam a inflação mais uma taxa (IPCA+).",
        "Renda fixa não é sem risco. Os principais riscos são o de o emissor não pagar (crédito), o de o preço do título oscilar se você vender antes do vencimento (mercado) e o de você não conseguir resgatar quando precisar (liquidez).",
        "Os rendimentos de renda fixa pagam imposto de renda com alíquota que diminui com o prazo (de 22,5% a 15% na tabela regressiva), e há isenção em alguns produtos. Confira sempre as regras vigentes antes de investir."
      ],
      example: null
    },
    {
      id: "diversificacao", title: "Diversificação, risco e rentabilidade", minutes: 4,
      tags: ["sem_problemas"],
      body: [
        "Diversificar é distribuir o dinheiro em ativos diferentes, para que um problema em um deles não comprometa tudo.",
        "Risco e retorno andam juntos: em geral, quanto maior a expectativa de retorno, maior a chance de perda ou de oscilação no caminho. Nenhuma rentabilidade é garantida, e rentabilidade passada não garante a futura.",
        "O que é adequado depende do seu objetivo, do prazo e do quanto você tolera ver o valor oscilar. Dinheiro de curto prazo e de emergência deve ficar em aplicações seguras e líquidas.",
        "Antes de investir em algo, entenda como funciona, quais são os riscos, os custos e o prazo. Se não conseguir explicar para outra pessoa, ainda não está pronto."
      ],
      example: null
    },
    {
      id: "inflacao", title: "Inflação e juros reais", minutes: 3,
      tags: ["sem_problemas", "patrimonio_queda", "invest_irregular"],
      body: [
        "A inflação é o aumento geral dos preços. Se o seu dinheiro rende menos que a inflação, ele compra cada vez menos, mesmo crescendo em números.",
        "O que importa para o seu poder de compra é o juro real: o rendimento descontada a inflação. A conta é (1 + taxa) ÷ (1 + inflação) − 1."
      ],
      example: function () {
        var nom = 0.10, inf = 0.05, real = (1 + nom) / (1 + inf) - 1;
        return "Exemplo: uma aplicação que rende " + pct(nom) + " ao ano, com inflação de " + pct(inf) + ", rende " + pct(real, 2) + " de juro real. Em uma aplicação de " + money(10000) + ", isso é " + money(10000 * real) + " de ganho de poder de compra em um ano (não os " + money(1000) + " nominais).";
      }
    },
    {
      id: "alocacao", title: "Alocação de capital: um dinheiro para cada objetivo", minutes: 4,
      tags: ["sem_problemas"],
      body: [
        "Alocar capital é decidir em que colocar o seu dinheiro conforme cada objetivo e prazo: emergência, metas de curto e médio prazo, aposentadoria.",
        "Dinheiro que você vai precisar em pouco tempo não deve ficar em algo que pode cair de valor. Dinheiro para daqui a muitos anos pode aceitar mais oscilação.",
        "Revise a divisão de tempos em tempos: quando uma meta é concluída ou sua renda muda, a alocação também deve mudar.",
        "Construir patrimônio é passar de quem paga juros a quem recebe juros: primeiro eliminar as dívidas caras, depois formar a reserva e, só então, investir com consistência."
      ],
      example: null
    }
  ];

  /** Em que fase o usuário está, a partir do diagnóstico (só o que está nos dados). */
  function stageOf(diag) {
    if (!diag || diag.overall.score === null) return { id: "inicio", label: "Começando: faltam dados", lessons: ["orcamento", "reserva"] };
    var ids = diag.problems.map(function (p) { return p.id; });
    if (ids.indexOf("deficit") >= 0 || ids.indexOf("juros_altos") >= 0 || ids.indexOf("juros_moderados") >= 0 || ids.indexOf("taxa_desconhecida") >= 0)
      return { id: "endividado", label: "Organizando dívidas e orçamento", lessons: ["juros_compostos", "credito_cartao", "negociar", "avalanche_neve", "orcamento"] };
    if (ids.indexOf("reserva_baixa") >= 0 || ids.indexOf("reserva_parcial") >= 0)
      return { id: "sem_reserva", label: "Formando a reserva de emergência", lessons: ["reserva", "orcamento"] };
    var ind = {}; diag.indicators.forEach(function (i) { ind[i.id] = i; });
    var invests = ind.investimentos && ind.investimentos.score !== null && ind.investimentos.score > 0;
    if (!invests || ids.indexOf("invest_irregular") >= 0) return { id: "iniciando", label: "Começando a investir", lessons: ["renda_fixa", "inflacao", "diversificacao"] };
    if (diag.problems.length) return { id: "investindo", label: "Investindo com pontos a ajustar", lessons: ["diversificacao", "inflacao", "alocacao"] };
    return { id: "acumulando", label: "Acumulando patrimônio", lessons: ["inflacao", "alocacao", "diversificacao"] };
  }

  /** Lições recomendadas: as da fase atual primeiro, depois as ligadas a cada problema, sem repetir. */
  function recommended(diag) {
    var stage = stageOf(diag), seen = {}, out = [];
    function add(id) {
      if (seen[id]) return; seen[id] = true;
      LESSONS.forEach(function (l) { if (l.id === id) out.push(l); });
    }
    stage.lessons.forEach(add);
    if (diag) diag.problems.forEach(function (p) { LESSONS.forEach(function (l) { if (l.tags.indexOf(p.id) >= 0) add(l.id); }); });
    return { stage: stage, lessons: out };
  }

  function lessonsFor(problemId) { return LESSONS.filter(function (l) { return l.tags.indexOf(problemId) >= 0; }); }

  root.CBEdu = { LESSONS: LESSONS, stageOf: stageOf, recommended: recommended, lessonsFor: lessonsFor };
  if (typeof module !== "undefined" && module.exports) module.exports = root.CBEdu;
})(typeof window !== "undefined" ? window : globalThis);

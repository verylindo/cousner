/*
 * Cousner Pro — tela do Treinador Financeiro.
 * Todas as contas ficam em treinador-core.js (testável). Aqui só há tela, formulários e eventos.
 * Textos digitados pelo usuário são sempre escapados (nunca entram como HTML).
 */
(function () {
  "use strict";

  var G = window.CBGastos, CB = window.CB, T = window.CBTreinador, E = window.CBEdu, PRO = window.CousnerPro;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var host = $("#view");
  if (!host || !G || !T) return;

  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  var R = G.fmt;
  function moneyInput(cents) { return (cents / 100).toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
  function pct(v, d) { return (v * 100).toLocaleString("pt-BR", { minimumFractionDigits: d || 0, maximumFractionDigits: d || 0 }) + "%"; }
  function toast(msg, kind) {
    var h = $("#toasts");
    if (!h) { h = document.createElement("div"); h.className = "toasts"; h.id = "toasts"; document.body.appendChild(h); }
    var el = document.createElement("div");
    el.className = "toast " + (kind || "ok"); el.textContent = msg; h.appendChild(el);
    setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, kind === "ok" ? 4000 : 8000);
  }

  /* ---------- marcador apresentado pelo servidor; o Treinador está aberto ao público ---------- */

  if (!PRO || !PRO.hasAccess()) {
    $("#tabs").hidden = true;
    host.innerHTML = '<section class="panel teaser"><h2>Em breve</h2><p>O Treinador Financeiro Cousner Pro chega em breve.</p></section>';
    return;
  }

  /* ---------- dados ---------- */

  var storage = null;
  try { storage = window.localStorage; storage.getItem("monevo.teste"); } catch (e) { storage = null; }
  var loaded = T.load(storage), data = loaded.data, gdata = G.emptyState(), goals = [];

  var TABS = [["resumo", "Visão geral"], ["dividas", "Dívidas"], ["patrimonio", "Patrimônio"], ["previsao", "Previsão"], ["simulador", "Simulador"], ["aprender", "Aprender"], ["historico", "Histórico"]];
  var TITLES = { dados: "Dados incompletos", deficit: "Gastos maiores que os ganhos", juros_altos: "Dívidas com juros altos", invest_com_divida: "Investindo com dívida cara",
    reserva_baixa: "Reserva de emergência insuficiente", reserva_parcial: "Reserva de emergência incompleta", comprometimento: "Renda muito comprometida", taxa_desconhecida: "Dívidas sem taxa informada",
    juros_moderados: "Dívidas com juros menores", poupanca_baixa: "Pouca sobra no fim do mês", patrimonio_queda: "Patrimônio em queda", metas_fora: "Metas fora do ritmo", invest_irregular: "Aportes irregulares" };
  var GO = { dados: ["link", "gastos.html", "Ir para Gastos"], deficit: ["link", "gastos.html", "Ver meus gastos"], juros_altos: ["tab", "dividas", "Abrir Dívidas"], invest_com_divida: ["tab", "dividas", "Abrir Dívidas"],
    taxa_desconhecida: ["tab", "dividas", "Abrir Dívidas"], juros_moderados: ["tab", "dividas", "Abrir Dívidas"], reserva_baixa: ["tab", "patrimonio", "Registrar reserva"], reserva_parcial: ["tab", "patrimonio", "Registrar reserva"],
    comprometimento: ["link", "gastos.html", "Ver despesas fixas"], poupanca_baixa: ["link", "gastos.html", "Ver meus gastos"], patrimonio_queda: ["tab", "patrimonio", "Abrir Patrimônio"],
    metas_fora: ["link", "metas.html", "Abrir Metas"], invest_irregular: ["link", "gastos.html", "Registrar aporte"] };
  var SRC = { registrado: "Registrado", declarado: "Declarado", estimado: "Estimado", misto: "Registrado + declarado" };

  var ST = { tab: "resumo", today: "", diag: null, fc: { mode: "monthly", est: true }, extra: "", sim: { mode: "vista", name: "", price: "", n: "", inst: "", rate: "", income: "", invest: "", horizon: "12" },
    simOut: null, cmpA: null, cmpB: null, itemKind: "asset", editItem: null, editDebt: null, confirmFn: null };

  function persist() { if (!T.save(storage, data)) toast("Não foi possível salvar neste navegador.", "err"); }

  function compute() {
    ST.today = G.todayStr();
    gdata = G.load(storage).state;
    goals = T.loadGoals(storage);
    ST.diag = T.diagnose(gdata, goals, data, ST.today);
    var before = JSON.stringify(data.history);
    T.saveDiagnostic(data, ST.diag); // guarda o diagnóstico de hoje no histórico
    if (JSON.stringify(data.history) !== before) persist();
  }

  /* ---------- peças de tela ---------- */

  function months(m) { return m === null || m === undefined ? "Não quita nesse ritmo" : CB.formatPeriod(m); }
  function tone(score) { return score === null ? "na" : score >= 70 ? "good" : score >= 40 ? "warn" : "bad"; }
  var TONE_COLOR = { good: "#139A49", warn: "#C46A0C", bad: "#D42B35", na: "#7B8780" };
  function stat(label, value, hint, cls) { return '<div class="stat"><div class="l">' + label + '</div><div class="v num' + (cls ? " " + cls : "") + '">' + value + '</div>' + (hint ? '<div class="h">' + hint + "</div>" : "") + "</div>"; }

  function ring(score, tn) {
    var c = 2 * Math.PI * 70, off = score === null ? c : c * (1 - score / 100);
    return '<div class="ring"><svg viewBox="0 0 168 168" aria-hidden="true"><circle class="bgc" cx="84" cy="84" r="70"></circle><circle class="fgc" cx="84" cy="84" r="70" stroke="' + TONE_COLOR[tn] + '" stroke-dasharray="' + c.toFixed(1) + '" stroke-dashoffset="' + off.toFixed(1) + '"></circle></svg>' +
      '<div class="mid"><b class="tone-' + tn + '">' + (score === null ? "—" : score) + "</b><span>de 100</span></div></div>";
  }

  function goButton(p) {
    var g = GO[p.id]; if (!g) return "";
    return g[0] === "link" ? '<a class="btn" href="' + g[1] + '">' + g[2] + "</a>" : '<button type="button" class="btn" data-go="' + g[1] + '">' + g[2] + "</button>";
  }

  function recHTML(p) {
    var h = '<div class="rec">' +
      '<div class="blk"><h4>O que está acontecendo</h4><p>' + esc(p.what) + "</p></div>" +
      '<div class="blk"><h4>Por que isso é um problema</h4><p>' + esc(p.why) + "</p></div>" +
      '<div class="blk"><h4>Se nada mudar</h4><p>' + esc(p.consequence) + "</p></div>" +
      '<div class="blk do"><h4>O que fazer</h4><p>' + esc(p.action) + "</p></div>";
    if (p.how.length) h += '<div class="blk"><h4>Como fazer</h4><ol>' + p.how.map(function (x) { return "<li>" + esc(x) + "</li>"; }).join("") + "</ol></div>";
    if (p.outcome) h += '<div class="blk out"><h4>Resultado possível</h4><p>' + esc(p.outcome) + "</p></div>";
    if (p.evidence && p.evidence.length) h += '<details class="more"><summary>De onde vêm esses números</summary><ul class="ev">' + p.evidence.map(function (x) { return "<li>" + esc(x) + "</li>"; }).join("") + "</ul></details>";
    return h + "</div>";
  }

  function actionBar(p) {
    var done = data.actions[p.id], h = "";
    if (done) {
      h += '<p class="done-note warn">Você marcou esta ação como concluída em ' + G.brDate(done.doneAt) + ', mas o diagnóstico de hoje ainda indica este problema. Confira os números ou reabra a ação.</p>';
      h += '<div class="acts"><button type="button" class="btn" data-reopen="' + p.id + '">Reabrir ação</button>' + goButton(p) + "</div>";
    } else {
      h += '<div class="acts"><button type="button" class="btn gold" data-done="' + p.id + '">Marcar como concluída</button>' + goButton(p) +
        (E && E.lessonsFor(p.id).length ? '<button type="button" class="btn" data-go="aprender">Entender melhor</button>' : "") + "</div>";
    }
    return h;
  }

  /* ---------- aba: visão geral ---------- */

  function renderResumo() {
    var d = ST.diag, ov = d.overall, tn = ov.score === null ? "na" : ov.level.tone, h = "";

    // nota
    h += '<section class="panel score-card">' + ring(ov.score, tn) + "<div>";
    if (ov.score !== null) {
      h += '<h2>Saúde financeira: <span class="lvl tone-' + tn + '">' + ov.level.label + "</span></h2>" +
        "<p>Nota calculada com " + ov.coverage + " de 8 indicadores" + (d.base ? ", usando " + (d.base.partial ? "o mês em andamento" : "a média de " + d.base.months + (d.base.months === 1 ? " mês fechado" : " meses fechados")) + " com ganhos e despesas registrados" : "") + ".</p>" +
        (ov.coverage < 8 ? "<p>Indicadores sem dados não entram na nota. Veja abaixo o que falta.</p>" : "") +
        (ov.capped ? '<p class="done-note warn" style="margin-top:10px">A média dos indicadores daria ' + ov.capped.raw + ", mas a nota foi limitada a " + ov.capped.max + " porque há um problema " + ov.capped.severity + ": " + esc(ov.capped.because) + ".</p>" : "");
    } else {
      h += "<h2>Ainda sem nota</h2><p>" + esc(ov.reason) + "</p><p>Preferimos não dar uma nota a chutar.</p>";
    }
    h += '<details class="how"><summary>Como a nota é calculada</summary><div class="t-scroll"><table class="t-table"><thead><tr><th>Indicador</th><th>Peso</th></tr></thead><tbody>' +
      T.INDICATOR_IDS.map(function (id) { return "<tr><td>" + T.LABELS[id] + "</td><td>" + T.WEIGHTS[id] + "%</td></tr>"; }).join("") + "</tbody></table></div>" +
      '<ul class="crit">' + T.INDICATOR_IDS.map(function (id) { return "<li><b>" + T.LABELS[id] + ":</b> " + esc(T.CRITERIA[id]) + "</li>"; }).join("") + "</ul>" +
      '<p class="t-sub" style="margin-top:10px">A nota é a média ponderada dos indicadores que têm dados. É preciso ao menos 3 indicadores, incluindo a capacidade de poupança. Se houver um problema crítico, a nota não passa de ' + T.CAP_CRITICAL + '; se houver um de gravidade alta, não passa de ' + T.CAP_HIGH + ', para uma média boa não esconder um problema grave. Cada indicador mostra se vem de dados registrados, declarados por você ou estimados.</p></details>';
    h += "</div></section>";

    // dados que faltam
    if (d.missing.length) {
      h += '<section class="panel"><div class="panel-head"><div><h2>Para um diagnóstico mais completo</h2><p>O Treinador só usa o que você registra. Estas informações ainda não existem:</p></div></div><div class="rows">' +
        d.missing.map(function (m) {
          var btn = "";
          if (m.id === "gastos" || m.id === "metas") btn = '<a class="btn small" href="' + m.where + '">' + (m.id === "metas" ? "Abrir Metas" : "Abrir Gastos") + "</a>";
          else if (m.id === "dividas") btn = '<button type="button" class="btn small" data-go="dividas">Cadastrar dívidas</button><button type="button" class="btn small" data-has-debts="nao">Não tenho dívidas</button>';
          else if (m.id === "reserva") btn = '<button type="button" class="btn small" data-go="patrimonio">Registrar reserva</button><button type="button" class="btn small" data-no-reserve="1">Não tenho reserva</button>';
          else if (m.id === "patrimonio") btn = '<button type="button" class="btn small" data-go="patrimonio">Registrar patrimônio</button>';
          return '<div class="row-card"><div class="nm">' + esc(m.text) + '</div><div class="ra" style="grid-column:auto">' + btn + "</div></div>";
        }).join("") + "</div></section>";
    }

    // prioridade
    if (d.priority) {
      var p = d.priority;
      h += '<section class="panel prio"><div class="kicker">Sua prioridade agora <span class="sev ' + p.severity + '">' + ({ critico: "Crítico", alto: "Alta", medio: "Média", baixo: "Baixa", info: "Para começar" }[p.severity]) + "</span></div><h2>" + esc(p.title) + "</h2>" + recHTML(p) + actionBar(p) + "</section>";
      if (d.problems.length > 1) {
        h += '<section class="panel"><div class="panel-head"><div><h2>Próximos passos, em ordem</h2><p>Depois da prioridade acima, esta é a ordem lógica: gravidade, custo e impacto.</p></div></div><div class="others">' +
          d.problems.slice(1).map(function (q, i) {
            var done = data.actions[q.id];
            return '<details class="prob"><summary><span class="n">' + (i + 2) + 'º</span> ' + esc(q.title) + ' <span class="sev ' + q.severity + '">' + ({ critico: "Crítico", alto: "Alta", medio: "Média", baixo: "Baixa", info: "Info" }[q.severity]) + "</span>" + (done ? ' <span class="tag-s ok">Marcada como concluída</span>' : "") + "</summary>" + recHTML(q) + actionBar(q) + "</details>";
          }).join("") + "</div></section>";
      }
    } else if (ov.score !== null) {
      h += '<section class="panel prio"><div class="kicker">Sua prioridade agora</div><h2>Nenhum problema prioritário encontrado</h2><div class="rec"><div class="blk"><p>Com os dados registrados, o Treinador não encontrou nada urgente. O próximo passo é manter o ritmo e aprender sobre como proteger e fazer o patrimônio crescer.</p></div></div><div class="acts"><button type="button" class="btn gold" data-go="aprender">Ver conteúdos</button></div></section>';
    }

    // indicadores
    h += '<section class="panel"><div class="panel-head"><div><h2>Indicadores</h2><p>Oito pontos da sua saúde financeira. Os que não têm dados ainda ficam de fora da nota.</p></div></div><div class="t-grid3">' +
      d.indicators.map(function (i) {
        var tn2 = i.status === "na" ? "na" : i.status;
        return '<div class="ind"><div class="top"><span class="nm">' + esc(i.label) + '</span><span class="src">' + SRC[i.source] + "</span></div>" +
          '<div class="val tone-' + tn2 + '">' + (i.value ? esc(i.value) : "Sem dados") + "</div>" +
          (i.score !== null ? '<div class="bar ' + i.status + '"><i style="width:' + i.score + '%"></i></div>' : "") +
          '<div class="det">' + esc(i.detail) + "</div>" + (i.missing ? '<div class="miss">' + esc(i.missing) + "</div>" : "") +
          (i.score !== null ? '<div class="det">Pontuação: ' + i.score + " de 100</div>" : "") + "</div>";
      }).join("") + "</div></section>";

    // positivos, riscos, oportunidades
    function list(arr, empty) { return arr.length ? '<ul class="pts">' + arr.map(function (x) { return "<li>" + esc(x) + "</li>"; }).join("") + "</ul>" : '<p class="muted">' + empty + "</p>"; }
    h += '<div class="t-grid3"><section class="panel col ok"><h3>Pontos positivos</h3>' + list(d.positives, "Ainda não há indicadores com nota alta.") + "</section>" +
      '<section class="panel col risk"><h3>Riscos</h3>' + list(d.risks, "Nenhum risco grave identificado nos dados.") + "</section>" +
      '<section class="panel col opp"><h3>Oportunidades</h3>' + list(d.opportunities, "Registre mais dados para ver oportunidades.") + "</section></div>";

    // progresso e mudanças
    var pg = T.progress(d.problems, data);
    h += '<div class="t-grid2"><section class="panel"><div class="panel-head"><div><h2>Progresso das recomendações</h2></div></div><div class="prog">' +
      (pg.total ? '<div class="row"><span>' + pg.done + " de " + pg.total + " recomendações marcadas como concluídas</span><b>" + Math.round(pg.done / pg.total * 100) + "%</b></div>" +
        '<div class="track' + (pg.done === pg.total ? " done" : "") + '"><i style="width:' + Math.round(pg.done / pg.total * 100) + '%"></i></div>' : '<p class="muted">Nenhuma recomendação pendente.</p>') +
      '<p class="t-sub" style="margin:8px 0 0">Ações concluídas desde o início: ' + pg.lifetime + ". Se o problema continuar nos dados, ele volta a aparecer.</p></div></section>" +
      '<section class="panel"><div class="panel-head"><div><h2>O que mudou desde o último diagnóstico</h2></div></div>' + changesHTML(d) + "</section></div>";
    return h;
  }

  function changesHTML(d) {
    var prev = null;
    data.history.forEach(function (x) { if (x.date !== ST.today) prev = x; });
    if (!prev || d.overall.score === null) return '<p class="muted">O Treinador guarda um diagnóstico por dia. Volte depois de atualizar seus dados para ver o que mudou.</p>';
    var now = T.historyEntry(d), c = T.compareHistory(prev, now), lines = [];
    lines.push("Último diagnóstico salvo: " + G.brDate(prev.date) + (prev.score !== null ? " (nota " + prev.score + ")" : "") + ".");
    if (c.scoreDelta !== null) lines.push(c.scoreDelta === 0 ? "A nota geral não mudou." : "A nota geral " + (c.scoreDelta > 0 ? "subiu " : "caiu ") + Math.abs(c.scoreDelta) + " pontos.");
    c.indicators.forEach(function (i) { if (i.direction === "melhorou") lines.push("Melhorou: " + i.label + "."); else if (i.direction === "piorou") lines.push("Piorou: " + i.label + "."); });
    c.resolved.forEach(function (id) { lines.push("Deixou de aparecer: " + TITLES[id] + "."); });
    c.appeared.forEach(function (id) { lines.push("Novo: " + TITLES[id] + "."); });
    return '<ul class="changes">' + lines.map(function (l) { return "<li>" + esc(l) + "</li>"; }).join("") + "</ul>";
  }

  /* ---------- aba: dívidas ---------- */

  function renderDividas() {
    var h = "", debts = data.debts;
    h += '<section class="panel"><div class="panel-head"><div><h2>Suas dívidas</h2><p>Cadastre saldo, taxa e parcela. O Treinador compara as estratégias de quitação com os seus números.</p></div><button type="button" class="btn gold" data-new-debt>+ Nova dívida</button></div>';
    if (!debts.length) {
      h += data.profile.hasDebts === "nao"
        ? '<p class="empty"><b>Você informou que não tem dívidas</b>Isso conta como um ponto positivo no diagnóstico.<br><button type="button" class="btn" data-has-debts="">Mudei de ideia</button></p>'
        : '<p class="empty"><b>Nenhuma dívida cadastrada</b>Cadastre financiamentos, empréstimos, cartão, cheque especial e parcelamentos. Se não tiver nenhuma, informe isso para o diagnóstico considerar.<br><button type="button" class="btn gold" data-new-debt>+ Cadastrar dívida</button> <button type="button" class="btn" data-has-debts="nao">Não tenho dívidas</button></p>';
      return h + "</section>";
    }
    var tb = 0, ti = 0, tj = 0, unk = 0;
    debts.forEach(function (d) { tb += d.balance; ti += d.installment; if (d.rate === null) unk++; else tj += d.balance * d.rate; });
    h += '<div class="stats three" style="margin-bottom:16px">' + stat("Saldo devedor total", R(tb), "Valor para quitar tudo hoje") + stat("Parcelas por mês", R(ti)) +
      stat("Juros por mês", R(Math.round(tj)), unk ? "Sem contar " + unk + (unk === 1 ? " dívida sem taxa" : " dívidas sem taxa") : "Saldo × taxa, de cada dívida") + "</div>";
    h += '<div class="rows">' + debts.map(function (d) {
      return '<div class="row-card"><div><div class="nm">' + esc(d.name) + (d.creditor ? ' <span class="muted" style="font-weight:400">· ' + esc(d.creditor) + "</span>" : "") + '</div><div class="sb">' +
        "<span>Parcela " + R(d.installment) + "</span>" + (d.rate !== null ? "<span>" + (d.rate * 100).toLocaleString("pt-BR", { maximumFractionDigits: 2 }) + "% ao mês" + (d.rate >= T.HIGH_RATE ? " (alta)" : "") + "</span>" : '<span class="warn-chip">Taxa não informada</span>') +
        (d.remaining ? "<span>" + d.remaining + " parcelas restantes</span>" : "") + (d.dueDay ? "<span>Vence dia " + d.dueDay + "</span>" : "") + (d.logged ? "<span>Parcela já lançada em Gastos</span>" : "") +
        '</div></div><div class="vl">' + R(d.balance) + '</div><div class="ra"><button type="button" class="btn small" data-edit-debt="' + esc(d.id) + '">Editar</button><button type="button" class="btn small" data-del-debt="' + esc(d.id) + '">Excluir</button></div></div>';
    }).join("") + "</div></section>";

    h += '<section class="panel"><div class="panel-head"><div><h2>Simulação de quitação</h2><p>Avalanche (maior juros primeiro) x bola de neve (menor saldo primeiro). Quando uma dívida quita, a parcela dela vai para a próxima.</p></div></div>' +
      '<div class="form-row"><div class="field"><label for="extraAmt">Valor extra por mês para quitar dívidas <span class="opt">(opcional)</span></label><div class="input" id="w-extraAmt"><span>R$</span><input id="extraAmt" inputmode="decimal" placeholder="0,00" autocomplete="off" value="' + esc(ST.extra) + '"></div><p class="msg" id="e-extraAmt"></p></div></div>' +
      '<div id="debtSim"></div></section>';
    return h;
  }

  function debtSimHTML() {
    var debts = data.debts, extra = 0, msg = "";
    if (String(ST.extra).trim()) { extra = G.parseCents(ST.extra); if (isNaN(extra) || extra < 0 || extra > G.MAX_AMOUNT_CENTS) { extra = 0; msg = "Informe um valor válido. Exemplo: 300,00"; } }
    var el = $("#e-extraAmt"); if (el) { el.textContent = msg; $("#w-extraAmt").classList.toggle("err", !!msg); }
    var c = T.compareMethods(debts, extra), h = "";
    if (c.incomplete) h += '<div class="banner-t warn" style="margin-bottom:14px"><span><b>Simulação incompleta.</b> Faltam as taxas de juros de: ' + esc(c.unknownRates.join(", ")) + ". Essas dívidas foram calculadas sem juros, então o tempo e o custo reais serão maiores. Cadastre as taxas para um resultado completo.</span></div>";
    var rows = [["separado", "Pagando cada dívida só com a própria parcela", c.separado], ["avalanche", "Avalanche (maior juros primeiro)", c.avalanche], ["bola_de_neve", "Bola de neve (menor saldo primeiro)", c.bola_de_neve]];
    var best = null;
    [c.avalanche, c.bola_de_neve].forEach(function (x) { if (!x.never && (best === null || x.interest < best.interest)) best = x; });
    h += '<div class="t-scroll"><table class="t-table"><thead><tr><th>Método</th><th>Tempo para quitar</th><th>Juros totais</th><th>Total pago</th><th>Economia de juros</th></tr></thead><tbody>' +
      rows.map(function (r) {
        var x = r[2], eco = r[0] === "avalanche" ? c.economyAvalanche.interest : r[0] === "bola_de_neve" ? c.economySnowball.interest : null;
        return "<tr><td>" + r[1] + "</td><td>" + months(x.months) + '</td><td class="' + (best && x === best ? "best" : "") + '">' + (x.never ? "—" : R(x.interest)) + "</td><td>" + (x.never ? "—" : R(x.paid)) + "</td><td>" + (eco === null ? "—" : R(eco)) + "</td></tr>";
      }).join("") + "</tbody></table></div>";
    h += '<p class="t-sub" style="margin-top:12px">Valor necessário para quitar tudo hoje: <b>' + R(c.totalBalance) + "</b> (soma dos saldos). Com o valor extra de " + R(extra) + " por mês.</p>";
    [["avalanche", "Avalanche", c.avalanche], ["bola_de_neve", "Bola de neve", c.bola_de_neve]].forEach(function (r) {
      if (r[2].order.length) h += '<p class="t-sub" style="margin:4px 0"><b>' + r[1] + " — ordem em que as dívidas quitam:</b> " + r[2].order.map(esc).join(" → ") + ".</p>";
    });
    var notes = [];
    if (c.avalanche.never || c.bola_de_neve.never || c.separado.never) notes.push("Em pelo menos um cenário a parcela não cobre os juros: a dívida não quita no ritmo atual. Aumente o valor extra ou renegocie.");
    if (!c.avalanche.never && !c.bola_de_neve.never) {
      var diff = c.bola_de_neve.interest - c.avalanche.interest;
      if (diff > 0) notes.push("Nos seus números, a avalanche custa " + R(diff) + " a menos em juros que a bola de neve" + (c.avalanche.months !== c.bola_de_neve.months ? " e leva " + Math.abs(c.avalanche.months - c.bola_de_neve.months) + (c.avalanche.months < c.bola_de_neve.months ? " meses a menos." : " meses a mais.") : "."));
      else notes.push("Nos seus números, os dois métodos custam praticamente o mesmo. A bola de neve quita as dívidas pequenas mais cedo.");
      var f1 = c.avalanche.payoff[0], f2 = c.bola_de_neve.payoff[0];
      if (f1 && f2) notes.push("A primeira dívida quita no mês " + f1.month + " na avalanche e no mês " + f2.month + " na bola de neve.");
    }
    if (extra === 0) notes.push("Informe um valor extra por mês para ver o efeito de concentrar dinheiro em uma dívida.");
    h += '<ul class="lines" style="margin-top:12px">' + notes.map(function (n) { return "<li>" + esc(n) + "</li>"; }).join("") + "</ul>";
    h += '<p class="disc" style="margin-top:12px">Simulação com juros compostos mensais sobre o saldo, sem tarifas, seguros ou atrasos. Os valores reais dependem do contrato de cada dívida.</p>';
    return h;
  }

  /* ---------- aba: patrimônio ---------- */

  function lineChart(points) {
    var w = 640, h = 220, L = 64, Rr = 14, Tp = 16, B = 30, iw = w - L - Rr, ih = h - Tp - B;
    var vals = points.map(function (p) { return p.value; }), mn = Math.min.apply(null, vals), mx = Math.max.apply(null, vals);
    if (mn === mx) { mn -= 1; mx += 1; }
    var pad = (mx - mn) * 0.1; mn -= pad; mx += pad;
    var X = function (i) { return L + (points.length === 1 ? iw / 2 : i / (points.length - 1) * iw); }, Y = function (v) { return Tp + ih - (v - mn) / (mx - mn) * ih; };
    var s = "";
    for (var t = 0; t <= 3; t++) {
      var gv = mn + (mx - mn) * t / 3, gy = Y(gv);
      s += '<line x1="' + L + '" x2="' + (w - Rr) + '" y1="' + gy.toFixed(1) + '" y2="' + gy.toFixed(1) + '" stroke="#B9C6BF" stroke-opacity=".45"></line><text x="' + (L - 8) + '" y="' + (gy + 4).toFixed(1) + '" text-anchor="end" font-size="11" fill="#66736B">' + G.fmtShort(gv) + "</text>";
    }
    if (mn < 0 && mx > 0) s += '<line x1="' + L + '" x2="' + (w - Rr) + '" y1="' + Y(0).toFixed(1) + '" y2="' + Y(0).toFixed(1) + '" stroke="#66736B" stroke-dasharray="4 4"></line>';
    s += '<polyline fill="none" stroke="#139A49" stroke-width="2.5" stroke-linejoin="round" points="' + points.map(function (p, i) { return X(i).toFixed(1) + "," + Y(p.value).toFixed(1); }).join(" ") + '"></polyline>';
    points.forEach(function (p, i) { s += '<circle cx="' + X(i).toFixed(1) + '" cy="' + Y(p.value).toFixed(1) + '" r="4" fill="#139A49" stroke="#FFFFFF" stroke-width="2"><title>' + esc(p.label) + ": " + R(p.value) + "</title></circle>"; });
    s += '<text x="' + L + '" y="' + (h - 8) + '" font-size="11" fill="#66736B">' + esc(points[0].label) + '</text><text x="' + (w - Rr) + '" y="' + (h - 8) + '" font-size="11" fill="#66736B" text-anchor="end">' + esc(points[points.length - 1].label) + "</text>";
    return '<svg class="t-chart" viewBox="0 0 ' + w + " " + h + '" role="img" aria-label="Gráfico da evolução do patrimônio líquido">' + s + "</svg>";
  }

  function itemRow(x, kind) {
    var types = kind === "asset" ? T.ASSET_TYPES : T.LIAB_TYPES, tn = "";
    types.forEach(function (t) { if (t[0] === x.type) tn = t[1]; });
    return '<div class="row-card"><div><div class="nm">' + esc(x.name) + '</div><div class="sb"><span>' + esc(tn) + '</span></div></div><div class="vl">' + R(x.value) + '</div><div class="ra"><button type="button" class="btn small" data-edit-item="' + kind + ":" + esc(x.id) + '">Editar</button><button type="button" class="btn small" data-del-item="' + kind + ":" + esc(x.id) + '">Excluir</button></div></div>';
  }

  function renderPatrimonio() {
    var nw = T.netWorth(data), h = "", tn = nw.net > 0 ? "good" : nw.net < 0 ? "bad" : "na";
    h += '<section class="panel"><div class="panel-head"><div><h2>Patrimônio líquido</h2><p>Ativos (o que você tem) menos passivos (o que você deve).</p></div></div>' +
      '<div class="stats three">' + stat("Ativos", R(nw.assets)) + stat("Passivos", R(nw.liabilities), nw.debts ? "Inclui " + R(nw.debts) + " das Dívidas" : "") + stat("Patrimônio líquido", '<span class="tone-' + tn + '">' + (nw.net < 0 ? "−" : "") + R(Math.abs(nw.net)) + "</span>") + "</div>" +
      '<p class="note-line">As dívidas cadastradas em Dívidas já entram nos passivos: não é preciso cadastrar duas vezes.</p></section>';

    h += '<div class="t-grid2"><section class="panel"><div class="panel-head"><div><h2>Ativos</h2></div><button type="button" class="btn small gold" data-new-asset>+ Novo ativo</button></div>' +
      (data.assets.length ? '<div class="rows">' + data.assets.map(function (x) { return itemRow(x, "asset"); }).join("") + "</div>" : '<p class="empty"><b>Nenhum ativo registrado</b>Dinheiro, saldo em conta, reserva de emergência, investimentos, imóveis e outros bens.</p>');
    var hasReserve = data.assets.some(function (a) { return a.type === "reserva"; });
    if (!hasReserve) h += data.profile.noReserve ? '<p class="note-line">Você informou que não tem reserva de emergência. <button type="button" class="t-link" data-no-reserve="0">Desfazer</button></p>' : '<p class="note-line">Não tem reserva de emergência? <button type="button" class="t-link" data-no-reserve="1">Informar que não tenho</button></p>';
    h += "</section>";
    h += '<section class="panel"><div class="panel-head"><div><h2>Passivos</h2></div><button type="button" class="btn small gold" data-new-liab>+ Novo passivo</button></div>' +
      (data.liabilities.length || data.debts.length ? '<div class="rows">' + data.liabilities.map(function (x) { return itemRow(x, "liab"); }).join("") +
        (data.debts.length ? '<div class="row-card"><div><div class="nm">Dívidas cadastradas (' + data.debts.length + ')</div><div class="sb"><span>Vêm da aba Dívidas</span></div></div><div class="vl">' + R(nw.debts) + '</div><div class="ra"><button type="button" class="btn small" data-go="dividas">Abrir Dívidas</button></div></div>' : "") + "</div>"
        : '<p class="empty"><b>Nenhum passivo registrado</b>Financiamentos, empréstimos e outros compromissos. Dívidas com parcela e juros ficam melhor na aba Dívidas.</p>') + "</section></div>";

    var snaps = data.networth;
    h += '<section class="panel"><div class="panel-head"><div><h2>Evolução do patrimônio</h2><p>O Treinador guarda uma foto por dia quando você atualiza ativos, passivos ou dívidas.</p></div></div>';
    if (snaps.length >= 2) {
      h += lineChart(snaps.map(function (s) { return { label: G.brDate(s.date), value: s.net }; })) +
        '<details class="more" style="margin-top:12px"><summary>Ver os dados em tabela</summary><div class="t-scroll"><table class="t-table"><thead><tr><th>Data</th><th>Ativos</th><th>Passivos</th><th>Patrimônio</th><th>Variação</th></tr></thead><tbody>' +
        snaps.map(function (s, i) { var dv = i ? s.net - snaps[i - 1].net : null; return "<tr><td>" + G.brDate(s.date) + "</td><td>" + R(s.assets) + "</td><td>" + R(s.liabilities) + "</td><td>" + (s.net < 0 ? "−" : "") + R(Math.abs(s.net)) + "</td><td>" + (dv === null ? "—" : (dv < 0 ? "−" : "+") + R(Math.abs(dv))) + "</td></tr>"; }).reverse().join("") + "</tbody></table></div></details>";
    } else h += '<p class="empty"><b>' + (snaps.length ? "Só há um registro" : "Sem histórico ainda") + '</b>A evolução aparece a partir de dois registros em datas diferentes. Atualize os valores de tempos em tempos.</p>';
    var gs = 0; goals.forEach(function (g) { gs += g.saved; });
    h += '<p class="note-line">' + (gs ? "As suas metas somam " + R(gs) + " guardados. Esse valor não é somado automaticamente: registre acima onde o dinheiro está (conta, reserva, investimento) para não contar em dobro. " : "") +
      "Transferências entre as suas contas e aportes não são ganhos nem despesas: não os lance como ganho em Gastos.</p></section>";
    return h;
  }

  /* ---------- aba: previsão ---------- */

  function renderPrevisao() {
    var f = T.forecast(gdata, data, ST.today, { mode: ST.fc.mode, includeEstimates: ST.fc.est }), h = "";
    h += '<section class="panel"><div class="panel-head"><div><h2>Previsão de saldo</h2><p>O que já está confirmado nos seus lançamentos e, se você quiser, uma estimativa do restante.</p></div></div>' +
      '<div class="form-row"><div class="seg" role="group" aria-label="Período">' +
      '<button type="button" data-fc-mode="weekly" class="' + (ST.fc.mode === "weekly" ? "on" : "") + '">Próximas 8 semanas</button><button type="button" data-fc-mode="monthly" class="' + (ST.fc.mode === "monthly" ? "on" : "") + '">Próximos 6 meses</button></div>' +
      '<div class="check"><input type="checkbox" id="fcEst"' + (ST.fc.est ? " checked" : "") + '><label for="fcEst">Incluir estimativas de gastos variáveis e ganhos eventuais</label></div></div></section>';
    var firstNeg = f.balanceKnown ? (f.firstNegative ? '<span class="tone-bad">' + esc(f.firstNegative.label) + "</span>" : '<span class="tone-good">Nenhum</span>') : "—";
    h += '<div class="stats three">' + stat("Saldo inicial", f.balanceKnown ? R(f.startBalance) : "Não informado", f.balanceKnown ? "Dinheiro e contas, em Patrimônio" : "Informe em Patrimônio") +
      stat("Primeiro saldo negativo", firstNeg, f.balanceKnown ? "Considera " + (f.includeEstimates ? "confirmado + estimado" : "só o confirmado") : "Precisa do saldo inicial") +
      stat("Maior comprometimento", f.heaviest ? esc(f.heaviest.label) : "—", f.heaviest ? "Saídas de " + R(f.heaviest.outC + (f.includeEstimates ? f.heaviest.outE : 0)) : "") + "</div>";

    var sl = f.balanceKnown ? "Saldo" : "Variação acumulada";
    h += '<section class="panel"><div class="t-scroll"><table class="t-table"><thead><tr><th>Período</th><th>Entradas confirmadas</th><th>Saídas confirmadas</th>' + (f.includeEstimates ? "<th>Estimativa (entradas − saídas)</th>" : "") + "<th>" + sl + " (confirmado)</th>" + (f.includeEstimates ? "<th>" + sl + " (com estimativas)</th>" : "") + "</tr></thead><tbody>" +
      f.buckets.map(function (b) {
        var neg = b.negConfirmed || b.negEstimated || (!f.balanceKnown && b.deficit), est = b.inE - b.outE;
        function sg(v) { return (v < 0 ? "−" : "") + R(Math.abs(v)); }
        return '<tr class="' + (neg ? "neg " : "") + (f.heaviest === b ? "heavy" : "") + '"><td>' + esc(b.label) + "</td><td>" + R(b.inC) + "</td><td>" + R(b.outC) + "</td>" + (f.includeEstimates ? "<td>" + sg(est) + "</td>" : "") + "<td>" + sg(b.endConfirmed) + "</td>" + (f.includeEstimates ? "<td>" + sg(b.endEstimated) + "</td>" : "") + "</tr>";
      }).join("") + "</tbody></table></div>" +
      '<p class="note-line">Linhas em vermelho: saldo negativo previsto' + (f.balanceKnown ? "" : " (sem saldo inicial, mostra períodos em que as saídas superam as entradas)") + ". A barra dourada marca o período de maior saída.</p></section>";

    h += '<section class="panel"><div class="panel-head"><div><h2>O que é confirmado e o que é estimativa</h2></div></div><ul class="lines"><li><b>Confirmado:</b> lançamentos que você já agendou, despesas e ganhos recorrentes que você cadastrou e parcelas de dívidas.</li>' +
      "<li><b>Estimado:</b> uma média dos seus gastos variáveis e ganhos eventuais recentes. É uma projeção, não uma garantia.</li>" + f.assumptions.map(function (a) { return "<li>" + esc(a) + "</li>"; }).join("") + "</ul>" +
      '<details class="more" style="margin-top:12px"><summary>Ver os lançamentos confirmados de cada período</summary>' + f.buckets.map(function (b) {
        return '<p class="t-sub" style="margin:12px 0 4px"><b>' + esc(b.label) + "</b></p>" + (b.items.length ? '<ul class="lines">' + b.items.slice(0, 40).map(function (it) { return "<li>" + G.brDate(it.date) + " · " + esc(it.name) + " · " + (it.dir === "in" ? "+" : "−") + R(it.amount) + " (" + ({ agendado: "agendado", recorrente: "recorrente", parcela: "parcela de dívida" }[it.kind]) + ")</li>"; }).join("") + "</ul>" : '<p class="muted" style="margin:0">Nada confirmado.</p>');
      }).join("") + "</details></section>";
    return h;
  }

  /* ---------- aba: simulador ---------- */

  function renderSimulador() {
    var s = ST.sim, d = ST.diag, h = "";
    var incomeHint = d.base ? "Média registrada: " + R(d.base.income) : "Informe a sua renda mensal";
    h += '<section class="panel"><div class="panel-head"><div><h2>Simulador de compra</h2><p>Veja o impacto de uma compra no orçamento e compare com guardar o dinheiro. Comprar não é errado: o objetivo é decidir com consciência.</p></div></div>' +
      '<div class="form-row"><div class="field"><label for="sName">Produto ou serviço <span class="opt">(opcional)</span></label><div class="input"><input id="sName" maxlength="60" autocomplete="off" value="' + esc(s.name) + '" placeholder="Ex.: notebook"></div></div>' +
      '<div class="field"><label for="sPrice">Preço à vista</label><div class="input" id="w-sPrice"><span>R$</span><input id="sPrice" inputmode="decimal" autocomplete="off" value="' + esc(s.price) + '" placeholder="0,00"></div><p class="msg" id="e-sPrice"></p></div></div>' +
      '<div class="form-row" style="margin-top:14px"><div class="seg" role="group" aria-label="Forma de pagamento"><button type="button" data-sim-mode="vista" class="' + (s.mode === "vista" ? "on" : "") + '">À vista</button><button type="button" data-sim-mode="parcelado" class="' + (s.mode === "parcelado" ? "on" : "") + '">Parcelado</button></div></div>';
    if (s.mode === "parcelado") {
      h += '<div class="form-row" style="margin-top:14px"><div class="field"><label for="sN">Número de parcelas</label><div class="input" id="w-sN"><input id="sN" inputmode="numeric" autocomplete="off" value="' + esc(s.n) + '" placeholder="Ex.: 12"></div><p class="msg" id="e-sN"></p></div>' +
        '<div class="field"><label for="sInst">Valor da parcela</label><div class="input" id="w-sInst"><span>R$</span><input id="sInst" inputmode="decimal" autocomplete="off" value="' + esc(s.inst) + '" placeholder="0,00"></div><p class="msg" id="e-sInst"></p></div>' +
        '<div class="field"><label for="sRate">ou juros ao mês <span class="opt">(se não souber a parcela)</span></label><div class="input" id="w-sRate"><input id="sRate" inputmode="decimal" autocomplete="off" value="' + esc(s.rate) + '" placeholder="Ex.: 2,5"><span>%</span></div><p class="msg" id="e-sRate"></p></div></div>';
    } else {
      h += '<div class="form-row" style="margin-top:14px"><div class="field"><label for="sHorizon">Prazo para comparar com guardar <span class="opt">(meses)</span></label><div class="input" id="w-sHorizon"><input id="sHorizon" inputmode="numeric" autocomplete="off" value="' + esc(s.horizon) + '" placeholder="12"></div><p class="msg" id="e-sHorizon"></p></div></div>';
    }
    h += '<div class="form-row" style="margin-top:14px"><div class="field"><label for="sIncome">Renda mensal <span class="opt">(opcional)</span></label><div class="input" id="w-sIncome"><span>R$</span><input id="sIncome" inputmode="decimal" autocomplete="off" value="' + esc(s.income) + '" placeholder="' + esc(d.base ? moneyInput(d.base.income) : "0,00") + '"></div><p class="msg" id="e-sIncome">' + "</p><p class=\"hint\">" + esc(incomeHint) + '</p></div>' +
      '<div class="field"><label for="sInvest">Rentabilidade ao mês se guardar <span class="opt">(hipótese, opcional)</span></label><div class="input" id="w-sInvest"><input id="sInvest" inputmode="decimal" autocomplete="off" value="' + esc(s.invest) + '" placeholder="0"><span>%</span></div><p class="msg" id="e-sInvest"></p><p class="hint">É uma hipótese sua, não uma garantia. Em branco = 0%.</p></div></div>' +
      '<div class="acts"><button type="button" class="btn gold" data-run-sim>Simular</button></div><div id="simOut" style="margin-top:20px"></div></section>';
    return h;
  }

  function simOutHTML(r) {
    if (!r) return "";
    if (r.error) return '<div class="banner-t warn">' + esc(r.error) + "</div>";
    var VT = { ok: "Cabe no seu orçamento", atencao: "Merece atenção", risco: "Pesa no seu orçamento" };
    var h = '<div><span class="verdict ' + r.tone + '">' + VT[r.tone] + "</span> <span class=\"muted\">" + esc(r.name) + "</span></div><div class=\"stats three\" style=\"margin-top:14px\">";
    h += stat("Preço à vista", R(r.price));
    if (r.mode === "parcelado") h += stat("Parcela", R(r.payment), r.n + " vezes") + stat("Total pago", R(r.total), r.extraCost > 0 ? R(r.extraCost) + " de juros (" + (r.rate * 100).toLocaleString("pt-BR", { maximumFractionDigits: 2 }) + "% ao mês)" : "Sem juros");
    if (r.incomeShare !== undefined) h += stat(r.mode === "parcelado" ? "Parcela na sua renda" : "Valor na sua renda mensal", pct(r.incomeShare, 1));
    if (r.leftoverBefore !== undefined && r.mode === "parcelado") h += stat("Sobra mensal depois", (r.leftoverAfter < 0 ? "−" : "") + R(Math.abs(r.leftoverAfter)), "Hoje: " + (r.leftoverBefore < 0 ? "−" : "") + R(Math.abs(r.leftoverBefore)));
    h += "</div>";
    h += '<ul class="lines" style="margin-top:14px">' + r.notes.map(function (n) { return "<li>" + esc(n) + "</li>"; }).join("") + "</ul>";
    h += '<div class="banner-t info" style="margin-top:14px"><span><b>Alternativa: ' + esc(r.alternative.label) + ".</b> Você teria " + R(r.alternative.amount) + ". " + esc(r.alternative.note) + "</span></div>";
    h += '<p class="disc" style="margin-top:12px">Esta análise mostra o impacto no seu orçamento. A decisão é sua: o Treinador não considera nenhuma compra como errada.</p>';
    return h;
  }

  function runSim() {
    var s = ST.sim, errs = {}, price = G.parseCents(s.price), n = null, inst = null, rate = null;
    function setErr(id, msg) { var e = $("#e-" + id), w = $("#w-" + id); if (e) e.textContent = msg || ""; if (w) w.classList.toggle("err", !!msg); }
    ["sPrice", "sN", "sInst", "sRate", "sHorizon", "sIncome", "sInvest"].forEach(function (i) { setErr(i, ""); });
    if (isNaN(price) || price <= 0 || price > G.MAX_AMOUNT_CENTS) errs.sPrice = "Informe um preço válido. Exemplo: 1.500,00";
    if (s.mode === "parcelado") {
      n = /^\d{1,3}$/.test(String(s.n).trim()) ? +s.n : NaN;
      if (isNaN(n) || n < 2 || n > 120) errs.sN = "Informe de 2 a 120 parcelas.";
      if (String(s.inst).trim()) { inst = G.parseCents(s.inst); if (isNaN(inst) || inst <= 0) errs.sInst = "Informe um valor válido."; }
      if (String(s.rate).trim()) { var rr = CB.parseBR(s.rate); if (isNaN(rr) || rr < 0 || rr > 100) errs.sRate = "Informe uma taxa entre 0 e 100."; else rate = rr / 100; }
      if (!errs.sInst && !errs.sRate && inst === null && rate === null) errs.sInst = "Informe o valor da parcela ou os juros ao mês.";
    }
    var horizon = 12;
    if (s.mode === "vista" && String(s.horizon).trim()) { horizon = /^\d{1,3}$/.test(String(s.horizon).trim()) ? +s.horizon : NaN; if (isNaN(horizon) || horizon < 1 || horizon > 600) errs.sHorizon = "Informe de 1 a 600 meses."; }
    var income = ST.diag.base ? ST.diag.base.income : undefined;
    if (String(s.income).trim()) { var inc = G.parseCents(s.income); if (isNaN(inc) || inc <= 0) errs.sIncome = "Informe um valor válido."; else income = inc; }
    var ir = 0;
    if (String(s.invest).trim()) { var iv = CB.parseBR(s.invest); if (isNaN(iv) || iv < 0 || iv > 100) errs.sInvest = "Informe uma taxa entre 0 e 100."; else ir = iv / 100; }
    Object.keys(errs).forEach(function (k) { setErr(k, errs[k]); });
    if (Object.keys(errs).length) { $("#" + Object.keys(errs)[0]).focus(); $("#simOut").innerHTML = ""; return; }
    var c = ST.diag.ctx;
    ST.simOut = T.simulatePurchase({ name: s.name.trim(), price: price, mode: s.mode, n: n, installment: inst, rate: rate, income: income, leftover: c.leftover, reserve: c.reserve, goalsMonthly: c.goalsMonthly, hasHighDebt: c.highDebts.length > 0, investRate: ir, horizon: horizon });
    $("#simOut").innerHTML = simOutHTML(ST.simOut);
  }

  /* ---------- aba: aprender ---------- */

  function renderAprender() {
    var rec = E.recommended(ST.diag), shown = {}, h = "";
    h += '<section class="panel"><div class="panel-head"><div><h2>Aprender</h2><p>Conteúdos curtos, escolhidos conforme a sua situação. Os exemplos usam números calculados na hora.</p></div></div><p>Sua fase agora: <span class="stage">' + esc(rec.stage.label) + "</span></p></section>";
    function lessonHTML(l, open) {
      var ex = l.example ? l.example() : "";
      return '<details class="lesson"' + (open ? " open" : "") + "><summary><span>" + esc(l.title) + '</span><span class="mins">' + l.minutes + " min</span></summary><div class=\"bd\">" + l.body.map(function (p) { return "<p>" + esc(p) + "</p>"; }).join("") + (ex ? '<p class="ex">' + esc(ex) + "</p>" : "") + "</div></details>";
    }
    h += '<section class="panel"><div class="panel-head"><div><h2>Recomendados para você</h2></div></div><div class="rows">' + rec.lessons.slice(0, 4).map(function (l, i) { shown[l.id] = true; return lessonHTML(l, i === 0); }).join("") + "</div></section>";
    var rest = E.LESSONS.filter(function (l) { return !shown[l.id]; });
    if (rest.length) h += '<section class="panel"><div class="panel-head"><div><h2>Todos os conteúdos</h2></div></div><div class="rows">' + rest.map(function (l) { return lessonHTML(l, false); }).join("") + "</div></section>";
    h += '<p class="disc">Conteúdo educacional. Não é recomendação individual de investimento, consultoria financeira regulada nem garantia de resultado. Rentabilidade passada não garante rentabilidade futura.</p>';
    return h;
  }

  /* ---------- aba: histórico ---------- */

  function spark(values) {
    var pts = values.filter(function (v) { return v !== null; });
    if (pts.length < 2) return "";
    var w = 640, h = 120, L = 30, Rr = 10, Tp = 10, B = 20, iw = w - L - Rr, ih = h - Tp - B;
    var X = function (i) { return L + i / (values.length - 1) * iw; }, Y = function (v) { return Tp + ih - v / 100 * ih; };
    var s = '<line x1="' + L + '" x2="' + (w - Rr) + '" y1="' + Y(0) + '" y2="' + Y(0) + '" stroke="#B9C6BF" stroke-opacity=".5"></line><line x1="' + L + '" x2="' + (w - Rr) + '" y1="' + Y(100) + '" y2="' + Y(100) + '" stroke="#B9C6BF" stroke-opacity=".5"></line><text x="' + (L - 6) + '" y="' + (Y(100) + 4) + '" text-anchor="end" font-size="11" fill="#66736B">100</text><text x="' + (L - 6) + '" y="' + (Y(0) + 4) + '" text-anchor="end" font-size="11" fill="#66736B">0</text>';
    s += '<polyline fill="none" stroke="#139A49" stroke-width="2.5" points="' + values.map(function (v, i) { return v === null ? null : X(i).toFixed(1) + "," + Y(v).toFixed(1); }).filter(Boolean).join(" ") + '"></polyline>';
    values.forEach(function (v, i) { if (v !== null) s += '<circle cx="' + X(i).toFixed(1) + '" cy="' + Y(v).toFixed(1) + '" r="4" fill="#139A49" stroke="#FFFFFF" stroke-width="2"><title>' + v + "</title></circle>"; });
    return '<svg class="t-chart" viewBox="0 0 ' + w + " " + h + '" role="img" aria-label="Evolução da nota de saúde financeira">' + s + "</svg>";
  }

  function renderHistorico() {
    var hs = data.history, h = "";
    h += '<section class="panel"><div class="panel-head"><div><h2>Histórico de diagnósticos</h2><p>O Treinador guarda um diagnóstico por dia (quando já há nota). Use para ver se você está evoluindo.</p></div></div>';
    if (!hs.length) h += '<p class="empty"><b>Ainda sem histórico</b>O primeiro diagnóstico é salvo assim que houver dados suficientes para uma nota.</p>';
    else {
      h += spark(hs.map(function (x) { return x.score; })) + '<div class="t-scroll"><table class="t-table"><thead><tr><th>Data</th><th>Nota</th><th>Nível</th><th>Prioridade</th><th>Problemas</th></tr></thead><tbody>' +
        hs.slice().reverse().slice(0, 30).map(function (x) { var lv = x.score === null ? "—" : T.levelOf(x.score).label; return "<tr><td>" + G.brDate(x.date) + "</td><td>" + (x.score === null ? "—" : x.score) + "</td><td>" + lv + "</td><td>" + (x.priority ? esc(TITLES[x.priority]) : "—") + "</td><td>" + x.problems.length + "</td></tr>"; }).join("") + "</tbody></table></div>";
    }
    h += "</section>";

    if (hs.length >= 2) {
      var a = ST.cmpA && hs.filter(function (x) { return x.date === ST.cmpA; })[0] || hs[hs.length - 2], b = ST.cmpB && hs.filter(function (x) { return x.date === ST.cmpB; })[0] || hs[hs.length - 1];
      var opts = function (sel) { return hs.map(function (x) { return '<option value="' + x.date + '"' + (x.date === sel ? " selected" : "") + ">" + G.brDate(x.date) + (x.score !== null ? " (nota " + x.score + ")" : "") + "</option>"; }).join(""); };
      var c = T.compareHistory(a, b);
      h += '<section class="panel"><div class="panel-head"><div><h2>Comparar dois diagnósticos</h2></div></div><div class="form-row"><div class="field"><label for="cmpA">De</label><div class="input"><select id="cmpA">' + opts(a.date) + '</select></div></div><div class="field"><label for="cmpB">Para</label><div class="input"><select id="cmpB">' + opts(b.date) + "</select></div></div></div>" +
        '<div class="t-scroll" style="margin-top:14px"><table class="t-table"><thead><tr><th>Indicador</th><th>Antes</th><th>Depois</th><th>Variação</th></tr></thead><tbody>' +
        '<tr><td><b>Nota geral</b></td><td>' + (a.score === null ? "—" : a.score) + "</td><td>" + (b.score === null ? "—" : b.score) + '</td><td class="' + (c.scoreDelta > 0 ? "tone-good" : c.scoreDelta < 0 ? "tone-bad" : "") + '">' + (c.scoreDelta === null ? "—" : (c.scoreDelta > 0 ? "▲ +" : c.scoreDelta < 0 ? "▼ " : "") + c.scoreDelta) + "</td></tr>" +
        c.indicators.map(function (i) { return "<tr><td>" + esc(i.label) + "</td><td>" + (i.from === null ? "—" : i.from) + "</td><td>" + (i.to === null ? "—" : i.to) + '</td><td class="' + (i.direction === "melhorou" ? "tone-good" : i.direction === "piorou" ? "tone-bad" : "") + '">' + ({ melhorou: "▲ melhorou", piorou: "▼ piorou", igual: "igual", sem: "sem comparação" }[i.direction]) + "</td></tr>"; }).join("") + "</tbody></table></div>" +
        (c.resolved.length || c.appeared.length ? '<ul class="changes" style="margin-top:12px">' + c.resolved.map(function (id) { return "<li>Deixou de aparecer: " + esc(TITLES[id]) + "</li>"; }).join("") + c.appeared.map(function (id) { return "<li>Novo: " + esc(TITLES[id]) + "</li>"; }).join("") + "</ul>" : "") + "</section>";
    }

    var done = Object.keys(data.actions);
    h += '<section class="panel"><div class="panel-head"><div><h2>Ações concluídas</h2></div></div>' + (done.length ? '<div class="rows">' + done.map(function (id) { return '<div class="row-card"><div><div class="nm">' + esc(TITLES[id]) + '</div><div class="sb"><span>Concluída em ' + G.brDate(data.actions[id].doneAt) + '</span></div></div><div class="ra" style="grid-column:auto"><button type="button" class="btn small" data-reopen="' + id + '">Reabrir</button></div></div>'; }).join("") + "</div>" : '<p class="muted">Nenhuma ação concluída ainda. Marque as recomendações como concluídas na Visão geral.</p>') + "</section>";

    h += '<section class="panel"><div class="panel-head"><div><h2>Seus dados do Treinador</h2><p>Dívidas, patrimônio, histórico e ações ficam só neste navegador. Os gastos, ganhos e metas continuam nas páginas deles.</p></div></div>' +
      (loaded.status === "corrupt" ? '<div class="banner-t warn" style="margin-bottom:12px">Os dados salvos estavam corrompidos e foram ignorados.</div>' : "") + (!storage ? '<div class="banner-t warn" style="margin-bottom:12px">Este navegador não permite salvar dados (modo privado ou bloqueio). O que você registrar vale só até fechar a página.</div>' : "") +
      '<div class="acts"><button type="button" class="btn" data-export>Exportar backup (JSON)</button><button type="button" class="btn" data-import>Importar backup</button><button type="button" class="btn danger" data-wipe>Apagar dados do Treinador</button></div></section>';
    return h;
  }

  /* ---------- montagem ---------- */

  function renderTabs() {
    $("#tabs").innerHTML = TABS.map(function (t) { return '<button type="button" role="tab" id="tab-' + t[0] + '" data-tab="' + t[0] + '" aria-selected="' + (t[0] === ST.tab) + '" tabindex="' + (t[0] === ST.tab ? 0 : -1) + '">' + t[1] + "</button>"; }).join("");
    host.setAttribute("aria-labelledby", "tab-" + ST.tab);
  }

  function render() {
    renderTabs();
    var fn = { resumo: renderResumo, dividas: renderDividas, patrimonio: renderPatrimonio, previsao: renderPrevisao, simulador: renderSimulador, aprender: renderAprender, historico: renderHistorico }[ST.tab];
    host.innerHTML = fn();
    if (ST.tab === "dividas" && data.debts.length) $("#debtSim").innerHTML = debtSimHTML();
    if (ST.tab === "simulador" && ST.simOut) $("#simOut").innerHTML = simOutHTML(ST.simOut);
  }

  function go(tab, noScroll) {
    ST.tab = TABS.some(function (t) { return t[0] === tab; }) ? tab : "resumo";
    try { history.replaceState(null, "", "#" + ST.tab); } catch (e) { /* segue */ }
    compute(); render();
    if (!noScroll) { var el = $("#tabs"); if (el && el.scrollIntoView) el.scrollIntoView({ block: "start", behavior: "smooth" }); }
  }

  /* ---------- formulários ---------- */

  function setErr(id, msg) { var e = $("#e-" + id), w = $("#w-" + id); if (e) e.textContent = msg || ""; if (w) w.classList.toggle("err", !!msg); var i = $("#" + id); if (i) i.setAttribute("aria-invalid", msg ? "true" : "false"); }

  function openDebt(id) {
    var d = id ? data.debts.filter(function (x) { return x.id === id; })[0] : null;
    ST.editDebt = d ? d.id : null;
    $("#debtTitle").textContent = d ? "Editar dívida" : "Nova dívida";
    $("#dName").value = d ? d.name : ""; $("#dCreditor").value = d ? d.creditor : "";
    $("#dBalance").value = d ? moneyInput(d.balance) : ""; $("#dInst").value = d ? moneyInput(d.installment) : "";
    $("#dRate").value = d && d.rate !== null ? (d.rate * 100).toLocaleString("pt-BR", { maximumFractionDigits: 4 }) : "";
    $("#dRemaining").value = d && d.remaining ? d.remaining : ""; $("#dDue").value = d && d.dueDay ? d.dueDay : ""; $("#dLogged").checked = !!(d && d.logged);
    ["dName", "dBalance", "dInst", "dRate", "dRemaining", "dDue"].forEach(function (i) { setErr(i, ""); });
    var dlg = $("#dlgDebt"); if (!dlg.open) dlg.showModal(); $("#dName").focus();
  }

  function saveDebt(ev) {
    ev.preventDefault();
    var err = {}, name = $("#dName").value.trim(), bal = G.parseCents($("#dBalance").value), inst = G.parseCents($("#dInst").value), rate = null, rem = null, due = null;
    if (!name) err.dName = "Dê um nome para a dívida."; else if (name.length > 60) err.dName = "Use no máximo 60 caracteres.";
    if (isNaN(bal) || bal <= 0 || bal > G.MAX_AMOUNT_CENTS) err.dBalance = "Informe o saldo devedor. Exemplo: 5.000,00";
    if (isNaN(inst) || inst <= 0 || inst > G.MAX_AMOUNT_CENTS) err.dInst = "Informe a parcela mensal. Exemplo: 450,00";
    var rt = $("#dRate").value.trim();
    if (rt) { var rn = CB.parseBR(rt); if (isNaN(rn) || rn < 0 || rn > 100) err.dRate = "Informe uma taxa entre 0 e 100% ao mês, ou deixe em branco."; else rate = rn / 100; }
    var rm = $("#dRemaining").value.trim();
    if (rm) { if (!/^\d{1,4}$/.test(rm) || +rm < 1 || +rm > 1200) err.dRemaining = "Informe de 1 a 1.200 parcelas, ou deixe em branco."; else rem = +rm; }
    var dd = $("#dDue").value.trim();
    if (dd) { if (!/^\d{1,2}$/.test(dd) || +dd < 1 || +dd > 31) err.dDue = "Informe um dia de 1 a 31, ou deixe em branco."; else due = +dd; }
    ["dName", "dBalance", "dInst", "dRate", "dRemaining", "dDue"].forEach(function (i) { setErr(i, err[i]); });
    var keys = Object.keys(err); if (keys.length) { $("#" + keys[0]).focus(); return; }
    var debt = T.sanitizeDebt({ id: ST.editDebt || G.uid(), name: name, creditor: $("#dCreditor").value, balance: bal, installment: inst, rate: rate, remaining: rem, dueDay: due, logged: $("#dLogged").checked });
    if (ST.editDebt) data.debts = data.debts.map(function (x) { return x.id === ST.editDebt ? debt : x; }); else data.debts.push(debt);
    data.profile.hasDebts = "sim";
    T.snapshotNetWorth(data, ST.today); persist(); $("#dlgDebt").close(); compute(); render(); toast(ST.editDebt ? "Dívida atualizada." : "Dívida salva.", "ok");
  }

  function openItem(kind, id) {
    var list = kind === "asset" ? data.assets : data.liabilities, x = id ? list.filter(function (i) { return i.id === id; })[0] : null, types = kind === "asset" ? T.ASSET_TYPES : T.LIAB_TYPES;
    ST.itemKind = kind; ST.editItem = x ? x.id : null;
    $("#itemTitle").textContent = (x ? "Editar " : "Novo ") + (kind === "asset" ? "ativo" : "passivo");
    $("#iType").innerHTML = types.map(function (t) { return '<option value="' + t[0] + '">' + esc(t[1]) + "</option>"; }).join("");
    $("#iName").value = x ? x.name : ""; $("#iType").value = x ? x.type : types[0][0]; $("#iValue").value = x ? moneyInput(x.value) : "";
    $("#itemHint").textContent = kind === "asset" ? "Para a reserva de emergência, escolha o tipo “Reserva de emergência”. Se não tiver reserva, use o botão “Informar que não tenho”." : "Dívidas com parcela e juros ficam melhor na aba Dívidas, onde o Treinador simula a quitação.";
    ["iName", "iValue"].forEach(function (i) { setErr(i, ""); });
    var dlg = $("#dlgItem"); if (!dlg.open) dlg.showModal(); $("#iName").focus();
  }

  function saveItem(ev) {
    ev.preventDefault();
    var err = {}, name = $("#iName").value.trim(), v = G.parseCents($("#iValue").value), kind = ST.itemKind;
    if (!name) err.iName = "Dê um nome."; else if (name.length > 60) err.iName = "Use no máximo 60 caracteres.";
    if (isNaN(v) || v < 0 || v > G.MAX_AMOUNT_CENTS || (kind === "liab" && v === 0)) err.iValue = kind === "asset" ? "Informe um valor válido (pode ser zero). Exemplo: 1.500,00" : "Informe um valor maior que zero.";
    ["iName", "iValue"].forEach(function (i) { setErr(i, err[i]); });
    var keys = Object.keys(err); if (keys.length) { $("#" + keys[0]).focus(); return; }
    var obj = { id: ST.editItem || G.uid(), name: name, type: $("#iType").value, value: v };
    if (kind === "asset") { var a = T.sanitizeAsset(obj); data.assets = ST.editItem ? data.assets.map(function (x) { return x.id === a.id ? a : x; }) : data.assets.concat([a]); if (a.type === "reserva") data.profile.noReserve = false; }
    else { var l = T.sanitizeLiability(obj); data.liabilities = ST.editItem ? data.liabilities.map(function (x) { return x.id === l.id ? l : x; }) : data.liabilities.concat([l]); }
    T.snapshotNetWorth(data, ST.today); persist(); $("#dlgItem").close(); compute(); render(); toast("Salvo.", "ok");
  }

  function ask(title, text, okLabel, fn) {
    $("#cfTitle").textContent = title; $("#cfText").textContent = text; $("#cfOk").textContent = okLabel; ST.confirmFn = fn;
    $("#dlgConfirm").showModal(); $("#cfOk").focus();
  }

  /* ---------- exportar, importar, apagar ---------- */

  function exportData() {
    var blob = new Blob([JSON.stringify({ app: "cousner-treinador", version: 1, exportedAt: ST.today, data: data }, null, 2)], { type: "application/json" });
    var a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "cousner-treinador-" + ST.today + ".json";
    document.body.appendChild(a); a.click(); document.body.removeChild(a); setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
    toast("Backup exportado.", "ok");
  }

  function importFile(file) {
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) { toast("Arquivo grande demais (máximo 5 MB).", "err"); return; }
    var fr = new FileReader();
    fr.onload = function () {
      try {
        var raw = JSON.parse(String(fr.result)), src = raw && raw.data && typeof raw.data === "object" ? raw.data : raw;
        if (!src || typeof src !== "object") throw new Error("formato");
        var imp = T.sanitizeData(src);
        ask("Importar backup?", "Isso substitui os dados atuais do Treinador (dívidas, patrimônio, histórico e ações) pelos do arquivo: " + imp.debts.length + " dívidas, " + imp.assets.length + " ativos, " + imp.liabilities.length + " passivos e " + imp.history.length + " diagnósticos.", "Importar", function () {
          data = imp; persist(); compute(); render(); toast("Backup importado.", "ok");
        });
      } catch (e) { toast("Não foi possível ler esse arquivo. Use um backup exportado por esta página.", "err"); }
    };
    fr.onerror = function () { toast("Não foi possível ler o arquivo.", "err"); };
    fr.readAsText(file);
  }

  /* ---------- eventos ---------- */

  document.addEventListener("click", function (e) {
    var b = e.target.closest && e.target.closest("button");
    if (!b) return;
    if (b.hasAttribute("data-close")) { var dlg = b.closest("dialog"); if (dlg) dlg.close(); return; }
    if (b.hasAttribute("data-tab")) return go(b.getAttribute("data-tab"), true);
    if (b.hasAttribute("data-go")) return go(b.getAttribute("data-go"));
    if (b.hasAttribute("data-done")) { T.setAction(data, b.getAttribute("data-done"), true, ST.today); persist(); render(); toast("Ação marcada como concluída.", "ok"); return; }
    if (b.hasAttribute("data-reopen")) { T.setAction(data, b.getAttribute("data-reopen"), false, ST.today); persist(); render(); return; }
    if (b.hasAttribute("data-has-debts")) { var v = b.getAttribute("data-has-debts"); data.profile.hasDebts = v === "nao" ? "nao" : null; persist(); compute(); render(); return; }
    if (b.hasAttribute("data-no-reserve")) { data.profile.noReserve = b.getAttribute("data-no-reserve") === "1"; persist(); compute(); render(); return; }
    if (b.hasAttribute("data-new-debt")) return openDebt(null);
    if (b.hasAttribute("data-edit-debt")) return openDebt(b.getAttribute("data-edit-debt"));
    if (b.hasAttribute("data-del-debt")) {
      var did = b.getAttribute("data-del-debt"), dd = data.debts.filter(function (x) { return x.id === did; })[0]; if (!dd) return;
      return ask("Excluir dívida?", "“" + dd.name + "” (" + R(dd.balance) + ") será excluída. Essa ação não pode ser desfeita.", "Excluir", function () { data.debts = data.debts.filter(function (x) { return x.id !== did; }); T.snapshotNetWorth(data, ST.today); persist(); compute(); render(); toast("Dívida excluída.", "ok"); });
    }
    if (b.hasAttribute("data-new-asset")) return openItem("asset", null);
    if (b.hasAttribute("data-new-liab")) return openItem("liab", null);
    if (b.hasAttribute("data-edit-item")) { var p = b.getAttribute("data-edit-item").split(":"); return openItem(p[0], p.slice(1).join(":")); }
    if (b.hasAttribute("data-del-item")) {
      var q = b.getAttribute("data-del-item").split(":"), kind = q[0], iid = q.slice(1).join(":"), list = kind === "asset" ? data.assets : data.liabilities, it = list.filter(function (x) { return x.id === iid; })[0]; if (!it) return;
      return ask("Excluir?", "“" + it.name + "” (" + R(it.value) + ") será excluído. Essa ação não pode ser desfeita.", "Excluir", function () {
        if (kind === "asset") data.assets = data.assets.filter(function (x) { return x.id !== iid; }); else data.liabilities = data.liabilities.filter(function (x) { return x.id !== iid; });
        T.snapshotNetWorth(data, ST.today); persist(); compute(); render(); toast("Excluído.", "ok");
      });
    }
    if (b.hasAttribute("data-fc-mode")) { ST.fc.mode = b.getAttribute("data-fc-mode"); render(); return; }
    if (b.hasAttribute("data-sim-mode")) { readSim(); ST.sim.mode = b.getAttribute("data-sim-mode"); ST.simOut = null; render(); return; }
    if (b.hasAttribute("data-run-sim")) { readSim(); runSim(); return; }
    if (b.hasAttribute("data-export")) return exportData();
    if (b.hasAttribute("data-import")) { $("#fileImport").value = ""; $("#fileImport").click(); return; }
    if (b.hasAttribute("data-wipe")) return ask("Apagar dados do Treinador?", "Isso apaga dívidas, patrimônio, histórico de diagnósticos e ações concluídas, só deste navegador. Seus gastos, ganhos e metas não são afetados. Essa ação não pode ser desfeita.", "Apagar tudo", function () { data = T.emptyData(); persist(); compute(); render(); toast("Dados do Treinador apagados.", "ok"); });
  });

  function readSim() {
    var s = ST.sim, m = { sName: "name", sPrice: "price", sN: "n", sInst: "inst", sRate: "rate", sIncome: "income", sInvest: "invest", sHorizon: "horizon" };
    Object.keys(m).forEach(function (id) { var el = $("#" + id); if (el) s[m[id]] = el.value; });
  }

  document.addEventListener("change", function (e) {
    var t = e.target;
    if (t.id === "fcEst") { ST.fc.est = t.checked; render(); }
    else if (t.id === "extraAmt") { ST.extra = t.value; $("#debtSim").innerHTML = debtSimHTML(); }
    else if (t.id === "cmpA") { ST.cmpA = t.value; render(); }
    else if (t.id === "cmpB") { ST.cmpB = t.value; render(); }
  });

  $("#debtForm").addEventListener("submit", saveDebt);
  $("#itemForm").addEventListener("submit", saveItem);
  $("#fileImport").addEventListener("change", function (e) { importFile(e.target.files && e.target.files[0]); });
  $("#cfOk").addEventListener("click", function () { var fn = ST.confirmFn; ST.confirmFn = null; $("#dlgConfirm").close(); if (fn) fn(); });

  $("#tabs").addEventListener("keydown", function (e) {
    var ids = TABS.map(function (t) { return t[0]; }), i = ids.indexOf(ST.tab);
    if (e.key === "ArrowRight") i = (i + 1) % ids.length; else if (e.key === "ArrowLeft") i = (i - 1 + ids.length) % ids.length; else return;
    e.preventDefault(); go(ids[i], true); var el = $("#tab-" + ids[i]); if (el) el.focus();
  });

  window.addEventListener("hashchange", function () { var h = location.hash.slice(1); if (h && h !== ST.tab) go(h, true); });
  document.addEventListener("visibilitychange", function () {
    if (document.visibilityState === "visible" && (ST.tab === "resumo" || ST.tab === "previsao" || ST.tab === "historico") && !document.querySelector("dialog[open]")) { compute(); render(); }
  });

  /* ---------- início ---------- */
  var h0 = location.hash.slice(1);
  ST.tab = TABS.some(function (t) { return t[0] === h0; }) ? h0 : "resumo";
  compute(); render();
})();

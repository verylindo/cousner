/*
 * Marcador visual servido pelo backend quando a versão pública gratuita está ativa.
 * Não é controle de pagamento ou autorização; o acesso é aberto por decisão do proprietário.
 */
(function (root) {
  "use strict";
  root.CousnerPro = {
    hasAccess: function () {
      var proof = document.querySelector('meta[name="cousner-pro-access"]');
      return Boolean(proof && proof.content === "public-free");
    }
  };
})(window);

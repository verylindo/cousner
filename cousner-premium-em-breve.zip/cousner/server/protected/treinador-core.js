/*
 * Cousner Pro — Treinador Financeiro: regras e contas (sem tela).
 *
 * - Valores em CENTAVOS (inteiros). Taxas de dívida em decimal ao mês (0,03 = 3% ao mês).
 * - Tudo aqui é determinístico: o mesmo conjunto de dados sempre gera o mesmo diagnóstico.
 *   Nenhum número é inventado. Quando falta informação, o resultado diz isso (score/valor = null).
 * - Usa os dados que o Cousner já guarda (gastos, ganhos, metas) e só pede o que ainda não existe
 *   (dívidas, patrimônio, algumas declarações).
 *
 * Roda no navegador (window.CBTreinador) e no Node (module.exports), para poder ser testado.
 */
(function (root) {
  "use strict";

  var CB = root.CB, G = root.CBGastos;
  var KEY = "monevo.treinador.v1";
  var METAS_KEY = "monevo.metas.v1";
  var MAX = G.MAX_AMOUNT_CENTS;
  var CAP_CRITICAL = 59; // com problema crítico, a nota não passa de 59 ("Atenção")
  var CAP_HIGH = 79;     // com problema de gravidade alta, a nota não passa de 79 ("Boa")
  var HIGH_RATE = 0.03; // "juros altos": 3% ao mês ou mais (cerca de 43% ao ano)

  /* ---------- utilidades ---------- */

  function dict() { return Object.create(null); }
  function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }
  function pad(n) { return n < 10 ? "0" + n : "" + n; }
  function R(cents) { return G.fmt(cents); }
  function pctText(v, digits) { return (v * 100).toLocaleString("pt-BR", { minimumFractionDigits: digits || 0, maximumFractionDigits: digits || 0 }) + "%"; }
  function rateText(r) { return (r * 100).toLocaleString("pt-BR", { maximumFractionDigits: 2 }) + "% ao mês"; }

  /** Interpola linearmente entre pontos [x, y] em ordem crescente de x (fora do intervalo, usa a ponta). */
  function piecewise(x, pts) {
    if (x <= pts[0][0]) return pts[0][1];
    for (var i = 1; i < pts.length; i++) {
      if (x <= pts[i][0]) return pts[i - 1][1] + (pts[i][1] - pts[i - 1][1]) * (x - pts[i - 1][0]) / (pts[i][0] - pts[i - 1][0]);
    }
    return pts[pts.length - 1][1];
  }

  function monthKey(s) { return s.slice(0, 7); }
  function shiftMonthKey(key, n) {
    var idx = (+key.slice(0, 4)) * 12 + (+key.slice(5, 7) - 1) + n;
    return Math.floor(idx / 12) + "-" + pad((idx % 12) + 1);
  }
  function monthsBetween(fromStr, toStr) {
    var a = fromStr.split("-"), b = toStr.split("-");
    return (+b[0] * 12 + +b[1]) - (+a[0] * 12 + +a[1]);
  }

  /* ---------- tipos ---------- */

  var ASSET_TYPES = [
    ["dinheiro", "Dinheiro em espécie"], ["banco", "Saldo em conta bancária"], ["reserva", "Reserva de emergência"],
    ["investimento", "Investimentos"], ["imovel", "Imóveis"], ["outro", "Outros bens"]
  ];
  var LIAB_TYPES = [["emprestimo", "Empréstimo"], ["financiamento", "Financiamento"], ["divida", "Dívida"], ["outro", "Outro compromisso"]];
  var INDICATOR_IDS = ["poupanca", "comprometimento", "equilibrio", "endividamento", "reserva", "investimentos", "patrimonio", "metas"];
  var PROBLEM_IDS = ["dados", "deficit", "juros_altos", "invest_com_divida", "reserva_baixa", "reserva_parcial", "comprometimento",
    "taxa_desconhecida", "juros_moderados", "poupanca_baixa", "patrimonio_queda", "metas_fora", "invest_irregular"];

  function inList(list, v) { return list.some(function (x) { return (Array.isArray(x) ? x[0] : x) === v; }); }

  /* ---------- dados do Treinador (o que ainda não existia no Cousner) ---------- */

  function emptyData() {
    return { version: 1, profile: { hasDebts: null, noReserve: false }, debts: [], assets: [], liabilities: [], networth: [], history: [], actions: {} };
  }

  function text(s, n) { return String(s == null ? "" : s).trim().slice(0, n); }
  function goodId(v) { return typeof v === "string" && v && v.length <= 80 ? v : G.uid(); }
  function intIn(v, lo, hi) { var n = Number(v); return v !== null && v !== "" && Number.isInteger(n) && n >= lo && n <= hi ? n : null; }

  function sanitizeDebt(d) {
    if (!d || typeof d !== "object") return null;
    var name = text(d.name, 60), balance = intIn(d.balance, 1, MAX), inst = intIn(d.installment, 1, MAX);
    if (!name || balance === null || inst === null) return null;
    var rate = d.rate === null || d.rate === undefined || d.rate === "" ? null : Number(d.rate);
    if (rate !== null && !(rate >= 0 && rate <= 1)) rate = null;
    return {
      id: goodId(d.id), name: name, creditor: text(d.creditor, 60), balance: balance, rate: rate, installment: inst,
      remaining: intIn(d.remaining, 1, 1200), dueDay: intIn(d.dueDay, 1, 31), logged: !!d.logged
    };
  }

  function sanitizeAsset(a) {
    if (!a || typeof a !== "object") return null;
    var name = text(a.name, 60), value = intIn(a.value, 0, MAX);
    if (!name || value === null) return null;
    return { id: goodId(a.id), name: name, type: inList(ASSET_TYPES, a.type) ? a.type : "outro", value: value };
  }

  function sanitizeLiability(a) {
    if (!a || typeof a !== "object") return null;
    var name = text(a.name, 60), value = intIn(a.value, 1, MAX);
    if (!name || value === null) return null;
    return { id: goodId(a.id), name: name, type: inList(LIAB_TYPES, a.type) ? a.type : "outro", value: value };
  }

  function sanitizeHistory(h) {
    if (!h || typeof h !== "object" || isNaN(G.toDays(h.date))) return null;
    var ind = {};
    INDICATOR_IDS.forEach(function (id) { var v = h.ind && h.ind[id]; ind[id] = typeof v === "number" && isFinite(v) ? clamp(Math.round(v), 0, 100) : null; });
    return {
      date: h.date, score: typeof h.score === "number" && isFinite(h.score) ? clamp(Math.round(h.score), 0, 100) : null,
      coverage: intIn(h.coverage, 0, 8) || 0, priority: inList(PROBLEM_IDS, h.priority) ? h.priority : null,
      problems: (Array.isArray(h.problems) ? h.problems : []).filter(function (p) { return inList(PROBLEM_IDS, p); }).slice(0, 20),
      ind: ind, net: Number.isInteger(h.net) && Math.abs(h.net) <= MAX * 100 ? h.net : null, months: intIn(h.months, 0, 12) || 0
    };
  }

  function sanitizeData(raw) {
    var d = emptyData();
    if (!raw || typeof raw !== "object") return d;
    var p = raw.profile || {};
    d.profile.hasDebts = p.hasDebts === "sim" || p.hasDebts === "nao" ? p.hasDebts : null;
    d.profile.noReserve = p.noReserve === true;
    function many(list, fn, out) {
      var seen = dict();
      (Array.isArray(list) ? list : []).slice(0, 500).forEach(function (x) { var y = fn(x); if (y && !seen[y.id]) { seen[y.id] = true; out.push(y); } });
    }
    many(raw.debts, sanitizeDebt, d.debts);
    many(raw.assets, sanitizeAsset, d.assets);
    many(raw.liabilities, sanitizeLiability, d.liabilities);
    var seenN = dict();
    (Array.isArray(raw.networth) ? raw.networth : []).forEach(function (s) {
      if (!s || isNaN(G.toDays(s.date)) || seenN[s.date]) return;
      var a = intIn(s.assets, 0, MAX * 500), l = intIn(s.liabilities, 0, MAX * 500);
      if (a === null || l === null) return;
      seenN[s.date] = true; d.networth.push({ date: s.date, assets: a, liabilities: l, net: a - l });
    });
    d.networth.sort(function (a, b) { return G.toDays(a.date) - G.toDays(b.date); });
    d.networth = d.networth.slice(-120);
    var seenH = dict();
    (Array.isArray(raw.history) ? raw.history : []).forEach(function (h) { var x = sanitizeHistory(h); if (x && !seenH[x.date]) { seenH[x.date] = true; d.history.push(x); } });
    d.history.sort(function (a, b) { return G.toDays(a.date) - G.toDays(b.date); });
    d.history = d.history.slice(-60);
    var acts = raw.actions && typeof raw.actions === "object" ? raw.actions : {};
    PROBLEM_IDS.forEach(function (id) {
      var a = Object.prototype.hasOwnProperty.call(acts, id) ? acts[id] : null;
      if (a && a.status === "done" && !isNaN(G.toDays(a.doneAt))) d.actions[id] = { status: "done", doneAt: a.doneAt };
    });
    return d;
  }

  function load(storage) {
    if (!storage) return { data: emptyData(), status: "unavailable" };
    var raw;
    try { raw = storage.getItem(KEY); } catch (e) { return { data: emptyData(), status: "unavailable" }; }
    if (!raw) return { data: emptyData(), status: "ok" };
    try { return { data: sanitizeData(JSON.parse(raw)), status: "ok" }; }
    catch (e) { return { data: emptyData(), status: "corrupt" }; }
  }
  function save(storage, data) {
    if (!storage) return false;
    try { storage.setItem(KEY, JSON.stringify(data)); return true; } catch (e) { return false; }
  }

  /** Metas (mesma chave usada pela página Metas). Só lê: não cria cadastro duplicado. */
  function loadGoals(storage) {
    var out = [];
    try {
      var raw = JSON.parse(storage.getItem(METAS_KEY));
      (raw && Array.isArray(raw.goals) ? raw.goals : []).forEach(function (g) {
        if (!g || typeof g !== "object") return;
        var target = intIn(g.target, 1, MAX), saved = intIn(g.saved, 0, MAX), monthly = intIn(g.monthly, 0, MAX);
        var rate = Number(g.rate || 0);
        if (!(rate >= 0 && rate <= 1)) rate = 0;
        if (target === null || saved === null || monthly === null) return;
        out.push({ id: String(g.id || ""), name: text(g.name, 60) || "Meta", target: target, saved: saved, monthly: monthly, rate: rate,
          deadline: g.deadline && !isNaN(G.toDays(g.deadline)) ? g.deadline : "" });
      });
    } catch (e) { /* sem metas */ }
    return out;
  }

  /* ---------- dados registrados: médias mensais ---------- */

  /**
   * Resumo dos últimos `nFull` meses fechados + o mês atual (parcial).
   * Um mês só é "utilizável" quando tem ganhos E despesas registrados: mês com só um dos lados
   * geraria uma conclusão falsa (ex.: esqueceu de lançar o salário).
   */
  function monthlyStats(gdata, today, nFull) {
    nFull = nFull || 3;
    var map = G.catMap(G.allCategories(gdata.categories));
    var ex = G.expand(gdata.expenses, today).real, inc = G.expandIncomes(gdata.incomes || [], today).real;
    var cur = monthKey(today), keys = [], k;
    for (k = nFull; k >= 1; k--) keys.push(shiftMonthKey(cur, -k));
    keys.push(cur);
    return keys.map(function (key) {
      var e = ex.filter(function (o) { return monthKey(o.date) === key; });
      var n = inc.filter(function (o) { return monthKey(o.date) === key; });
      var s = G.summarize(e, map), fv = G.fixedVariable(e, map), nonRecC = 0, nonRecI = 0;
      e.forEach(function (o) { if (G.isConsumption(o, map) && !o.recurring) nonRecC += o.amount; });
      n.forEach(function (o) { if (!o.recurring) nonRecI += o.amount; });
      var income = G.sumIncome(n);
      return {
        key: key, partial: key === cur, income: income, incomeCount: n.length, consumption: s.total, expenseCount: s.count,
        fixed: fv.fixa, variable: fv.variavel, invest: s.invest, transfer: s.transfer, byCat: s.byCat,
        nonRecurringConsumption: nonRecC, nonRecurringIncome: nonRecI,
        usable: income > 0 && s.count > 0
      };
    });
  }

  /** Média dos meses utilizáveis. Sem mês fechado utilizável, usa o mês em andamento (marcado como parcial). */
  function computeBase(stats, gdata) {
    var full = stats.filter(function (m) { return !m.partial && m.usable; });
    var used = full, partial = false;
    if (!used.length) {
      var cur = stats.filter(function (m) { return m.partial && m.usable; });
      if (!cur.length) return null;
      used = cur; partial = true;
    }
    var n = used.length, base = { months: n, partial: partial, keys: used.map(function (m) { return m.key; }), income: 0, consumption: 0, fixed: 0, variable: 0, invest: 0,
      nonRecurringConsumption: 0, nonRecurringIncome: 0, byCat: dict(), fullMonths: full };
    used.forEach(function (m) {
      ["income", "consumption", "fixed", "variable", "invest", "nonRecurringConsumption", "nonRecurringIncome"].forEach(function (f) { base[f] += m[f]; });
      Object.keys(m.byCat).forEach(function (c) { base.byCat[c] = (base.byCat[c] || 0) + m.byCat[c]; });
    });
    ["income", "consumption", "fixed", "variable", "invest", "nonRecurringConsumption", "nonRecurringIncome"].forEach(function (f) { base[f] = Math.round(base[f] / n); });
    var map = G.catMap(G.allCategories(gdata.categories));
    base.top = Object.keys(base.byCat).map(function (id) {
      var avg = Math.round(base.byCat[id] / n);
      return { id: id, name: map[id] ? map[id].name : id, avg: avg, share: base.consumption ? avg / base.consumption : 0 };
    }).sort(function (a, b) { return b.avg - a.avg; }).slice(0, 3);
    return base;
  }

  /* ---------- metas ---------- */

  function evalGoals(goals, today) {
    return goals.map(function (g) {
      var out = { id: g.id, name: g.name, monthly: g.monthly, target: g.target, saved: g.saved, deadline: g.deadline };
      if (g.saved >= g.target) { out.status = "done"; return out; }
      if (!g.deadline) { out.status = "sem_prazo"; return out; }
      var left = monthsBetween(today, g.deadline), r = CB.toMonthlyRate(g.rate, "year");
      out.monthsLeft = left;
      if (left <= 0) { out.status = "atrasada"; return out; }
      var total = g.saved / 100, n = 0;
      while (n < 1200 && total < g.target / 100) { total = total * (1 + r) + g.monthly / 100; n++; }
      out.needed = Math.ceil(CB.requiredMonthly(g.saved / 100, g.target / 100, r, left) * 100);
      out.status = total >= g.target / 100 && n <= left ? "no_prazo" : "fora";
      return out;
    });
  }

  /* ---------- dívidas: simulação de quitação ---------- */

  /** Quanto tempo e quanto de juros uma dívida isolada gera pagando só a própria parcela. */
  function singleDebt(d, extra) {
    var r = d.rate || 0, bal = d.balance, pay = d.installment + (extra || 0), interest = 0, m = 0;
    while (bal > 0.005 && m < 1200) {
      var i = bal * r; interest += i; bal += i;
      bal -= Math.min(pay, bal); m++;
    }
    return { months: bal > 0.005 ? null : m, interest: Math.round(interest), paid: Math.round(d.balance + interest - Math.max(bal, 0)), never: bal > 0.005 };
  }

  /**
   * Simula a quitação de todas as dívidas.
   * method: "avalanche" (maior taxa primeiro) | "bola_de_neve" (menor saldo primeiro) | "separado" (sem realocar: cada dívida paga só a própria parcela).
   * extra: valor extra por mês (centavos). O orçamento total é a soma das parcelas + extra e fica constante:
   * quando uma dívida quita, a parcela dela passa a ser usada na próxima.
   */
  function simulatePayoff(debts, method, extra) {
    extra = Math.max(0, extra || 0);
    var unknown = debts.filter(function (d) { return d.rate === null; }).map(function (d) { return d.name; });
    var res = { method: method, incomplete: unknown.length > 0, unknownRates: unknown, months: 0, interest: 0, paid: 0, order: [], payoff: [], never: false, balance: 0 };
    debts.forEach(function (d) { res.balance += d.balance; });
    if (!debts.length) return res;

    if (method === "separado") {
      var maxM = 0, anyNever = false;
      debts.forEach(function (d) {
        var s = singleDebt(d, 0);
        res.interest += s.interest; res.paid += s.paid;
        if (s.never) anyNever = true; else maxM = Math.max(maxM, s.months);
        res.payoff.push({ id: d.id, name: d.name, month: s.months });
      });
      res.never = anyNever; res.months = anyNever ? null : maxM;
      return res;
    }

    var open = debts.map(function (d) { return { id: d.id, name: d.name, bal: d.balance, r: d.rate || 0, inst: d.installment, interest: 0 }; });
    var budget = extra; open.forEach(function (d) { budget += d.inst; });
    var m = 0, totalInterest = 0, totalPaid = 0;
    function byMethod(a, b) {
      if (method === "avalanche") return b.r - a.r || a.bal - b.bal;
      return a.bal - b.bal || b.r - a.r;
    }
    while (open.length && m < 1200) {
      m++;
      open.forEach(function (d) { var i = d.bal * d.r; d.bal += i; d.interest += i; totalInterest += i; });
      var pool = budget;
      open.forEach(function (d) { var p = Math.min(d.inst, d.bal); d.bal -= p; pool -= p; totalPaid += p; });
      open.slice().sort(byMethod).forEach(function (d) {
        if (pool <= 0.005 || d.bal <= 0.005) return;
        var p = Math.min(pool, d.bal); d.bal -= p; pool -= p; totalPaid += p;
      });
      open = open.filter(function (d) {
        if (d.bal <= 0.005) { res.payoff.push({ id: d.id, name: d.name, month: m }); return false; }
        return true;
      });
    }
    res.never = open.length > 0;
    res.months = res.never ? null : m;
    res.interest = Math.round(totalInterest);
    res.paid = Math.round(totalPaid);
    res.order = res.payoff.map(function (p) { return p.name; });
    return res;
  }

  /** Compara os dois métodos com o cenário "sem realocar" e aponta a economia. */
  function compareMethods(debts, extra) {
    var sep = simulatePayoff(debts, "separado", 0), av = simulatePayoff(debts, "avalanche", extra), sn = simulatePayoff(debts, "bola_de_neve", extra);
    function econ(x) {
      return {
        interest: sep.never || x.never ? null : sep.interest - x.interest,
        months: sep.never || x.never ? null : sep.months - x.months
      };
    }
    return { separado: sep, avalanche: av, bola_de_neve: sn, economyAvalanche: econ(av), economySnowball: econ(sn),
      incomplete: sep.incomplete, unknownRates: sep.unknownRates, totalBalance: sep.balance };
  }

  /* ---------- patrimônio líquido ---------- */

  function netWorth(tdata) {
    var assets = 0, manual = 0, debts = 0, byType = dict();
    tdata.assets.forEach(function (a) { assets += a.value; byType[a.type] = (byType[a.type] || 0) + a.value; });
    tdata.liabilities.forEach(function (l) { manual += l.value; });
    tdata.debts.forEach(function (d) { debts += d.balance; });
    return { assets: assets, manualLiabilities: manual, debts: debts, liabilities: manual + debts, net: assets - manual - debts, byType: byType };
  }

  /** Guarda uma "foto" do patrimônio de hoje (uma por dia; a última do dia vale). */
  function snapshotNetWorth(tdata, today) {
    var nw = netWorth(tdata);
    if (!tdata.assets.length && !tdata.liabilities.length && !tdata.debts.length) return false;
    tdata.networth = tdata.networth.filter(function (s) { return s.date !== today; });
    tdata.networth.push({ date: today, assets: nw.assets, liabilities: nw.liabilities, net: nw.net });
    tdata.networth.sort(function (a, b) { return G.toDays(a.date) - G.toDays(b.date); });
    tdata.networth = tdata.networth.slice(-120);
    return true;
  }

  /** Variação do patrimônio: compara a foto mais recente com uma de pelo menos 25 dias antes (ou a mais antiga). */
  function netWorthChange(tdata) {
    var s = tdata.networth;
    if (s.length < 2) return null;
    var last = s[s.length - 1], ld = G.toDays(last.date), prev = null, i;
    for (i = s.length - 2; i >= 0; i--) { if (ld - G.toDays(s[i].date) >= 25) { prev = s[i]; break; } }
    if (!prev) prev = s[0];
    var days = ld - G.toDays(prev.date);
    if (days <= 0) return null;
    return { from: prev, to: last, delta: last.net - prev.net, days: days, monthlyDelta: (last.net - prev.net) / (days / 30.4375) };
  }

  /* ---------- diagnóstico ---------- */

  function statusOf(score) { return score === null ? "na" : score >= 70 ? "good" : score >= 40 ? "warn" : "bad"; }

  function buildContext(gdata, goals, tdata, today) {
    var stats = monthlyStats(gdata, today, 3);
    var base = computeBase(stats, gdata);
    var nw = netWorth(tdata);
    var highDebts = tdata.debts.filter(function (d) { return d.rate !== null && d.rate >= HIGH_RATE; });
    var modDebts = tdata.debts.filter(function (d) { return d.rate !== null && d.rate > 0 && d.rate < HIGH_RATE; });
    var unknownDebts = tdata.debts.filter(function (d) { return d.rate === null; });
    var instAll = 0, instNotLogged = 0;
    tdata.debts.forEach(function (d) { instAll += d.installment; if (!d.logged) instNotLogged += d.installment; });
    var reserveAssets = tdata.assets.filter(function (a) { return a.type === "reserva"; });
    var reserve = null;
    if (reserveAssets.length) { reserve = 0; reserveAssets.forEach(function (a) { reserve += a.value; }); }
    else if (tdata.profile.noReserve) reserve = 0;
    var g = evalGoals(goals, today), goalsMonthly = 0;
    goals.forEach(function (x) { if (x.saved < x.target) goalsMonthly += x.monthly; });
    return {
      today: today, stats: stats, base: base, tdata: tdata, nw: nw, nwChange: netWorthChange(tdata), goals: g, goalsMonthly: goalsMonthly,
      debts: tdata.debts, highDebts: highDebts, modDebts: modDebts, unknownDebts: unknownDebts, debtInstallments: instAll, debtInstallmentsNotLogged: instNotLogged,
      reserve: reserve, reserveFromAssets: reserveAssets.length > 0,
      leftover: base ? base.income - base.consumption : null
    };
  }

  var CRITERIA = {
    poupanca: "Sobra = ganhos − gastos de consumo, em % dos ganhos (média dos meses com ganhos e despesas). 20% ou mais = 100 pontos; 10% = 70; 0% = 30; −20% ou menos = 0.",
    comprometimento: "Despesas fixas + parcelas de dívidas (que você não lança como despesa), em % dos ganhos. Até 50% = 100 pontos; 70% = 50; 90% = 10; 100% ou mais = 0.",
    equilibrio: "Em quantos dos meses fechados (mínimo 2) os ganhos foram maiores que as despesas. 3 de 3 = 100 pontos; 2 de 3 = 67; 1 de 3 = 33.",
    endividamento: "Parcelas das dívidas em % dos ganhos. Até 15% = 100 pontos; 30% = 60; 50% = 20; 70% ou mais = 0. Tirar 25 pontos se alguma dívida tiver juros de 3% ao mês ou mais.",
    reserva: "Meses de gastos cobertos pela reserva de emergência. 6 meses ou mais = 100 pontos; 3 = 70; 1 = 30; 0 = 0.",
    investimentos: "Em quantos dos meses fechados (mínimo 2) você registrou aportes na categoria Investimentos. Todos = 100 pontos; metade = 50.",
    patrimonio: "Variação mensal do patrimônio líquido (entre duas fotos suas) em relação aos ganhos mensais: +20% dos ganhos por mês ou mais = 100 pontos; estável = 50; −20% ou menos = 0.",
    metas: "Percentual das suas metas (com prazo) que estão no ritmo certo ou já foram concluídas."
  };
  var LABELS = {
    poupanca: "Capacidade de poupança", comprometimento: "Comprometimento da renda", equilibrio: "Equilíbrio entre ganhos e despesas",
    endividamento: "Nível de endividamento", reserva: "Reserva de emergência", investimentos: "Regularidade dos investimentos",
    patrimonio: "Evolução patrimonial", metas: "Capacidade de alcançar metas"
  };
  var WEIGHTS = { poupanca: 20, comprometimento: 10, equilibrio: 12, endividamento: 16, reserva: 16, investimentos: 8, patrimonio: 8, metas: 10 };

  function indicators(ctx) {
    var base = ctx.base, out = [];
    function add(id, score, value, detail, source, missing) {
      score = score === null ? null : clamp(Math.round(score), 0, 100);
      out.push({ id: id, label: LABELS[id], weight: WEIGHTS[id], score: score, status: statusOf(score), value: value, detail: detail, source: source, criteria: CRITERIA[id], missing: missing || null });
    }
    var haveIncome = base && base.income > 0;
    var baseNote = base ? (base.partial ? "mês em andamento (parcial)" : "média de " + base.months + (base.months === 1 ? " mês" : " meses")) : "";

    // 1. Capacidade de poupança
    if (haveIncome) {
      var rate = (base.income - base.consumption) / base.income;
      add("poupanca", piecewise(rate, [[-0.2, 0], [0, 30], [0.1, 70], [0.2, 100]]), pctText(rate, 1) + " da renda",
        (rate >= 0 ? "Sobra média de " : "Falta média de ") + R(Math.abs(base.income - base.consumption)) + " por mês (" + baseNote + ").", "registrado");
    } else add("poupanca", null, null, "Sem ganhos e despesas registrados no mesmo mês.", "registrado", "Registre ganhos e despesas em Gastos.");

    // 2. Comprometimento da renda
    if (haveIncome) {
      var commit = base.fixed + ctx.debtInstallmentsNotLogged, cr = commit / base.income;
      add("comprometimento", piecewise(cr, [[0, 100], [0.5, 100], [0.7, 50], [0.9, 10], [1, 0]]), pctText(cr, 1) + " da renda",
        "Despesas fixas (" + R(base.fixed) + ") + parcelas de dívidas (" + R(ctx.debtInstallmentsNotLogged) + ") = " + R(commit) + " por mês.", "registrado");
    } else add("comprometimento", null, null, "Precisa de ganhos e despesas registrados.", "registrado", "Registre ganhos e despesas em Gastos.");

    // 3. Equilíbrio entre ganhos e despesas (mensal)
    var fullM = base ? base.fullMonths : [];
    if (fullM.length >= 2) {
      var pos = fullM.filter(function (m) { return m.income > m.consumption; }).length;
      add("equilibrio", pos / fullM.length * 100, pos + " de " + fullM.length + " meses no azul",
        "Meses em que os ganhos superaram as despesas de consumo.", "registrado");
    } else add("equilibrio", null, null, "Precisa de pelo menos 2 meses fechados com ganhos e despesas.", "registrado", "Continue registrando: com 2 meses completos esse indicador aparece.");

    // 4. Nível de endividamento
    if (ctx.debts.length) {
      if (haveIncome) {
        var dti = ctx.debtInstallments / base.income;
        var sc = piecewise(dti, [[0, 100], [0.15, 100], [0.3, 60], [0.5, 20], [0.7, 0]]);
        if (ctx.highDebts.length) sc = Math.max(0, sc - 25);
        add("endividamento", sc, pctText(dti, 1) + " da renda em parcelas",
          "Saldo devedor total de " + R(ctx.nw.debts) + "; parcelas de " + R(ctx.debtInstallments) + " por mês" + (ctx.highDebts.length ? "; há dívida com juros altos." : "."), "declarado");
      } else add("endividamento", null, R(ctx.nw.debts) + " em dívidas", "Falta renda registrada para comparar as parcelas.", "declarado", "Registre ganhos em Gastos.");
    } else if (ctx.tdata.profile.hasDebts === "nao") add("endividamento", 100, "Sem dívidas", "Você informou que não tem dívidas.", "declarado");
    else add("endividamento", null, null, "Você ainda não informou se tem dívidas.", "declarado", "Cadastre suas dívidas ou informe que não tem nenhuma.");

    // 5. Reserva de emergência
    if (ctx.reserve === null) add("reserva", null, null, "Você ainda não informou sua reserva de emergência.", "declarado", "Registre a reserva em Patrimônio ou informe que não tem.");
    else if (ctx.reserve === 0) add("reserva", 0, "0 meses", "Você informou que não tem reserva de emergência.", "declarado");
    else if (base && base.consumption > 0) {
      var rm = ctx.reserve / base.consumption;
      add("reserva", piecewise(rm, [[0, 0], [1, 30], [3, 70], [6, 100]]), rm.toLocaleString("pt-BR", { maximumFractionDigits: 1 }) + " meses de gastos",
        "Reserva de " + R(ctx.reserve) + " para gastos médios de " + R(base.consumption) + " por mês.", "misto");
    } else add("reserva", null, R(ctx.reserve), "Falta registrar despesas para saber quantos meses a reserva cobre.", "misto", "Registre despesas em Gastos.");

    // 6. Regularidade dos investimentos
    if (fullM.length >= 2) {
      var inv = fullM.filter(function (m) { return m.invest > 0; }).length;
      add("investimentos", inv / fullM.length * 100, inv + " de " + fullM.length + " meses com aporte",
        "Considera os lançamentos na categoria Investimentos e aplicações.", "registrado");
    } else add("investimentos", null, null, "Precisa de pelo menos 2 meses fechados.", "registrado", "Continue registrando seus aportes na categoria Investimentos.");

    // 7. Evolução patrimonial
    var ch = ctx.nwChange;
    if (ch) {
      var psc = haveIncome ? 50 + 250 * (ch.monthlyDelta / base.income) : (ch.delta > 0 ? 75 : ch.delta === 0 ? 50 : 25);
      add("patrimonio", psc, (ch.delta >= 0 ? "+" : "−") + R(Math.abs(ch.delta)), "Patrimônio líquido de " + R(ch.from.net) + " em " + G.brDate(ch.from.date) + " para " + R(ch.to.net) + " em " + G.brDate(ch.to.date) + ".", "declarado");
    } else add("patrimonio", null, ctx.tdata.networth.length ? R(ctx.nw.net) : null, "Precisa de pelo menos 2 registros do patrimônio em datas diferentes.", "declarado", "Atualize seu patrimônio de tempos em tempos (o Treinador guarda uma foto por dia).");

    // 8. Metas
    var ev = ctx.goals.filter(function (x) { return x.status !== "sem_prazo"; });
    if (ev.length) {
      var ok = ev.filter(function (x) { return x.status === "done" || x.status === "no_prazo"; }).length;
      add("metas", ok / ev.length * 100, ok + " de " + ev.length + " no ritmo", "Metas com prazo: concluídas ou com aporte suficiente para chegar a tempo.", "declarado");
    } else add("metas", null, null, ctx.goals.length ? "Suas metas não têm prazo definido." : "Você ainda não criou metas.", "declarado", "Crie metas com prazo em Metas.");

    return out;
  }

  function levelOf(score) {
    if (score >= 85) return { id: "excelente", label: "Excelente", tone: "good" };
    if (score >= 70) return { id: "boa", label: "Boa", tone: "good" };
    if (score >= 50) return { id: "atencao", label: "Atenção", tone: "warn" };
    return { id: "critica", label: "Crítica", tone: "bad" };
  }

  /** Nota geral: média ponderada só dos indicadores que têm dados. Exige 3+ indicadores e a poupança. */
  function overall(inds) {
    var tot = 0, w = 0, n = 0, hasSav = false, missing = [];
    inds.forEach(function (i) {
      if (i.score !== null) { tot += i.score * i.weight; w += i.weight; n++; if (i.id === "poupanca") hasSav = true; }
      else missing.push({ id: i.id, label: i.label, hint: i.missing });
    });
    if (n < 3 || !hasSav) return { score: null, coverage: n, level: null, missing: missing, reason: "Dados insuficientes para uma nota geral: são necessários pelo menos 3 indicadores, incluindo a capacidade de poupança." };
    var score = Math.round(tot / w);
    return { score: score, coverage: n, level: levelOf(score), missing: missing, reason: null };
  }

  /* ---------- problemas, prioridades e recomendações ---------- */

  var RANK = { dados: 5, deficit: 10, juros_altos: 20, invest_com_divida: 25, reserva_baixa: 30, reserva_parcial: 40, comprometimento: 45,
    taxa_desconhecida: 48, juros_moderados: 50, poupanca_baixa: 60, patrimonio_queda: 65, metas_fora: 70, invest_irregular: 80 };

  function names(list) { return list.map(function (d) { return d.name; }).join(", "); }

  function findProblems(ctx, inds) {
    var base = ctx.base, list = [];
    function add(id, severity, title, o) {
      o.id = id; o.severity = severity; o.title = title; o.rank = RANK[id];
      o.how = o.how || []; o.evidence = o.evidence || [];
      list.push(o);
    }
    var byId = {}; inds.forEach(function (i) { byId[i.id] = i; });

    // Dados insuficientes: sem isso nenhuma conclusão sobre ganhos e despesas é confiável.
    if (!base) {
      var anyInc = ctx.stats.some(function (m) { return m.incomeCount > 0; }), anyExp = ctx.stats.some(function (m) { return m.expenseCount > 0; });
      add("dados", "info", "Complete seus dados para o diagnóstico", {
        what: !anyInc && !anyExp ? "Ainda não há ganhos nem despesas registrados nos últimos meses."
          : !anyInc ? "Há despesas registradas, mas nenhum ganho nos últimos meses." : !anyExp ? "Há ganhos registrados, mas nenhuma despesa nos últimos meses."
            : "Ganhos e despesas aparecem em meses diferentes: o Treinador precisa dos dois no mesmo mês.",
        why: "Sem ganhos e despesas do mesmo período não dá para saber quanto sobra ou falta. Preferimos não dar nota a chutar.",
        consequence: "Enquanto isso, as recomendações sobre poupança, déficit e reserva ficam indisponíveis.",
        action: "Registrar seus ganhos e despesas do último mês (e dos anteriores, se lembrar).",
        how: ["Em Gastos, use + Novo ganho e + Nova despesa.", "Marque como recorrentes os itens que se repetem todo mês (salário, aluguel, assinaturas).", "Volte ao Treinador: o diagnóstico se atualiza sozinho."],
        outcome: "Com 2 ou 3 meses completos, a nota e as prioridades ficam bem mais confiáveis."
      });
    }

    if (base && base.income > 0 && base.consumption > base.income) {
      var gap = base.consumption - base.income, tops = base.top.map(function (t) { return t.name + " (" + R(t.avg) + ")"; }).join(", ");
      add("deficit", "critico", "Você gasta mais do que ganha", {
        what: "Em média, seus gastos de consumo foram " + R(base.consumption) + " por mês e seus ganhos " + R(base.income) + ": faltam " + R(gap) + " por mês (" + pctText(base.consumption / base.income, 0) + " da renda).",
        why: "Quando o mês fecha no vermelho, a diferença sai da reserva, vira dívida ou deixa contas atrasadas. Nenhuma outra melhoria se sustenta enquanto isso acontece.",
        consequence: "Se nada mudar, em 6 meses são " + R(gap * 6) + " de reserva consumida ou de dívida nova.",
        action: "Fechar o mês no azul: reduzir despesas ou aumentar ganhos em pelo menos " + R(gap) + " por mês.",
        how: ["Em Gastos, veja as maiores categorias do período" + (tops ? " (hoje: " + tops + ")" : "") + ".",
          "Corte ou renegocie primeiro o que não é essencial; mantenha moradia, alimentação, saúde e transporte básicos.",
          "Defina um orçamento mensal em Gastos > Orçamento e acompanhe por 30 dias.",
          "Se os cortes não bastarem, avalie formas de aumentar a renda."],
        outcome: "Zerar o déficit libera " + R(gap) + " por mês, que passam a poder ser usados para reserva e dívidas.",
        evidence: ["Ganhos médios: " + R(base.income), "Gastos médios: " + R(base.consumption), "Base: " + (base.partial ? "mês em andamento" : base.months + " mês(es)")]
      });
    }

    if (ctx.highDebts.length) {
      var interestMonth = 0, bal = 0, lines = [];
      ctx.highDebts.forEach(function (d) {
        interestMonth += d.balance * d.rate; bal += d.balance;
        var s = singleDebt(d, 0), jur = Math.round(d.balance * d.rate);
        lines.push(d.name + ": saldo " + R(d.balance) + " a " + rateText(d.rate) + (s.never ? "; a parcela de " + R(d.installment) + " não cobre os juros do mês (" + R(jur) + "), então o saldo cresce" : "; só pagando a parcela, quita em " + s.months + " meses"));
      });
      interestMonth = Math.round(interestMonth);
      add("juros_altos", ctx.highDebts.some(function (d) { return singleDebt(d, 0).never; }) ? "critico" : "alto", "Dívidas com juros altos", {
        what: "Você tem " + ctx.highDebts.length + (ctx.highDebts.length === 1 ? " dívida" : " dívidas") + " com juros de 3% ao mês ou mais (" + names(ctx.highDebts) + "), somando " + R(bal) + ". Só de juros isso custa cerca de " + R(interestMonth) + " por mês.",
        why: "Juros desse tamanho crescem mais rápido do que investimentos conservadores costumam render. Cada mês de atraso aumenta o saldo.",
        consequence: "Pagando apenas as parcelas, o tempo de quitação e o total de juros ficam muito maiores do que se o dinheiro extra fosse direcionado a essas dívidas.",
        action: "Concentrar qualquer dinheiro extra na dívida de maior taxa (método avalanche) e tentar renegociar.",
        how: ["Em Dívidas, confira se todas as dívidas estão cadastradas com saldo, taxa e parcela, e rode a simulação.",
          "Pague as parcelas de todas as dívidas e coloque todo valor extra na de maior taxa.",
          "Peça ao credor condições de renegociação ou desconto para quitação antecipada e compare o custo total antes de aceitar.",
          "Evite novas compras no crédito rotativo enquanto estiver quitando."],
        outcome: "Quitar o saldo de " + R(bal) + " elimina cerca de " + R(interestMonth) + " de juros por mês.",
        evidence: lines
      });
    }

    if (base && base.invest > 0 && ctx.highDebts.length) {
      var maxR = Math.max.apply(null, ctx.highDebts.map(function (d) { return d.rate; }));
      add("invest_com_divida", "alto", "Investindo enquanto paga juros altos", {
        what: "Você fez aportes médios de " + R(base.invest) + " por mês em investimentos enquanto paga juros de até " + rateText(maxR) + ".",
        why: "Um investimento conservador raramente rende o que uma dívida assim custa. Manter os dois ao mesmo tempo costuma sair mais caro do que quitar a dívida primeiro.",
        consequence: "O dinheiro que poderia reduzir a dívida fica rendendo menos do que ela custa.",
        action: "Direcionar os aportes para quitar a dívida cara, mantendo só o que for sua reserva mínima.",
        how: ["Pause temporariamente novos aportes além da reserva.", "Use o valor para quitar a dívida de maior taxa (veja a simulação em Dívidas).", "Retome os aportes depois da quitação."],
        outcome: "Cada " + R(100000) + " usados na quitação evitam cerca de " + R(Math.round(100000 * maxR)) + " de juros no primeiro mês.",
        evidence: ["Aporte médio: " + R(base.invest), "Maior taxa: " + rateText(maxR)]
      });
    }

    // Reserva
    if (ctx.reserve !== null && (ctx.reserve === 0 || base)) {
      var months = ctx.reserve === 0 ? 0 : base && base.consumption > 0 ? ctx.reserve / base.consumption : null;
      if (months !== null && months < 3) {
        var needMonthly = base && base.consumption > 0 ? base.consumption : null, target = needMonthly ? needMonthly * 3 : null;
        var left = ctx.leftover;
        add(months < 1 ? "reserva_baixa" : "reserva_parcial", months < 1 ? "alto" : "medio", months < 1 ? "Reserva de emergência insuficiente" : "Reserva de emergência incompleta", {
          what: ctx.reserve === 0 ? "Você informou que não tem reserva de emergência." : "Sua reserva de " + R(ctx.reserve) + " cobre " + months.toLocaleString("pt-BR", { maximumFractionDigits: 1 }) + " mês(es) dos seus gastos médios (" + R(needMonthly) + ").",
          why: "Imprevistos como problema de saúde, conserto ou perda de renda são comuns. Sem reserva, eles viram dívida cara ou atraso.",
          consequence: "Qualquer imprevisto pode obrigar você a usar crédito com juros altos.",
          action: target ? "Formar uma reserva de pelo menos 3 meses de gastos (" + R(target) + "); faltam " + R(Math.max(0, target - ctx.reserve)) + "." : "Começar uma reserva de emergência.",
          how: ["Defina um valor fixo por mês e separe logo que receber.", "Mantenha em uma aplicação de baixo risco e com resgate rápido (veja as opções da sua instituição).",
            "Registre a reserva em Patrimônio > Reserva de emergência para acompanhar o progresso.", "Crie uma meta para a reserva em Metas."],
          outcome: target && left > 0 ? "Guardando sua sobra média de " + R(left) + " por mês, a meta de 3 meses leva cerca de " + Math.ceil(Math.max(0, target - ctx.reserve) / left) + " meses (sem contar rendimento)." : (target ? "A meta de 3 meses é " + R(target) + "." : null),
          evidence: ["Reserva atual: " + R(ctx.reserve)]
        });
      }
    }

    if (base && base.income > 0) {
      var commit = base.fixed + ctx.debtInstallmentsNotLogged, cr = commit / base.income;
      if (cr > 0.5) {
        add("comprometimento", cr >= 0.7 ? "alto" : "medio", "Renda muito comprometida com gastos fixos", {
          what: "Despesas fixas e parcelas somam " + R(commit) + " por mês, " + pctText(cr, 0) + " da sua renda.",
          why: "Quanto maior a parte da renda presa em compromissos fixos, menor a margem para imprevistos, reserva e investimentos.",
          consequence: "Uma queda de renda ou um gasto inesperado desequilibra o orçamento com facilidade.",
          action: "Rever os compromissos fixos e reduzir os que puderem ser renegociados ou cancelados.",
          how: ["Liste as despesas fixas em Gastos e ordene pelo valor.", "Renegocie contratos (internet, seguros, planos) e cancele assinaturas que não usa.", "Evite assumir novas parcelas até reduzir esse percentual."],
          outcome: "Reduzir esse comprometimento para 50% da renda liberaria cerca de " + R(commit - Math.round(base.income * 0.5)) + " por mês.",
          evidence: ["Despesas fixas: " + R(base.fixed), "Parcelas (fora das despesas): " + R(ctx.debtInstallmentsNotLogged)]
        });
      }
    }

    if (ctx.unknownDebts.length) {
      add("taxa_desconhecida", "medio", "Faltam taxas de juros nas dívidas", {
        what: ctx.unknownDebts.length + (ctx.unknownDebts.length === 1 ? " dívida está" : " dívidas estão") + " sem taxa de juros: " + names(ctx.unknownDebts) + ".",
        why: "Sem a taxa não dá saber qual dívida custa mais nem simular a quitação com precisão.",
        consequence: "As simulações ficam incompletas e a ordem de pagamento pode estar errada.",
        action: "Descobrir a taxa de cada dívida e cadastrar.",
        how: ["Procure no contrato, no aplicativo do banco ou na fatura (taxa ao mês, no campo de juros ou CET).", "Se for cartão rotativo ou cheque especial, peça a taxa atual ao banco.", "Atualize a dívida em Dívidas."],
        outcome: "Com todas as taxas, a simulação mostra o tempo e o custo reais de cada estratégia."
      });
    }

    if (ctx.modDebts.length) {
      var bm = 0; ctx.modDebts.forEach(function (d) { bm += d.balance; });
      var top = ctx.modDebts.slice().sort(function (a, b) { return b.rate - a.rate; })[0];
      add("juros_moderados", "medio", "Dívidas com juros menores", {
        what: "Você tem " + ctx.modDebts.length + (ctx.modDebts.length === 1 ? " dívida" : " dívidas") + " com juros abaixo de 3% ao mês (" + names(ctx.modDebts) + "), somando " + R(bm) + ". A mais cara é " + top.name + ", a " + rateText(top.rate) + ".",
        why: "Essas dívidas custam menos, mas continuam consumindo parte da renda todo mês.",
        consequence: "Mantidas só no mínimo, levam mais tempo e custam mais juros do que se o excesso do orçamento fosse usado para antecipá-las.",
        action: "Manter as parcelas em dia e, depois da reserva, antecipar a dívida de maior taxa.",
        how: ["Em Dívidas, compare avalanche e bola de neve com o valor extra que você consegue usar.", "Peça desconto para antecipar parcelas (o credor deve abater os juros futuros).", "Não assuma novas dívidas durante a quitação."],
        outcome: "Quitar " + top.name + " elimina cerca de " + R(Math.round(top.balance * top.rate)) + " de juros por mês.",
        evidence: ctx.modDebts.map(function (d) { return d.name + ": " + R(d.balance) + " a " + rateText(d.rate); })
      });
    }

    if (base && base.income > 0 && base.consumption <= base.income) {
      var rate = (base.income - base.consumption) / base.income;
      if (rate < 0.1) {
        var want = Math.round(base.income * 0.1), more = want - (base.income - base.consumption);
        var tops2 = base.top.map(function (t) { return t.name + " (" + R(t.avg) + ")"; }).join(", ");
        add("poupanca_baixa", "medio", "Pouca sobra no fim do mês", {
          what: "Sobram em média " + R(base.income - base.consumption) + " por mês, " + pctText(rate, 1) + " da sua renda.",
          why: "Uma referência usual é poupar de 10% a 20% da renda. Com sobra pequena, o patrimônio cresce devagar e qualquer imprevisto pesa mais.",
          consequence: "Alcançar metas e formar reserva leva muito mais tempo.",
          action: "Chegar a 10% da renda (" + R(want) + " por mês), reduzindo despesas variáveis em cerca de " + R(more) + ".",
          how: ["Veja onde está o maior gasto" + (tops2 ? " (hoje: " + tops2 + ")" : "") + ".", "Escolha uma ou duas categorias para reduzir um pouco, em vez de cortar tudo.", "Transfira o valor da sobra logo que receber."],
          outcome: "Guardar mais " + R(more) + " por mês soma " + R(more * 12) + " em 12 meses (sem contar rendimento).",
          evidence: ["Sobra média: " + R(base.income - base.consumption)]
        });
      }
    }

    if (ctx.nwChange && ctx.nwChange.delta < 0) {
      var c = ctx.nwChange;
      add("patrimonio_queda", "medio", "Patrimônio líquido em queda", {
        what: "Seu patrimônio líquido foi de " + R(c.from.net) + " (" + G.brDate(c.from.date) + ") para " + R(c.to.net) + " (" + G.brDate(c.to.date) + "): queda de " + R(-c.delta) + ".",
        why: "Patrimônio que diminui indica que você está consumindo mais do que acumula, ou que dívidas e perdas de valor estão superando o que você guarda.",
        consequence: "Se continuar, a capacidade de enfrentar imprevistos e de atingir metas diminui.",
        action: "Descobrir a origem da queda: gastos acima da renda, nova dívida ou desvalorização de algum ativo.",
        how: ["Compare a lista de ativos e passivos entre as duas datas.", "Veja se houve novas dívidas ou despesas grandes no período.", "Atualize os valores em Patrimônio para o diagnóstico refletir a realidade."],
        outcome: "Identificar a causa mostra qual das prioridades acima precisa de atenção primeiro."
      });
    }

    var bad = ctx.goals.filter(function (x) { return x.status === "fora" || x.status === "atrasada"; });
    var overPlan = ctx.leftover !== null && ctx.goalsMonthly > Math.max(0, ctx.leftover);
    if (bad.length || overPlan) {
      add("metas_fora", "medio", "Metas fora da sua capacidade atual", {
        what: (bad.length ? bad.length + (bad.length === 1 ? " meta está" : " metas estão") + " fora do ritmo: " + names(bad) + ". " : "") +
          (overPlan ? "Os aportes planejados nas metas somam " + R(ctx.goalsMonthly) + " por mês, acima da sua sobra média de " + R(Math.max(0, ctx.leftover)) + "." : ""),
        why: "Metas com aporte maior do que a sobra real não se sustentam e geram frustração ou dívida.",
        consequence: "Você pode atrasar ou abandonar as metas, ou recorrer a crédito para cumpri-las.",
        action: "Ajustar prazo, valor ou aporte das metas para caber na sua realidade, priorizando a mais importante.",
        how: ["Em Metas, edite as que estão fora do ritmo e veja quanto precisa guardar por mês.", "Ordene por importância e concentre o dinheiro numa de cada vez.", "Se não couber, amplie o prazo antes de reduzir a reserva."],
        outcome: bad.length && bad[0].needed ? "Para " + bad[0].name + ", seria preciso guardar cerca de " + R(bad[0].needed) + " por mês." : null,
        evidence: bad.map(function (x) { return x.name + (x.needed ? ": precisa de " + R(x.needed) + "/mês, planejado " + R(x.monthly) : ""); })
      });
    }

    var severe = list.some(function (p) { return p.rank < 45; });
    var invInd = byId.investimentos;
    if (!severe && invInd && invInd.score !== null && invInd.score < 67 && ctx.leftover > 0) {
      add("invest_irregular", "baixo", "Aportes irregulares", {
        what: "Você registrou aportes em " + invInd.value + ".",
        why: "Aportar com regularidade forma o hábito e permite que os juros compostos trabalhem ao longo do tempo.",
        consequence: "Aportes esporádicos tornam o crescimento do patrimônio imprevisível.",
        action: "Definir um aporte mensal fixo, mesmo que pequeno, logo após receber.",
        how: ["Escolha um valor que caiba na sua sobra média (" + R(ctx.leftover) + ").", "Agende a transferência para o dia do recebimento.", "Registre o aporte na categoria Investimentos em Gastos."],
        outcome: "Aportar a sua sobra média por 12 meses soma " + R(ctx.leftover * 12) + " (sem contar rendimento)."
      });
    }

    list.sort(function (a, b) { return a.rank - b.rank; });
    return list;
  }

  function positives(ctx, inds) {
    var out = [];
    inds.forEach(function (i) { if (i.score !== null && i.score >= 80) out.push(i.label + ": " + i.value + "."); });
    return out;
  }

  function opportunities(ctx) {
    var out = [], base = ctx.base;
    if (ctx.leftover !== null && ctx.leftover > 0) {
      if (ctx.reserve !== null && base && ctx.reserve / base.consumption < 3) out.push("Sua sobra média de " + R(ctx.leftover) + " por mês pode alimentar a reserva de emergência.");
      else if (ctx.highDebts.length) out.push("Sua sobra média de " + R(ctx.leftover) + " por mês pode ser usada para quitar as dívidas com juros altos.");
      else out.push("Você tem sobra média de " + R(ctx.leftover) + " por mês para direcionar a metas ou investimentos.");
    }
    if (ctx.debts.length >= 2 && !ctx.debts.some(function (d) { return d.rate === null; })) {
      var cmp = compareMethods(ctx.debts, 0), best = cmp.avalanche;
      if (!best.never && !cmp.separado.never && cmp.economyAvalanche.interest > 0) out.push("Reorganizar o pagamento das dívidas (avalanche) pode economizar cerca de " + R(cmp.economyAvalanche.interest) + " em juros em relação a pagar cada uma isoladamente.");
    }
    var done = ctx.goals.filter(function (x) { return x.status === "done"; }).length;
    if (done) out.push("Você já concluiu " + done + (done === 1 ? " meta" : " metas") + ": mantenha o hábito.");
    return out;
  }

  function risks(problems) {
    return problems.filter(function (p) { return p.severity === "critico" || p.severity === "alto"; }).map(function (p) { return p.consequence; });
  }

  /** Dados que faltam para um diagnóstico completo (o Treinador pede, em vez de supor). */
  function missingData(ctx) {
    var m = [];
    if (!ctx.base) m.push({ id: "gastos", text: "Registrar ganhos e despesas do mesmo mês", where: "gastos.html" });
    if (!ctx.debts.length && ctx.tdata.profile.hasDebts === null) m.push({ id: "dividas", text: "Informar se você tem dívidas", where: "dividas" });
    if (ctx.reserve === null) m.push({ id: "reserva", text: "Informar sua reserva de emergência", where: "patrimonio" });
    if (!ctx.tdata.assets.length && !ctx.tdata.liabilities.length && !ctx.debts.length) m.push({ id: "patrimonio", text: "Registrar seus ativos e passivos", where: "patrimonio" });
    if (!ctx.goals.length) m.push({ id: "metas", text: "Criar suas metas financeiras", where: "metas.html" });
    return m;
  }

  /** Diagnóstico completo a partir dos dados do Cousner. */
  function diagnose(gdata, goals, tdata, today) {
    today = today || G.todayStr();
    var ctx = buildContext(gdata, goals || [], tdata, today);
    var inds = indicators(ctx), ov = overall(inds), problems = findProblems(ctx, inds);
    // Teto da nota: uma média alta não pode esconder um problema grave. O limite e o motivo ficam visíveis.
    if (ov.score !== null) {
      var worst = problems.filter(function (p) { return p.severity === "critico"; })[0], cap = null;
      if (worst) cap = { max: CAP_CRITICAL, because: worst.title, severity: "crítico" };
      else { worst = problems.filter(function (p) { return p.severity === "alto"; })[0]; if (worst) cap = { max: CAP_HIGH, because: worst.title, severity: "alto" }; }
      if (cap && ov.score > cap.max) { ov.capped = { raw: ov.score, max: cap.max, because: cap.because, severity: cap.severity }; ov.score = cap.max; ov.level = levelOf(ov.score); }
    }
    return {
      today: today, ctx: ctx, base: ctx.base, indicators: inds, overall: ov, problems: problems, priority: problems.length ? problems[0] : null,
      positives: positives(ctx, inds), risks: risks(problems), opportunities: opportunities(ctx), missing: missingData(ctx)
    };
  }

  /* ---------- histórico e acompanhamento ---------- */

  function historyEntry(diag) {
    var ind = {}; diag.indicators.forEach(function (i) { ind[i.id] = i.score; });
    return { date: diag.today, score: diag.overall.score, coverage: diag.overall.coverage, priority: diag.priority ? diag.priority.id : null,
      problems: diag.problems.map(function (p) { return p.id; }), ind: ind, net: diag.ctx.tdata.assets.length || diag.ctx.tdata.liabilities.length || diag.ctx.debts.length ? diag.ctx.nw.net : null,
      months: diag.base ? diag.base.months : 0 };
  }

  /** Guarda (ou atualiza) o diagnóstico de hoje. Só guarda se houver nota. */
  function saveDiagnostic(tdata, diag) {
    if (diag.overall.score === null) return false;
    var e = sanitizeHistory(historyEntry(diag));
    if (!e) return false;
    tdata.history = tdata.history.filter(function (h) { return h.date !== e.date; });
    tdata.history.push(e);
    tdata.history.sort(function (a, b) { return G.toDays(a.date) - G.toDays(b.date); });
    tdata.history = tdata.history.slice(-60);
    return true;
  }

  /** Compara dois diagnósticos salvos: o que melhorou, piorou e quais problemas surgiram ou sumiram. */
  function compareHistory(a, b) {
    var inds = INDICATOR_IDS.map(function (id) {
      var x = a.ind[id], y = b.ind[id], dir = x === null || y === null ? "sem" : y - x >= 5 ? "melhorou" : x - y >= 5 ? "piorou" : "igual";
      return { id: id, label: LABELS[id], from: x, to: y, delta: x === null || y === null ? null : y - x, direction: dir };
    });
    return {
      from: a, to: b, scoreDelta: a.score === null || b.score === null ? null : b.score - a.score, indicators: inds,
      appeared: b.problems.filter(function (p) { return a.problems.indexOf(p) < 0; }),
      resolved: a.problems.filter(function (p) { return b.problems.indexOf(p) < 0; })
    };
  }

  function setAction(tdata, id, done, today) {
    if (!inList(PROBLEM_IDS, id)) return false;
    if (done) tdata.actions[id] = { status: "done", doneAt: today }; else delete tdata.actions[id];
    return true;
  }

  /** Progresso das recomendações atuais: quantas já foram marcadas como concluídas. */
  function progress(problems, tdata) {
    var done = problems.filter(function (p) { return tdata.actions[p.id]; }).length;
    return { done: done, total: problems.length, lifetime: Object.keys(tdata.actions).length };
  }

  /* ---------- previsão financeira ---------- */

  function lastDay(key) { return G.toDays(key + "-" + pad(G.daysInMonth(+key.slice(0, 4), +key.slice(5, 7)))); }

  /**
   * Projeta o saldo em semanas (8) ou meses (6).
   * CONFIRMADO: lançamentos agendados, recorrentes cadastrados e parcelas de dívidas com prazo informado.
   * ESTIMADO: média dos gastos variáveis e ganhos eventuais dos meses recentes (pode ser desligada).
   */
  function forecast(gdata, tdata, today, opts) {
    opts = opts || {};
    var mode = opts.mode === "weekly" ? "weekly" : "monthly", includeEst = opts.includeEstimates !== false;
    var td = G.toDays(today), cur = monthKey(today), buckets = [], i;
    if (mode === "weekly") {
      for (i = 0; i < 8; i++) buckets.push({ start: td + 1 + 7 * i, end: td + 7 * (i + 1) });
    } else {
      for (i = 0; buckets.length < 6 && i < 8; i++) {
        var key = shiftMonthKey(cur, i), s = Math.max(td + 1, G.toDays(key + "-01")), e = lastDay(key);
        if (s <= e) buckets.push({ start: s, end: e, key: key });
      }
    }
    buckets.forEach(function (b) {
      b.label = mode === "weekly" ? G.brShort(b.start) + " a " + G.brShort(b.end) : G.monthName(G.fromDays(b.start)).replace(/ de \d+$/, "") + (b.start !== G.toDays(b.key + "-01") ? " (restante)" : "");
      b.days = b.end - b.start + 1; b.inC = 0; b.outC = 0; b.inE = 0; b.outE = 0; b.items = [];
    });
    var H = buckets[buckets.length - 1].end, assumptions = [];
    function put(days, amount, dir, kind, name) {
      if (days <= td || days > H) return;
      for (var j = 0; j < buckets.length; j++) {
        var b = buckets[j];
        if (days >= b.start && days <= b.end) {
          if (kind === "estimado") { if (dir === "in") b.inE += amount; else b.outE += amount; }
          else { if (dir === "in") b.inC += amount; else b.outC += amount; b.items.push({ date: G.fromDays(days), amount: amount, dir: dir, kind: kind, name: name }); }
          return;
        }
      }
    }
    function series(list, dir) {
      list.forEach(function (e) {
        if (e.category === "transferencias") return;
        var d0 = G.toDays(e.date);
        if (isNaN(d0)) return;
        if (!e.recurring) { put(d0, e.amount, dir, "agendado", e.name); return; }
        var anchor = +e.date.slice(8, 10), endD = e.end ? G.toDays(e.end) : Infinity;
        for (var k = 0; k < 1200; k++) {
          var d = G.toDays(G.addMonths(e.date, k, anchor));
          if (d > endD || d > H) break;
          put(d, e.amount, dir, "recorrente", e.name);
        }
      });
    }
    series(gdata.expenses, "out");
    series(gdata.incomes || [], "in");

    var debtNote = false, unknownTerm = false, noDay = false;
    tdata.debts.forEach(function (d) {
      if (d.logged) return;
      var day = d.dueDay || 1; if (!d.dueDay) noDay = true;
      var anchorKey = cur, cand = G.toDays(anchorKey + "-" + pad(Math.min(day, G.daysInMonth(+cur.slice(0, 4), +cur.slice(5, 7)))));
      var k0 = cand > td ? 0 : 1, count = d.remaining || null;
      if (!count) unknownTerm = true;
      for (var k = 0; k < 14; k++) {
        if (count !== null && k >= count) break;
        var key = shiftMonthKey(cur, k0 + k), dd = G.toDays(key + "-" + pad(Math.min(day, G.daysInMonth(+key.slice(0, 4), +key.slice(5, 7)))));
        put(dd, d.installment, "out", "parcela", d.name);
        debtNote = true;
      }
    });
    if (noDay) assumptions.push("Parcelas de dívidas sem dia de vencimento foram colocadas no dia 1 de cada mês.");
    if (unknownTerm) assumptions.push("Dívidas sem número de parcelas restantes: a parcela foi considerada em todos os meses do período.");
    if (debtNote) assumptions.push("Dívidas marcadas como \"já lanço como despesa\" não entram de novo (para não contar em dobro).");

    var ctx = buildContext(gdata, [], tdata, today), base = ctx.base;
    if (includeEst) {
      if (base) {
        var perDayOut = base.nonRecurringConsumption / 30.4375, perDayIn = base.nonRecurringIncome / 30.4375;
        buckets.forEach(function (b) { b.outE += Math.round(perDayOut * b.days); b.inE += Math.round(perDayIn * b.days); });
        assumptions.push("Estimativa de gastos variáveis e ganhos eventuais: média de " + (base.partial ? "mês em andamento" : base.months + " mês(es)") + " de lançamentos que não se repetem (" + R(base.nonRecurringConsumption) + " de gastos e " + R(base.nonRecurringIncome) + " de ganhos por mês).");
      } else assumptions.push("Sem meses completos com ganhos e despesas, não foi possível estimar gastos variáveis: só aparece o que está confirmado.");
    }

    var cash = 0, haveCash = false;
    tdata.assets.forEach(function (a) { if (a.type === "dinheiro" || a.type === "banco") { cash += a.value; haveCash = true; } });
    var balC = cash, balE = cash, firstNeg = null, heavy = null;
    buckets.forEach(function (b) {
      b.netC = b.inC - b.outC; b.netE = b.netC + (includeEst ? b.inE - b.outE : 0);
      balC += b.netC; balE += b.netE; b.endConfirmed = balC; b.endEstimated = includeEst ? balE : null;
      b.negConfirmed = haveCash && balC < 0; b.negEstimated = haveCash && includeEst && balE < 0; b.deficit = (includeEst ? b.netE : b.netC) < 0;
      var out = b.outC + (includeEst ? b.outE : 0);
      if (!heavy || out > heavy.out) heavy = { bucket: b, out: out };
      if (!firstNeg && (haveCash ? (b.negEstimated || b.negConfirmed) : false)) firstNeg = b;
    });
    if (!haveCash) assumptions.push("Saldo inicial não informado (Patrimônio > Saldo em conta ou Dinheiro): os valores mostram só a variação a partir de hoje.");
    return { mode: mode, includeEstimates: includeEst, startBalance: haveCash ? cash : null, balanceKnown: haveCash, buckets: buckets, firstNegative: firstNeg, heaviest: heavy ? heavy.bucket : null, assumptions: assumptions };
  }

  /* ---------- simulador de compra ---------- */

  function pmt(price, r, n) { return r === 0 ? price / n : price * r / (1 - Math.pow(1 + r, -n)); }

  /** Taxa mensal implícita de um parcelamento (bisseção). Retorna 0 se as parcelas somam menos que o preço. */
  function impliedRate(price, installment, n) {
    if (installment * n <= price) return 0;
    var lo = 0, hi = 1;
    for (var k = 0; k < 80; k++) { var mid = (lo + hi) / 2; if (pmt(price, mid, n) > installment) hi = mid; else lo = mid; }
    return (lo + hi) / 2;
  }

  /**
   * Avalia uma compra. input: { name, price, mode: "vista"|"parcelado", n, installment (centavos) | rate (decimal/mês),
   * income, leftover, reserve, goalsMonthly, hasHighDebt, investRate (decimal/mês, opcional), horizon (meses, à vista) }
   */
  function simulatePurchase(i) {
    var err = null;
    if (!(i.price > 0)) err = "Informe o preço.";
    else if (i.mode === "parcelado") {
      if (!(i.n >= 2 && i.n <= 120)) err = "Informe o número de parcelas (entre 2 e 120).";
      else if (!(i.installment > 0) && (i.rate === null || i.rate === undefined || !(i.rate >= 0))) err = "Informe o valor da parcela ou a taxa de juros.";
    }
    if (err) return { error: err };
    var r = { name: i.name || "Compra", mode: i.mode, price: i.price, notes: [], tone: "ok" };
    var payment = 0, total = i.price, rate = 0;
    if (i.mode === "parcelado") {
      if (i.installment > 0) { payment = i.installment; rate = impliedRate(i.price, payment, i.n); }
      else { rate = i.rate; payment = Math.round(pmt(i.price, rate, i.n)); }
      total = Math.round(payment * i.n);
      r.n = i.n; r.payment = payment; r.rate = rate; r.total = total; r.extraCost = total - i.price;
      if (i.installment > 0 && payment * i.n < i.price) r.notes.push("As parcelas somam menos que o preço à vista: confira os valores informados.");
      if (r.extraCost > 0) r.notes.push("Parcelado, você paga " + R(r.extraCost) + " a mais que à vista (juros de cerca de " + rateText(rate) + ").");
      else r.notes.push("Parcelado sem juros: o custo total é igual ao preço à vista.");
    }
    var outflow = i.mode === "parcelado" ? payment : i.price;
    if (i.income > 0) r.incomeShare = outflow / i.income;
    if (i.leftover !== null && i.leftover !== undefined) {
      r.leftoverBefore = i.leftover; r.leftoverAfter = i.mode === "parcelado" ? i.leftover - payment : i.leftover;
      if (i.mode === "parcelado") {
        if (i.leftover <= 0) { r.tone = "risco"; r.notes.push("Você já não tem sobra mensal: uma nova parcela de " + R(payment) + " aumenta o déficit."); }
        else if (payment > i.leftover) { r.tone = "risco"; r.notes.push("A parcela (" + R(payment) + ") é maior que a sua sobra média (" + R(i.leftover) + "): você precisaria cortar outros gastos."); }
        else if (payment > i.leftover * 0.5) { r.tone = "atencao"; r.notes.push("A parcela usaria mais da metade da sua sobra média (" + R(i.leftover) + "), deixando pouca margem."); }
        else r.notes.push("A parcela cabe na sua sobra média, que ficaria em " + R(r.leftoverAfter) + " por mês durante " + i.n + " meses.");
      } else {
        var months = i.leftover > 0 ? i.price / i.leftover : null;
        if (months !== null) r.monthsOfLeftover = months;
        if (months === null) { r.tone = "atencao"; r.notes.push("Sem sobra mensal registrada, esse valor viria da reserva ou de crédito."); }
        else r.notes.push("Esse valor equivale a " + months.toLocaleString("pt-BR", { maximumFractionDigits: 1 }) + " mês(es) da sua sobra média.");
      }
    } else r.notes.push("Sem ganhos e despesas registrados, não dá para medir o impacto no seu orçamento.");
    if (i.mode === "vista" && i.reserve > 0 && i.price > i.reserve * 0.5) {
      r.tone = r.tone === "risco" ? "risco" : "atencao";
      r.notes.push("O valor passa de metade da sua reserva de emergência (" + R(i.reserve) + ").");
    }
    if (i.hasHighDebt && (i.mode === "parcelado" && r.extraCost > 0)) {
      r.tone = r.tone === "risco" ? "risco" : "atencao";
      r.notes.push("Você tem dívidas com juros altos: antes de assumir uma nova parcela com juros, vale priorizar a quitação.");
    }
    if (i.goalsMonthly > 0) r.goalMonths = i.price / i.goalsMonthly;
    if (r.goalMonths) r.notes.push("O preço equivale a " + r.goalMonths.toLocaleString("pt-BR", { maximumFractionDigits: 1 }) + " mês(es) do que você planeja guardar nas metas.");
    var horizon = i.mode === "parcelado" ? i.n : (i.horizon || 12), ir = i.investRate > 0 ? i.investRate : 0;
    if (i.mode === "parcelado") {
      var acc = ir === 0 ? payment * horizon : payment * (Math.pow(1 + ir, horizon) - 1) / ir;
      r.alternative = { label: "Guardar a parcela de " + R(payment) + " por " + horizon + " meses", amount: Math.round(acc), rate: ir };
    } else {
      var acc2 = i.price * Math.pow(1 + ir, horizon);
      r.alternative = { label: "Guardar " + R(i.price) + " por " + horizon + " meses", amount: Math.round(acc2), rate: ir };
    }
    r.alternative.note = ir > 0 ? "Usa a rentabilidade que você informou (" + rateText(ir) + "), que é uma hipótese e não está garantida." : "Sem rentabilidade considerada (0%).";
    return r;
  }

  var api = {
    KEY: KEY, HIGH_RATE: HIGH_RATE, CAP_CRITICAL: CAP_CRITICAL, CAP_HIGH: CAP_HIGH, ASSET_TYPES: ASSET_TYPES, LIAB_TYPES: LIAB_TYPES, INDICATOR_IDS: INDICATOR_IDS, PROBLEM_IDS: PROBLEM_IDS, LABELS: LABELS, WEIGHTS: WEIGHTS, CRITERIA: CRITERIA,
    emptyData: emptyData, sanitizeData: sanitizeData, sanitizeDebt: sanitizeDebt, sanitizeAsset: sanitizeAsset, sanitizeLiability: sanitizeLiability, load: load, save: save, loadGoals: loadGoals,
    monthlyStats: monthlyStats, computeBase: computeBase, evalGoals: evalGoals,
    singleDebt: singleDebt, simulatePayoff: simulatePayoff, compareMethods: compareMethods,
    netWorth: netWorth, snapshotNetWorth: snapshotNetWorth, netWorthChange: netWorthChange,
    buildContext: buildContext, indicators: indicators, overall: overall, levelOf: levelOf, findProblems: findProblems, diagnose: diagnose,
    historyEntry: historyEntry, saveDiagnostic: saveDiagnostic, compareHistory: compareHistory, setAction: setAction, progress: progress,
    forecast: forecast, pmt: pmt, impliedRate: impliedRate, simulatePurchase: simulatePurchase
  };

  root.CBTreinador = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);

import express, { type Express, type NextFunction, type Request, type Response } from "express";
import fs from "fs";
import { type Server } from "http";
import { nanoid } from "nanoid";
import path from "path";
import { createServer as createViteServer } from "vite";
import viteConfig from "../../vite.config";
import { renderInitialHtml } from "../seo";

export async function setupVite(app: Express, server: Server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true as const,
  };

  const vite = await createViteServer({
    ...viteConfig,
    configFile: false,
    server: serverOptions,
    appType: "custom",
  });

  app.use(vite.middlewares);
  app.use("*", async (req, res, next) => {
    const url = req.originalUrl;

    try {
      const clientTemplate = path.resolve(
        import.meta.dirname,
        "../..",
        "client",
        "index.html"
      );

      // always reload the index.html file from disk incase it changes
      let template = await fs.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="/src/main.tsx"`,
        `src="/src/main.tsx?v=${nanoid()}"`
      );
      const rendered = renderInitialHtml(template, req.originalUrl);
      const page = await vite.transformIndexHtml(url, rendered.html);
      if (rendered.noindex) res.setHeader("X-Robots-Tag", "noindex, nofollow, noarchive");
      res.status(rendered.status).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e as Error);
      next(e);
    }
  });
}

export function serveStatic(app: Express) {
  const distPath =
    process.env.NODE_ENV === "development"
      ? path.resolve(import.meta.dirname, "../..", "dist", "public")
      : path.resolve(import.meta.dirname, "public");
  if (!fs.existsSync(distPath)) {
    console.error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }

  const sendInitialPage = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const template = await fs.promises.readFile(path.resolve(distPath, "index.html"), "utf-8");
      const rendered = renderInitialHtml(template, req.originalUrl);
      if (rendered.noindex) res.setHeader("X-Robots-Tag", "noindex, nofollow, noarchive");
      return res.status(rendered.status).type("html").send(rendered.html);
    } catch (error) {
      return next(error);
    }
  };

  app.get(["/", "/planos", "/conta", "/pagamentos", "/treinador", "/404"], sendInitialPage);
  app.use(express.static(distPath));

  // APIs and unmatched pages receive real 404s; static assets above keep their normal paths.
  app.use("*", (req, res, next) => {
    if (req.originalUrl.split("?", 1)[0].startsWith("/api/")) return res.status(404).json({ error: "Not found" });
    return sendInitialPage(req, res, next);
  });
}

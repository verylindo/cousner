import type { CookieOptions, Request } from "express";

export function getSessionCookieOptions(req: Request): CookieOptions {
  const host = String(req.hostname || "").toLowerCase().replace(/^\[|\]$/g, "");
  const plainHttpLocalHost = ["localhost", "127.0.0.1", "::1"].includes(host);
  // Preview is public HTTPS in a cross-site frame even when the upstream request is HTTP.
  // Only plain local development uses Lax/non-Secure so its HTTP cookie can be stored.
  return { httpOnly: true, path: "/", sameSite: plainHttpLocalHost ? "lax" : "none", secure: !plainHttpLocalHost };
}

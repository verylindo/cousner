import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { getPaymentHistoryForUser, getSubscriptionForUser } from "./db";
import { COUSNER_PRO_PUBLIC_FREE, getProBillingConfig, isProEntitled } from "./billing/products";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  billing: router({
    offer: publicProcedure.query(() => {
      return { ready: false, displayPrice: null, publicFree: COUSNER_PRO_PUBLIC_FREE };
    }),
    status: protectedProcedure.query(async ({ ctx }) => {
      ctx.res.setHeader("Cache-Control", "private, no-store, max-age=0");
      if (COUSNER_PRO_PUBLIC_FREE) return { active: true, status: "public_free" };
      const subscription = await getSubscriptionForUser(ctx.user.id);
      const active = isProEntitled(subscription, getProBillingConfig().priceId);
      return { active, status: subscription?.status ?? "free" };
    }),
    history: protectedProcedure.query(({ ctx }) => {
      ctx.res.setHeader("Cache-Control", "private, no-store, max-age=0");
      return getPaymentHistoryForUser(ctx.user.id);
    }),
  }),

  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;
